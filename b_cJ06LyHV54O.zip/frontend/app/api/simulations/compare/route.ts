import { createClient } from "@/lib/supabase/server"
import { createAdminClient } from "@/lib/supabase/admin"
import { NextResponse } from "next/server"

// Demo user/project IDs for unauthenticated users
const DEMO_USER_ID = "00000000-0000-0000-0000-000000000001"
const DEMO_PROJECT_ID = "00000000-0000-0000-0000-000000000002"

export async function POST(request: Request) {
  try {
    const userSupabase = await createClient()
    const adminSupabase = createAdminClient()
    const body = await request.json()
    
    const { base_scenario, scenarios } = body
    
    if (!base_scenario || !scenarios || scenarios.length === 0) {
      return NextResponse.json(
        { error: "Base scenario and at least one comparison scenario are required" },
        { status: 400 }
      )
    }
    
    // Calculate baseline metrics
    const baselineMetrics = calculateMetrics(base_scenario)
    console.log("[v0] Baseline metrics:", baselineMetrics)
    
    // Run each scenario
    const scenarioResults = scenarios.map((scenario: Record<string, number | string>, index: number) => {
      const scenarioMetrics = calculateMetrics(scenario)
      
      const deltaScore = scenarioMetrics.energy_score - baselineMetrics.energy_score
      const deltaCarbon = scenarioMetrics.carbon_footprint - baselineMetrics.carbon_footprint
      const improvementPercent = baselineMetrics.energy_score > 0 
        ? ((scenarioMetrics.energy_score - baselineMetrics.energy_score) / baselineMetrics.energy_score) * 100
        : 0
      
      return {
        name: scenario.name || `Scenario ${index + 1}`,
        config: scenario,
        energy_score: scenarioMetrics.energy_score,
        carbon_footprint: scenarioMetrics.carbon_footprint,
        delta_score: deltaScore,
        delta_carbon: deltaCarbon,
        improvement_percent: improvementPercent
      }
    })
    
    // Get the current user or use demo user
    const { data: { user } } = await userSupabase.auth.getUser()
    const effectiveUserId = user?.id || DEMO_USER_ID
    const effectiveProjectId = DEMO_PROJECT_ID
    
    // Save simulation to database using admin client
    const simulationData = {
      project_id: effectiveProjectId,
      user_id: effectiveUserId,
      name: `Scenario Comparison ${new Date().toLocaleString()}`,
      scenario_config: { base_scenario, scenarios },
      baseline_metrics: baselineMetrics,
      optimized_metrics: scenarioResults[0],
      savings_summary: {
        energy_improvement: scenarioResults[0]?.improvement_percent || 0,
        carbon_reduction: scenarioResults[0]?.delta_carbon || 0
      },
      status: "completed",
      completed_at: new Date().toISOString()
    }
    
    const { error: simError } = await adminSupabase
      .from("simulations")
      .insert(simulationData)
    
    if (simError) {
      console.error("[v0] Error saving simulation:", simError)
    }
    
    // Return results
    return NextResponse.json({
      baseline: baselineMetrics,
      scenarios: scenarioResults
    })
    
  } catch (err) {
    console.error("[v0] Error in POST /api/simulations/compare:", err)
    return NextResponse.json(
      { error: err instanceof Error ? err.message : "Simulation failed" },
      { status: 500 }
    )
  }
}

function calculateMetrics(params: Record<string, number | string>): { 
  energy_score: number
  carbon_footprint: number 
} {
  // Extract parameters with defaults
  const cpuCores = Number(params.cpu_cores) || 4
  const ramGb = Number(params.ram_gb) || 8
  const executionTime = Number(params.execution_time_ms) || 1000
  const linesOfCode = Number(params.lines_of_code) || 100
  const cyclomaticComplexity = Number(params.cyclomatic_complexity) || 5
  const nestedLoopDepth = Number(params.nested_loop_depth) || 1
  const ioOperations = Number(params.io_operations) || 5
  const memoryAllocations = Number(params.memory_allocations) || 50
  const functionCalls = Number(params.function_calls) || 25
  const asyncOperations = Number(params.async_operations) || 2
  
  // Calculate energy score (0-100)
  let energyScore = 100
  
  // Complexity penalties
  energyScore -= Math.min(30, cyclomaticComplexity * 2)
  energyScore -= Math.min(25, nestedLoopDepth * 8)
  energyScore -= Math.min(15, ioOperations * 1.5)
  energyScore -= Math.min(15, memoryAllocations * 0.1)
  energyScore -= Math.min(10, Math.floor(linesOfCode / 100))
  
  // Async operations bonus
  energyScore += Math.min(5, asyncOperations * 1)
  
  // Resource efficiency adjustments
  if (cpuCores >= 8) energyScore += 5
  else if (cpuCores <= 2) energyScore -= 5
  
  if (ramGb >= 16) energyScore += 3
  else if (ramGb <= 4) energyScore -= 3
  
  if (executionTime <= 500) energyScore += 5
  else if (executionTime >= 5000) energyScore -= 10
  
  energyScore = Math.max(0, Math.min(100, Math.round(energyScore)))
  
  // Carbon footprint calculation (kg CO2e)
  const baseWatts = 50 + (cpuCores * 10)
  const hours = executionTime / (1000 * 60 * 60)
  const energyKwh = (baseWatts / 1000) * hours
  const co2Factor = 0.5 // kg CO2/kWh
  const complexityMultiplier = 1 + (cyclomaticComplexity / 100) + (nestedLoopDepth / 20)
  const carbonFootprint = energyKwh * co2Factor * complexityMultiplier
  
  return {
    energy_score: energyScore,
    carbon_footprint: carbonFootprint
  }
}
