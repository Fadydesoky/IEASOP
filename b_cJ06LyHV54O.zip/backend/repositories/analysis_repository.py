"""
Analysis Repository
Database operations for Analysis entities
"""

from typing import Sequence
from sqlalchemy import select, func
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.orm import selectinload

from models.analysis import Analysis
from models.project import Project
from .base import BaseRepository


class AnalysisRepository(BaseRepository[Analysis]):
    """Repository for Analysis entity operations."""
    
    def __init__(self, session: AsyncSession) -> None:
        super().__init__(session, Analysis)
    
    async def get_by_project_id(
        self,
        project_id: str,
        skip: int = 0,
        limit: int = 100
    ) -> Sequence[Analysis]:
        """Get all analyses for a specific project."""
        result = await self._session.execute(
            select(Analysis)
            .where(Analysis.project_id == project_id)
            .order_by(Analysis.created_at.desc())
            .offset(skip)
            .limit(limit)
        )
        return result.scalars().all()
    
    async def get_with_all_relations(self, analysis_id: str) -> Analysis | None:
        """Get an analysis with all relations eagerly loaded."""
        result = await self._session.execute(
            select(Analysis)
            .where(Analysis.id == analysis_id)
            .options(
                selectinload(Analysis.issues),
                selectinload(Analysis.recommendations),
                selectinload(Analysis.metrics),
            )
        )
        return result.scalar_one_or_none()
    
    async def get_latest_by_project(self, project_id: str) -> Analysis | None:
        """Get the most recent analysis for a project."""
        result = await self._session.execute(
            select(Analysis)
            .where(Analysis.project_id == project_id)
            .order_by(Analysis.created_at.desc())
            .limit(1)
        )
        return result.scalar_one_or_none()
    
    async def get_by_user_id(
        self,
        user_id: str,
        skip: int = 0,
        limit: int = 100
    ) -> Sequence[Analysis]:
        """Get all analyses for a user (across all their projects)."""
        result = await self._session.execute(
            select(Analysis)
            .join(Project)
            .where(Project.user_id == user_id)
            .order_by(Analysis.created_at.desc())
            .offset(skip)
            .limit(limit)
        )
        return result.scalars().all()
    
    async def count_by_project(self, project_id: str) -> int:
        """Count analyses for a specific project."""
        result = await self._session.execute(
            select(func.count())
            .select_from(Analysis)
            .where(Analysis.project_id == project_id)
        )
        return result.scalar_one()
    
    async def count_by_user(self, user_id: str) -> int:
        """Count all analyses for a user."""
        result = await self._session.execute(
            select(func.count())
            .select_from(Analysis)
            .join(Project)
            .where(Project.user_id == user_id)
        )
        return result.scalar_one()
    
    async def get_average_score_by_user(self, user_id: str) -> float | None:
        """Get the average energy score across all user analyses."""
        result = await self._session.execute(
            select(func.avg(Analysis.energy_score))
            .join(Project)
            .where(Project.user_id == user_id)
            .where(Analysis.energy_score.isnot(None))
        )
        return result.scalar_one()
    
    async def create_analysis(
        self,
        project_id: str,
        energy_score: float | None = None,
        model_used: str | None = None
    ) -> Analysis:
        """Create a new analysis for a project."""
        analysis = Analysis(
            project_id=project_id,
            energy_score=energy_score,
            model_used=model_used
        )
        return await self.create(analysis)
