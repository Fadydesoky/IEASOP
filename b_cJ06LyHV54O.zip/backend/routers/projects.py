"""
Projects Router
CRUD operations for projects
"""

from fastapi import APIRouter, HTTPException, Header
from pydantic import BaseModel
from typing import Optional, List
from datetime import datetime
from db import get_client
from routers.auth import get_current_user

router = APIRouter()


class ProjectCreate(BaseModel):
    """Project creation model."""
    name: str
    description: Optional[str] = None
    repository_url: Optional[str] = None
    language: Optional[str] = None
    framework: Optional[str] = None


class ProjectUpdate(BaseModel):
    """Project update model."""
    name: Optional[str] = None
    description: Optional[str] = None
    repository_url: Optional[str] = None
    language: Optional[str] = None
    framework: Optional[str] = None
    status: Optional[str] = None


class ProjectResponse(BaseModel):
    """Project response model."""
    id: str
    user_id: str
    name: str
    description: Optional[str] = None
    repository_url: Optional[str] = None
    language: Optional[str] = None
    framework: Optional[str] = None
    status: str = "active"
    latest_energy_score: Optional[float] = None
    latest_carbon_footprint: Optional[float] = None
    created_at: datetime
    updated_at: datetime


@router.get("", response_model=List[ProjectResponse])
async def list_projects(authorization: str = Header(None)):
    """List all projects for current user."""
    user = await get_current_user(authorization)
    client = await get_client()
    
    result = await client.table("projects").select("*").eq("user_id", user.id).order("updated_at", desc=True).execute()
    
    return result.data or []


@router.post("", response_model=ProjectResponse)
async def create_project(project: ProjectCreate, authorization: str = Header(None)):
    """Create a new project."""
    user = await get_current_user(authorization)
    client = await get_client()
    
    data = {
        **project.model_dump(),
        "user_id": user.id,
    }
    
    result = await client.table("projects").insert(data).execute()
    
    if not result.data:
        raise HTTPException(status_code=500, detail="Failed to create project")
    
    return result.data[0]


@router.get("/{project_id}", response_model=ProjectResponse)
async def get_project(project_id: str, authorization: str = Header(None)):
    """Get a specific project."""
    user = await get_current_user(authorization)
    client = await get_client()
    
    result = await client.table("projects").select("*").eq("id", project_id).eq("user_id", user.id).single().execute()
    
    if not result.data:
        raise HTTPException(status_code=404, detail="Project not found")
    
    return result.data


@router.put("/{project_id}", response_model=ProjectResponse)
async def update_project(project_id: str, project: ProjectUpdate, authorization: str = Header(None)):
    """Update a project."""
    user = await get_current_user(authorization)
    client = await get_client()
    
    update_data = {k: v for k, v in project.model_dump().items() if v is not None}
    update_data["updated_at"] = datetime.utcnow().isoformat()
    
    result = await client.table("projects").update(update_data).eq("id", project_id).eq("user_id", user.id).execute()
    
    if not result.data:
        raise HTTPException(status_code=404, detail="Project not found")
    
    return result.data[0]


@router.delete("/{project_id}")
async def delete_project(project_id: str, authorization: str = Header(None)):
    """Delete a project."""
    user = await get_current_user(authorization)
    client = await get_client()
    
    await client.table("projects").delete().eq("id", project_id).eq("user_id", user.id).execute()
    
    return {"message": "Project deleted"}


@router.get("/{project_id}/analyses")
async def list_project_analyses(project_id: str, authorization: str = Header(None)):
    """List all analyses for a project."""
    user = await get_current_user(authorization)
    client = await get_client()
    
    # First verify project ownership
    project = await client.table("projects").select("id").eq("id", project_id).eq("user_id", user.id).single().execute()
    if not project.data:
        raise HTTPException(status_code=404, detail="Project not found")
    
    result = await client.table("analyses").select("*").eq("project_id", project_id).order("created_at", desc=True).execute()
    
    return result.data or []


@router.get("/{project_id}/metrics")
async def get_project_metrics(project_id: str, days: int = 30, authorization: str = Header(None)):
    """Get energy metrics for a project over time."""
    user = await get_current_user(authorization)
    client = await get_client()
    
    # Verify project ownership
    project = await client.table("projects").select("id").eq("id", project_id).eq("user_id", user.id).single().execute()
    if not project.data:
        raise HTTPException(status_code=404, detail="Project not found")
    
    from datetime import timedelta
    start_date = (datetime.utcnow() - timedelta(days=days)).isoformat()
    
    result = await client.table("energy_metrics").select("*").eq("project_id", project_id).gte("recorded_at", start_date).order("recorded_at").execute()
    
    return result.data or []
