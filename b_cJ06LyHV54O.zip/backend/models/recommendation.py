"""
Recommendation Model
"""

from sqlalchemy import String, Text, ForeignKey
from sqlalchemy.orm import Mapped, mapped_column, relationship
from typing import TYPE_CHECKING, Optional

from .base import Base, generate_uuid

if TYPE_CHECKING:
    from .analysis import Analysis


class Recommendation(Base):
    """Recommendation model matching the existing recommendations table."""
    
    __tablename__ = "recommendations"
    
    id: Mapped[str] = mapped_column(
        String,
        primary_key=True,
        default=generate_uuid
    )
    analysis_id: Mapped[str] = mapped_column(
        String,
        ForeignKey("analyses.id", ondelete="CASCADE"),
        nullable=False,
        index=True
    )
    suggestion: Mapped[Optional[str]] = mapped_column(
        Text,
        nullable=True
    )
    impact_level: Mapped[Optional[str]] = mapped_column(
        String,
        nullable=True
    )
    
    # Relationships
    analysis: Mapped["Analysis"] = relationship(
        "Analysis",
        back_populates="recommendations"
    )
    
    def __repr__(self) -> str:
        return f"<Recommendation(id={self.id}, impact_level={self.impact_level})>"
