"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Switch } from "@/components/ui/switch"
import { Slider } from "@/components/ui/slider"
import { Separator } from "@/components/ui/separator"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"
import { Skeleton } from "@/components/ui/skeleton"
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table"
import {
  GitBranch,
  Github,
  GitCommit,
  CheckCircle2,
  XCircle,
  TrendingUp,
  TrendingDown,
  Minus,
  Copy,
  ExternalLink,
  Webhook,
  Settings,
  Play,
  Info,
} from "lucide-react"

interface CICDRun {
  id: string
  commit_sha: string | null
  branch: string | null
  status: "pass" | "fail"
  energy_score: number
  threshold: number
  triggered_by: string
  comparison_to_previous?: {
    previous_score: number
    current_score: number
    delta: number
    improved: boolean
  } | null
  created_at: string
}

interface CICDStats {
  total_runs: number
  pass_rate: number
  fail_count: number
  average_score: number
  best_score: number
  worst_score: number
  trend: "improving" | "declining" | "stable"
}

const webhookExample = `curl -X POST https://api.ieasop.dev/cicd/webhook \\
  -H "Content-Type: application/json" \\
  -d '{
    "api_key": "your_api_key",
    "project_id": "your_project_id",
    "commit_sha": "$COMMIT_SHA",
    "branch": "$BRANCH",
    "code": "$(cat main.py)"
  }'`

const githubActionExample = `name: IEASOP Energy Check

on:
  push:
    branches: [main]
  pull_request:
    branches: [main]

jobs:
  energy-check:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v3
      
      - name: Run IEASOP Check
        run: |
          npx ieasop scan ./src --ci \\
            --api-key \${{ secrets.IEASOP_API_KEY }} \\
            --threshold 70
            
      - name: Comment on PR
        if: github.event_name == 'pull_request'
        uses: actions/github-script@v6
        with:
          script: |
            // Add energy score comment`

export function CICDPage() {
  const [runs, setRuns] = useState<CICDRun[]>([])
  const [stats, setStats] = useState<CICDStats | null>(null)
  const [threshold, setThreshold] = useState(70)
  const [notifyOnFail, setNotifyOnFail] = useState(true)
  const [notifyEmail, setNotifyEmail] = useState("")
  const [webhookUrl, setWebhookUrl] = useState("")
  const [copiedWebhook, setCopiedWebhook] = useState(false)
  const [isLoading, setIsLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)
  const [selectedProjectId, setSelectedProjectId] = useState<string | null>(null)

  useEffect(() => {
    async function fetchCICDData() {
      setError(null)
      try {
        // First try to get projects to get the project ID
        let projectId = selectedProjectId
        if (!projectId) {
          const projectsRes = await fetch("/api/projects")
          if (!projectsRes.ok) throw new Error("Failed to fetch projects")
          const projects = await projectsRes.json()
          if (projects.length > 0) {
            projectId = projects[0].id
            setSelectedProjectId(projectId)
          }
        }
        
        if (!projectId) {
          throw new Error("No project found. Please create a project first.")
        }
        
        // Fetch CI/CD runs
        const runsRes = await fetch(`/api/cicd/runs/${projectId}`)
        if (!runsRes.ok) throw new Error("Failed to fetch CI/CD runs")
        const runsData = await runsRes.json()
        
        // Fetch CI/CD stats
        const statsRes = await fetch(`/api/cicd/runs/${projectId}/stats`)
        if (statsRes.ok) {
          const statsData = await statsRes.json()
          setStats(statsData)
        }
        
        // Fetch CI/CD config
        const configRes = await fetch(`/api/cicd/config/${projectId}`)
        if (configRes.ok) {
          const configData = await configRes.json()
          if (configData.configured) {
            setThreshold(configData.threshold || 70)
            setNotifyOnFail(configData.notify_on_fail ?? true)
            setNotifyEmail(configData.notify_email || "")
            setWebhookUrl(configData.webhook_url || "")
          }
        }
        
        setRuns(runsData || [])
      } catch (err) {
        console.error("[v0] CI/CD fetch error:", err)
        setError(err instanceof Error ? err.message : "Failed to load CI/CD data")
      } finally {
        setIsLoading(false)
      }
    }
    
    fetchCICDData()
  }, [selectedProjectId])

  const displayStats = stats || {
    total_runs: runs.length,
    pass_rate: runs.length > 0 ? (runs.filter(r => r.status === "pass").length / runs.length) * 100 : 0,
    average_score: runs.length > 0 ? runs.reduce((sum, r) => sum + r.energy_score, 0) / runs.length : 0,
    trend: "stable" as const
  }

  const copyWebhook = () => {
    navigator.clipboard.writeText(webhookExample)
    setCopiedWebhook(true)
    setTimeout(() => setCopiedWebhook(false), 2000)
  }

  const formatDate = (dateString: string) => {
    const date = new Date(dateString)
    return date.toLocaleDateString("en-US", {
      month: "short",
      day: "numeric",
      hour: "2-digit",
      minute: "2-digit"
    })
  }

  if (isLoading) {
    return (
      <div className="space-y-6">
        <div>
          <Skeleton className="h-8 w-64" />
          <Skeleton className="h-4 w-96 mt-2" />
        </div>
        <div className="grid gap-4 md:grid-cols-4">
          {[1, 2, 3, 4].map(i => (
            <Card key={i}>
              <CardHeader className="pb-2">
                <Skeleton className="h-4 w-24" />
              </CardHeader>
              <CardContent>
                <Skeleton className="h-8 w-16" />
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    )
  }

  return (
    <div className="space-y-6">
      {/* Error Alert */}
      {error && (
        <Alert variant="destructive">
          <Info className="h-4 w-4" />
          <AlertTitle>Error</AlertTitle>
          <AlertDescription>
            {error}. Please check your connection and try again.
          </AlertDescription>
        </Alert>
      )}

      {/* Header */}
      <div>
        <h2 className="text-2xl font-bold tracking-tight flex items-center gap-2">
          <GitBranch className="h-6 w-6 text-primary" />
          CI/CD Integration
        </h2>
        <p className="text-muted-foreground">
          Integrate energy checks into your CI/CD pipeline
        </p>
      </div>

      {/* Stats */}
      <div className="grid gap-4 md:grid-cols-4">
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Total Runs</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{displayStats.total_runs}</div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Pass Rate</CardTitle>
          </CardHeader>
          <CardContent>
            <div className={`text-2xl font-bold ${
              displayStats.pass_rate >= 80 ? "text-green-500" : 
              displayStats.pass_rate >= 60 ? "text-yellow-500" : "text-red-500"
            }`}>
              {displayStats.pass_rate.toFixed(0)}%
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Average Score</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{displayStats.average_score.toFixed(1)}</div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Trend</CardTitle>
          </CardHeader>
          <CardContent>
            <div className={`text-2xl font-bold flex items-center gap-2 ${
              displayStats.trend === "improving" ? "text-green-500" :
              displayStats.trend === "declining" ? "text-red-500" : "text-muted-foreground"
            }`}>
              {displayStats.trend === "improving" ? (
                <><TrendingUp className="h-5 w-5" /> Improving</>
              ) : displayStats.trend === "declining" ? (
                <><TrendingDown className="h-5 w-5" /> Declining</>
              ) : (
                <><Minus className="h-5 w-5" /> Stable</>
              )}
            </div>
          </CardContent>
        </Card>
      </div>

      <Tabs defaultValue="runs">
        <TabsList>
          <TabsTrigger value="runs">
            <GitCommit className="mr-2 h-4 w-4" />
            Recent Runs
          </TabsTrigger>
          <TabsTrigger value="config">
            <Settings className="mr-2 h-4 w-4" />
            Configuration
          </TabsTrigger>
          <TabsTrigger value="setup">
            <Github className="mr-2 h-4 w-4" />
            Setup Guide
          </TabsTrigger>
        </TabsList>

        <TabsContent value="runs" className="mt-4">
          <Card>
            <CardHeader>
              <CardTitle>Pipeline Runs</CardTitle>
              <CardDescription>
                Recent energy check results from your CI/CD pipelines
              </CardDescription>
            </CardHeader>
            <CardContent>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Commit</TableHead>
                    <TableHead>Branch</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead>Score</TableHead>
                    <TableHead>Threshold</TableHead>
                    <TableHead>Change</TableHead>
                    <TableHead>Source</TableHead>
                    <TableHead>Time</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {runs.map((run) => {
                    const delta = run.comparison_to_previous?.delta ?? 0
                    return (
                      <TableRow key={run.id}>
                        <TableCell className="font-mono text-sm">
                          {run.commit_sha || "N/A"}
                        </TableCell>
                        <TableCell>
                          <Badge variant="outline" className="font-mono text-xs">
                            {run.branch || "unknown"}
                          </Badge>
                        </TableCell>
                        <TableCell>
                          {run.status === "pass" ? (
                            <Badge className="bg-green-500/10 text-green-500 border-green-500/20">
                              <CheckCircle2 className="mr-1 h-3 w-3" />
                              Pass
                            </Badge>
                          ) : (
                            <Badge variant="destructive">
                              <XCircle className="mr-1 h-3 w-3" />
                              Fail
                            </Badge>
                          )}
                        </TableCell>
                        <TableCell className={`font-bold ${
                          run.energy_score >= run.threshold ? "text-green-500" : "text-red-500"
                        }`}>
                          {run.energy_score}
                        </TableCell>
                        <TableCell className="text-muted-foreground">
                          {run.threshold}
                        </TableCell>
                        <TableCell>
                          <span className={`flex items-center gap-1 text-sm ${
                            delta > 0 ? "text-green-500" : 
                            delta < 0 ? "text-red-500" : "text-muted-foreground"
                          }`}>
                            {delta > 0 ? (
                              <TrendingUp className="h-3 w-3" />
                            ) : delta < 0 ? (
                              <TrendingDown className="h-3 w-3" />
                            ) : (
                              <Minus className="h-3 w-3" />
                            )}
                            {delta > 0 ? "+" : ""}{delta}
                          </span>
                        </TableCell>
                        <TableCell>
                          <Badge variant="secondary" className="text-xs">
                            {run.triggered_by}
                          </Badge>
                        </TableCell>
                        <TableCell className="text-sm text-muted-foreground">
                          {formatDate(run.created_at)}
                        </TableCell>
                      </TableRow>
                    )
                  })}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="config" className="mt-4 space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Threshold Settings</CardTitle>
              <CardDescription>
                Configure the minimum energy score required to pass CI checks
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <Label>Energy Score Threshold</Label>
                  <span className="text-2xl font-bold text-primary">{threshold}</span>
                </div>
                <Slider
                  value={[threshold]}
                  onValueChange={([v]) => setThreshold(v)}
                  min={0}
                  max={100}
                  step={5}
                  className="cursor-pointer"
                />
                <p className="text-sm text-muted-foreground">
                  Builds with energy scores below {threshold} will fail the check.
                </p>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Notifications</CardTitle>
              <CardDescription>
                Configure how you want to be notified about check results
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="flex items-center justify-between">
                <div className="space-y-0.5">
                  <Label>Notify on Failure</Label>
                  <p className="text-sm text-muted-foreground">
                    Receive notifications when energy checks fail
                  </p>
                </div>
                <Switch
                  checked={notifyOnFail}
                  onCheckedChange={setNotifyOnFail}
                />
              </div>

              <Separator />

              <div className="space-y-2">
                <Label htmlFor="email">Notification Email</Label>
                <Input
                  id="email"
                  type="email"
                  placeholder="team@company.com"
                  value={notifyEmail}
                  onChange={(e) => setNotifyEmail(e.target.value)}
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="webhook">Webhook URL (optional)</Label>
                <Input
                  id="webhook"
                  type="url"
                  placeholder="https://hooks.slack.com/..."
                  value={webhookUrl}
                  onChange={(e) => setWebhookUrl(e.target.value)}
                />
                <p className="text-xs text-muted-foreground">
                  POST requests will be sent to this URL on check completion
                </p>
              </div>

              <Button>
                <Settings className="mr-2 h-4 w-4" />
                Save Configuration
              </Button>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="setup" className="mt-4 space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Github className="h-5 w-5" />
                GitHub Actions
              </CardTitle>
              <CardDescription>
                Add this workflow to your repository
              </CardDescription>
            </CardHeader>
            <CardContent>
              <pre className="bg-muted p-4 rounded-lg text-xs overflow-x-auto">
                <code>{githubActionExample}</code>
              </pre>
              <div className="mt-4 flex gap-2">
                <Button variant="outline" size="sm">
                  <Copy className="mr-2 h-4 w-4" />
                  Copy Workflow
                </Button>
                <Button variant="outline" size="sm">
                  <ExternalLink className="mr-2 h-4 w-4" />
                  View Documentation
                </Button>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Webhook className="h-5 w-5" />
                Webhook Integration
              </CardTitle>
              <CardDescription>
                Use webhooks for custom CI/CD integration
              </CardDescription>
            </CardHeader>
            <CardContent>
              <pre className="bg-muted p-4 rounded-lg text-xs overflow-x-auto">
                <code>{webhookExample}</code>
              </pre>
              <div className="mt-4">
                <Button variant="outline" size="sm" onClick={copyWebhook}>
                  <Copy className="mr-2 h-4 w-4" />
                  {copiedWebhook ? "Copied!" : "Copy Command"}
                </Button>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Manual Check</CardTitle>
              <CardDescription>
                Run an energy check manually for testing
              </CardDescription>
            </CardHeader>
            <CardContent>
              <Button>
                <Play className="mr-2 h-4 w-4" />
                Run Manual Check
              </Button>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}
