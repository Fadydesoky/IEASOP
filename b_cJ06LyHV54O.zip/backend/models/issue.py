"""
Issue Model
"""

from sqlalchemy import String, Text, ForeignKey
from sqlalchemy.orm import Mapped, mapped_column, relationship
from typing import TYPE_CHECKING, Optional

from .base import Base, generate_uuid

if TYPE_CHECKING:
    from .analysis import Analysis


class Issue(Base):
    """Issue model matching the existing issues table."""
    
    __tablename__ = "issues"
    
    id: Mapped[str] = mapped_column(
        String,
        primary_key=True,
        default=generate_uuid
    )
    analysis_id: Mapped[str] = mapped_column(
        String,
        ForeignKey("analyses.id", ondelete="CASCADE"),
        nullable=False,
        index=True
    )
    severity: Mapped[Optional[str]] = mapped_column(
        String,
        nullable=True
    )
    title: Mapped[Optional[str]] = mapped_column(
        String,
        nullable=True
    )
    description: Mapped[Optional[str]] = mapped_column(
        Text,
        nullable=True
    )
    
    # Relationships
    analysis: Mapped["Analysis"] = relationship(
        "Analysis",
        back_populates="issues"
    )
    
    def __repr__(self) -> str:
        return f"<Issue(id={self.id}, severity={self.severity}, title={self.title})>"
