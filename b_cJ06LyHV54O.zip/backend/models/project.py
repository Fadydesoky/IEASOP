"""
Project Model
"""

from sqlalchemy import String, ForeignKey
from sqlalchemy.orm import Mapped, mapped_column, relationship
from typing import TYPE_CHECKING, List

from .base import Base, TimestampMixin, generate_uuid

if TYPE_CHECKING:
    from .user import User
    from .analysis import Analysis


class Project(Base, TimestampMixin):
    """Project model matching the existing projects table."""
    
    __tablename__ = "projects"
    
    id: Mapped[str] = mapped_column(
        String,
        primary_key=True,
        default=generate_uuid
    )
    user_id: Mapped[str] = mapped_column(
        String,
        ForeignKey("users.id", ondelete="CASCADE"),
        nullable=False,
        index=True
    )
    name: Mapped[str] = mapped_column(
        String,
        nullable=False
    )
    
    # Relationships
    user: Mapped["User"] = relationship(
        "User",
        back_populates="projects"
    )
    analyses: Mapped[List["Analysis"]] = relationship(
        "Analysis",
        back_populates="project",
        cascade="all, delete-orphan"
    )
    
    def __repr__(self) -> str:
        return f"<Project(id={self.id}, name={self.name})>"
