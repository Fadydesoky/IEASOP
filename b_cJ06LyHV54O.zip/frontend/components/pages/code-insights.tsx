"use client"

import { useState } from "react"
import { toast } from "sonner"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"
import { Textarea } from "@/components/ui/textarea"
import { Progress } from "@/components/ui/progress"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select"
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table"
import { Spinner } from "@/components/ui/spinner"
import {
  Zap,
  Upload,
  CheckCircle2,
  Info,
  FileCode,
  BarChart3,
  AlertTriangle,
} from "lucide-react"
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  Cell,
} from "recharts"

const placeholderCode = `# Paste your code here to analyze its energy efficiency
# Example: Python, JavaScript, TypeScript, Java, or Go code

def example_function():
    # Your code will be analyzed for energy efficiency
    pass`

interface AnalysisResult {
  energy_score: number
  carbon_footprint: number
  metrics: {
    lines_of_code: number
    cyclomatic_complexity: number
    nested_loop_depth: number
    io_operations: number
    memory_allocations: number
    function_calls: number
    async_operations: number
  }
  hotspots: Array<{
    issue_type: string
    severity: string
    energy_impact: number
    line_start: number
    explanation: string
  }>
  feature_contributions: Record<string, number>
}

export function CodeInsightsPage() {
  const [code, setCode] = useState(placeholderCode)
  const [language, setLanguage] = useState("python")
  const [isAnalyzing, setIsAnalyzing] = useState(false)
  const [result, setResult] = useState<AnalysisResult | null>(null)
  const [error, setError] = useState<string | null>(null)

  const analyzeCode = async () => {
    setIsAnalyzing(true)
    setError(null)
    setResult(null)
    
    try {
      // Call the analyses API to store results in Supabase
      const response = await fetch("/api/analyses", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          code: code,
          language: language,
          cpu_cores: 4.0,
          ram_gb: 8.0,
          execution_time_ms: 1000.0,
        }),
      })
      
      if (!response.ok) {
        const errorData = await response.json().catch(() => ({}))
        throw new Error(errorData.detail || `Analysis failed: ${response.status}`)
      }
      
      const data = await response.json()
      
      // Map the API response to our expected format
      const analysisResult = {
        energy_score: data.prediction?.energy_score ?? data.energy_score ?? 0,
        carbon_footprint: data.prediction?.carbon_footprint ?? data.carbon_footprint ?? 0,
        metrics: data.metrics ?? {
          lines_of_code: 0,
          cyclomatic_complexity: 0,
          nested_loop_depth: 0,
          io_operations: 0,
          memory_allocations: 0,
          function_calls: 0,
          async_operations: 0
        },
        hotspots: data.hotspots ?? [],
        feature_contributions: data.prediction?.feature_contributions ?? data.feature_contributions ?? {}
      }
      setResult(analysisResult)
      toast.success("Analysis Complete", {
        description: `Energy Score: ${analysisResult.energy_score}/100 - ${analysisResult.hotspots.length} hotspot(s) found`
      })
    } catch (err) {
      console.error("[v0] Analysis error:", err)
      const errorMessage = err instanceof Error ? err.message : "Analysis failed"
      setError(errorMessage)
      toast.error("Analysis Failed", {
        description: errorMessage
      })
    } finally {
      setIsAnalyzing(false)
    }
  }

  const getScoreColor = (score: number) => {
    if (score >= 80) return "text-green-500"
    if (score >= 60) return "text-yellow-500"
    return "text-red-500"
  }

  const getSeverityColor = (severity: string) => {
    switch (severity) {
      case "critical": return "destructive"
      case "high": return "default"
      case "medium": return "secondary"
      default: return "outline"
    }
  }

  const featureData = result ? Object.entries(result.feature_contributions)
    .map(([feature, value]) => ({
      feature: feature.replace(/_/g, " "),
      value,
      fill: value > 0 ? "hsl(var(--destructive))" : "hsl(var(--primary))"
    }))
    .sort((a, b) => Math.abs(b.value) - Math.abs(a.value)) : []

  return (
    <div className="space-y-6">
      {/* Code Input Section */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <FileCode className="h-5 w-5" />
            Code Analysis
          </CardTitle>
          <CardDescription>
            Paste your code to analyze its energy efficiency
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex items-center gap-4">
            <Select value={language} onValueChange={setLanguage}>
              <SelectTrigger className="w-[180px]">
                <SelectValue placeholder="Language" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="python">Python</SelectItem>
                <SelectItem value="javascript">JavaScript</SelectItem>
                <SelectItem value="typescript">TypeScript</SelectItem>
                <SelectItem value="java">Java</SelectItem>
                <SelectItem value="go">Go</SelectItem>
              </SelectContent>
            </Select>
            <Button variant="outline" size="sm">
              <Upload className="mr-2 h-4 w-4" />
              Upload File
            </Button>
          </div>
          
          <Textarea
            value={code}
            onChange={(e) => setCode(e.target.value)}
            className="font-mono text-sm min-h-[300px]"
            placeholder="Paste your code here..."
          />
          
          <Button onClick={analyzeCode} disabled={isAnalyzing || !code.trim()}>
            {isAnalyzing ? (
              <>
                <Spinner className="mr-2 h-4 w-4" />
                Analyzing...
              </>
            ) : (
              <>
                <Zap className="mr-2 h-4 w-4" />
                Analyze Code
              </>
            )}
          </Button>
        </CardContent>
      </Card>

      {/* Error Alert */}
      {error && (
        <Alert variant="destructive">
          <Info className="h-4 w-4" />
          <AlertTitle>Analysis Error</AlertTitle>
          <AlertDescription>
            {error}. Please check your code and try again.
          </AlertDescription>
        </Alert>
      )}

      {/* Results Section */}
      {result && (
        <>
          {/* Score Cards */}
          <div className="grid gap-4 md:grid-cols-3">
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium">Energy Score</CardTitle>
              </CardHeader>
              <CardContent>
                <div className={`text-3xl font-bold ${getScoreColor(result.energy_score)}`}>
                  {result.energy_score}/100
                </div>
                <Progress value={result.energy_score} className="mt-2" />
                <p className="mt-2 text-xs text-muted-foreground">
                  {result.energy_score >= 80 ? "Excellent efficiency" :
                   result.energy_score >= 60 ? "Good, but room for improvement" :
                   "Needs optimization"}
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium">Carbon Footprint</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-3xl font-bold">
                  {(result.carbon_footprint * 1000).toFixed(2)}g
                </div>
                <p className="mt-2 text-xs text-muted-foreground">
                  CO2 equivalent per execution
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium">Issues Found</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-3xl font-bold">{result.hotspots.length}</div>
                <div className="mt-2 flex gap-2">
                  {result.hotspots.filter(h => h.severity === "critical").length > 0 && (
                    <Badge variant="destructive">
                      {result.hotspots.filter(h => h.severity === "critical").length} Critical
                    </Badge>
                  )}
                  {result.hotspots.filter(h => h.severity === "high").length > 0 && (
                    <Badge>
                      {result.hotspots.filter(h => h.severity === "high").length} High
                    </Badge>
                  )}
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Detailed Analysis */}
          <Tabs defaultValue="hotspots">
            <TabsList>
              <TabsTrigger value="hotspots">
                <AlertTriangle className="mr-2 h-4 w-4" />
                Hotspots
              </TabsTrigger>
              <TabsTrigger value="metrics">
                <BarChart3 className="mr-2 h-4 w-4" />
                Metrics
              </TabsTrigger>
              <TabsTrigger value="shap">
                <Info className="mr-2 h-4 w-4" />
                SHAP Explanation
              </TabsTrigger>
            </TabsList>

            <TabsContent value="hotspots" className="mt-4">
              <Card>
                <CardHeader>
                  <CardTitle>Energy Hotspots</CardTitle>
                  <CardDescription>
                    Code sections with highest energy impact
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Issue</TableHead>
                        <TableHead>Severity</TableHead>
                        <TableHead>Line</TableHead>
                        <TableHead>Impact</TableHead>
                        <TableHead>Explanation</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {result.hotspots.map((hotspot, i) => (
                        <TableRow key={i}>
                          <TableCell className="font-medium">
                            {hotspot.issue_type.replace(/_/g, " ")}
                          </TableCell>
                          <TableCell>
                            <Badge variant={getSeverityColor(hotspot.severity)}>
                              {hotspot.severity}
                            </Badge>
                          </TableCell>
                          <TableCell>Line {hotspot.line_start}</TableCell>
                          <TableCell>
                            <div className="flex items-center gap-2">
                              <Progress value={hotspot.energy_impact} className="w-16 h-2" />
                              <span className="text-sm">{hotspot.energy_impact}%</span>
                            </div>
                          </TableCell>
                          <TableCell className="max-w-[300px] text-sm text-muted-foreground">
                            {hotspot.explanation}
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="metrics" className="mt-4">
              <Card>
                <CardHeader>
                  <CardTitle>Code Metrics</CardTitle>
                  <CardDescription>
                    Extracted features from your code
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
                    {Object.entries(result.metrics).map(([key, value]) => (
                      <div key={key} className="rounded-lg border p-4">
                        <p className="text-sm text-muted-foreground">
                          {key.replace(/_/g, " ")}
                        </p>
                        <p className="text-2xl font-bold">{value}</p>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="shap" className="mt-4">
              <Card>
                <CardHeader>
                  <CardTitle>SHAP Feature Contributions</CardTitle>
                  <CardDescription>
                    How each feature impacts your energy score (positive = worse, negative = better)
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="h-[400px]">
                    <ResponsiveContainer width="100%" height="100%">
                      <BarChart data={featureData} layout="vertical">
                        <CartesianGrid strokeDasharray="3 3" className="stroke-muted" horizontal={false} />
                        <XAxis type="number" className="text-xs" />
                        <YAxis dataKey="feature" type="category" width={130} className="text-xs" />
                        <Tooltip
                          contentStyle={{
                            backgroundColor: "hsl(var(--card))",
                            border: "1px solid hsl(var(--border))",
                            borderRadius: "var(--radius)",
                          }}
                          formatter={(value: number) => [
                            `${value > 0 ? "+" : ""}${value.toFixed(2)}`,
                            "Impact"
                          ]}
                        />
                        <Bar dataKey="value" radius={[0, 4, 4, 0]}>
                          {featureData.map((entry, index) => (
                            <Cell key={index} fill={entry.fill} />
                          ))}
                        </Bar>
                      </BarChart>
                    </ResponsiveContainer>
                  </div>
                  <div className="mt-4 flex items-center justify-center gap-6 text-sm">
                    <div className="flex items-center gap-2">
                      <div className="h-3 w-3 rounded bg-primary" />
                      <span>Improves efficiency</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <div className="h-3 w-3 rounded bg-destructive" />
                      <span>Reduces efficiency</span>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </>
      )}
    </div>
  )
}
