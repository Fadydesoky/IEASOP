"use client"

import {
  LayoutDashboard,
  Code2,
  FlaskConical,
  Lightbulb,
  GitBranch,
  Settings,
  Zap,
  Leaf,
} from "lucide-react"

import {
  Sidebar,
  SidebarContent,
  SidebarFooter,
  SidebarGroup,
  SidebarGroupContent,
  SidebarGroupLabel,
  SidebarHeader,
  SidebarMenu,
  SidebarMenuButton,
  SidebarMenuItem,
} from "@/components/ui/sidebar"
import { ModeToggle } from "@/components/mode-toggle"
import type { PageType } from "@/app/page"

interface AppSidebarProps {
  currentPage: PageType
  onNavigate: (page: PageType) => void
}

const mainNavItems = [
  {
    title: "Dashboard",
    page: "overview" as PageType,
    icon: LayoutDashboard,
  },
  {
    title: "Code Insights",
    page: "code-insights" as PageType,
    icon: Code2,
  },
  {
    title: "Simulation Lab",
    page: "simulation-lab" as PageType,
    icon: FlaskConical,
  },
  {
    title: "Recommendations",
    page: "recommendations" as PageType,
    icon: Lightbulb,
  },
]

const integrationItems = [
  {
    title: "CI/CD Integration",
    page: "cicd" as PageType,
    icon: GitBranch,
  },
  {
    title: "Settings",
    page: "settings" as PageType,
    icon: Settings,
  },
]

export function AppSidebar({ currentPage, onNavigate }: AppSidebarProps) {
  return (
    <Sidebar>
      <SidebarHeader className="border-b px-4 py-4">
        <div className="flex items-center gap-2">
          <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-primary text-primary-foreground">
            <Zap className="h-4 w-4" />
          </div>
          <div className="flex flex-col">
            <span className="text-sm font-semibold">IEASOP</span>
            <span className="text-xs text-muted-foreground">Energy Optimizer</span>
          </div>
        </div>
      </SidebarHeader>
      <SidebarContent>
        <SidebarGroup>
          <SidebarGroupLabel>Analysis</SidebarGroupLabel>
          <SidebarGroupContent>
            <SidebarMenu>
              {mainNavItems.map((item) => (
                <SidebarMenuItem key={item.page}>
                  <SidebarMenuButton
                    onClick={() => onNavigate(item.page)}
                    isActive={currentPage === item.page}
                    className="cursor-pointer"
                  >
                    <item.icon className="h-4 w-4" />
                    <span>{item.title}</span>
                  </SidebarMenuButton>
                </SidebarMenuItem>
              ))}
            </SidebarMenu>
          </SidebarGroupContent>
        </SidebarGroup>
        <SidebarGroup>
          <SidebarGroupLabel>Integration</SidebarGroupLabel>
          <SidebarGroupContent>
            <SidebarMenu>
              {integrationItems.map((item) => (
                <SidebarMenuItem key={item.page}>
                  <SidebarMenuButton
                    onClick={() => onNavigate(item.page)}
                    isActive={currentPage === item.page}
                    className="cursor-pointer"
                  >
                    <item.icon className="h-4 w-4" />
                    <span>{item.title}</span>
                  </SidebarMenuButton>
                </SidebarMenuItem>
              ))}
            </SidebarMenu>
          </SidebarGroupContent>
        </SidebarGroup>
      </SidebarContent>
      <SidebarFooter className="border-t p-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2 text-xs text-muted-foreground">
            <Leaf className="h-3 w-3 text-primary" />
            <span>Green Software</span>
          </div>
          <ModeToggle />
        </div>
      </SidebarFooter>
    </Sidebar>
  )
}
