import { createAdminClient } from "@/lib/supabase/admin"
import { NextResponse } from "next/server"

export async function POST(
  request: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params
    const supabase = createAdminClient()
    
    const { data, error } = await supabase
      .from("recommendations")
      .update({ status: "applied" })
      .eq("id", id)
      .select()
      .single()
    
    if (error) {
      console.error("[v0] Error applying recommendation:", error)
      return NextResponse.json(
        { error: error.message },
        { status: 500 }
      )
    }
    
    return NextResponse.json({ success: true, recommendation: data })
  } catch (err) {
    console.error("[v0] Error in POST /api/recommendations/[id]/apply:", err)
    return NextResponse.json(
      { error: "Failed to apply recommendation" },
      { status: 500 }
    )
  }
}
