"""
IEASOP Code Analyzer
Static analysis for extracting energy-relevant features from code
"""

import re
from dataclasses import dataclass
from typing import Optional
from .ml_pipeline import FeatureSet


@dataclass
class CodeMetrics:
    """Metrics extracted from code analysis."""
    lines_of_code: int
    cyclomatic_complexity: float
    nested_loop_depth: int
    io_operations: int
    memory_allocations: int
    function_calls: int
    async_operations: int
    functions: list
    hotspots: list


@dataclass
class FunctionInfo:
    """Information about a function."""
    name: str
    file_path: str
    line_start: int
    line_end: int
    complexity: float
    energy_impact: float
    issues: list[str]


@dataclass
class Hotspot:
    """Energy hotspot in code."""
    file_path: str
    function_name: str
    line_start: int
    line_end: int
    energy_impact: float
    complexity_score: float
    issue_type: str
    severity: str
    code_snippet: str
    explanation: str


def analyze_code(code: str, file_path: str = "unknown.py", language: str = "python") -> CodeMetrics:
    """Analyze code and extract energy-relevant metrics."""
    
    if language.lower() in ["python", "py"]:
        return _analyze_python(code, file_path)
    elif language.lower() in ["javascript", "js", "typescript", "ts"]:
        return _analyze_javascript(code, file_path)
    else:
        return _analyze_generic(code, file_path)


def _analyze_python(code: str, file_path: str) -> CodeMetrics:
    """Analyze Python code."""
    lines = code.split('\n')
    loc = len([l for l in lines if l.strip() and not l.strip().startswith('#')])
    
    # Count nested loops
    nested_loop_depth = 0
    current_depth = 0
    for line in lines:
        if re.search(r'\b(for|while)\b', line):
            current_depth += 1
            nested_loop_depth = max(nested_loop_depth, current_depth)
        # Simple heuristic for depth tracking
        indent = len(line) - len(line.lstrip())
        if indent == 0 and current_depth > 0:
            current_depth = 0
    
    # Count IO operations
    io_patterns = [
        r'\bopen\s*\(',
        r'\.read\s*\(',
        r'\.write\s*\(',
        r'\bprint\s*\(',
        r'\.send\s*\(',
        r'\.recv\s*\(',
        r'requests\.(get|post|put|delete)',
        r'urllib',
        r'\.execute\s*\(',  # DB operations
    ]
    io_operations = sum(len(re.findall(p, code, re.IGNORECASE)) for p in io_patterns)
    
    # Count memory allocations
    memory_patterns = [
        r'\[\s*\]',  # Empty list
        r'\{\s*\}',  # Empty dict
        r'\blist\s*\(',
        r'\bdict\s*\(',
        r'\bset\s*\(',
        r'\.append\s*\(',
        r'\.extend\s*\(',
        r'\bcopy\s*\(',
        r'\.copy\s*\(',
        r'np\.zeros',
        r'np\.ones',
        r'np\.array',
        r'pd\.DataFrame',
    ]
    memory_allocations = sum(len(re.findall(p, code)) for p in memory_patterns)
    
    # Count function calls
    function_calls = len(re.findall(r'\b\w+\s*\(', code))
    
    # Count async operations
    async_patterns = [
        r'\basync\s+def\b',
        r'\bawait\b',
        r'asyncio\.',
        r'\.create_task\s*\(',
        r'\.gather\s*\(',
    ]
    async_operations = sum(len(re.findall(p, code)) for p in async_patterns)
    
    # Calculate cyclomatic complexity (simplified)
    decision_patterns = [
        r'\bif\b',
        r'\belif\b',
        r'\bfor\b',
        r'\bwhile\b',
        r'\band\b',
        r'\bor\b',
        r'\btry\b',
        r'\bexcept\b',
    ]
    complexity = 1 + sum(len(re.findall(p, code)) for p in decision_patterns)
    
    # Extract functions
    functions = []
    function_pattern = r'def\s+(\w+)\s*\([^)]*\):'
    for match in re.finditer(function_pattern, code):
        func_name = match.group(1)
        line_start = code[:match.start()].count('\n') + 1
        
        # Find function end (simplified - looks for next function or end)
        func_code = code[match.start():]
        next_func = re.search(r'\ndef\s+\w+\s*\(', func_code[10:])
        if next_func:
            line_end = line_start + func_code[:next_func.start() + 10].count('\n')
        else:
            line_end = line_start + func_code.count('\n')
        
        func_complexity = _estimate_function_complexity(func_code.split('\n')[:line_end - line_start + 1])
        
        functions.append(FunctionInfo(
            name=func_name,
            file_path=file_path,
            line_start=line_start,
            line_end=line_end,
            complexity=func_complexity,
            energy_impact=_estimate_energy_impact(func_complexity, nested_loop_depth, io_operations),
            issues=_detect_issues(func_code[:500])
        ))
    
    # Detect hotspots
    hotspots = _detect_hotspots(code, file_path, functions)
    
    return CodeMetrics(
        lines_of_code=loc,
        cyclomatic_complexity=complexity,
        nested_loop_depth=nested_loop_depth,
        io_operations=io_operations,
        memory_allocations=memory_allocations,
        function_calls=function_calls,
        async_operations=async_operations,
        functions=[f.__dict__ for f in functions],
        hotspots=[h.__dict__ for h in hotspots]
    )


def _analyze_javascript(code: str, file_path: str) -> CodeMetrics:
    """Analyze JavaScript/TypeScript code."""
    lines = code.split('\n')
    loc = len([l for l in lines if l.strip() and not l.strip().startswith('//')])
    
    # Count nested loops
    nested_loop_depth = 0
    current_depth = 0
    for line in lines:
        if re.search(r'\b(for|while|do)\b', line):
            current_depth += 1
            nested_loop_depth = max(nested_loop_depth, current_depth)
        if '{' in line:
            current_depth += line.count('{')
        if '}' in line:
            current_depth = max(0, current_depth - line.count('}'))
    
    # Count IO operations
    io_patterns = [
        r'\bfetch\s*\(',
        r'\.json\s*\(',
        r'console\.(log|error|warn)',
        r'fs\.(read|write)',
        r'\.send\s*\(',
        r'axios\.',
        r'XMLHttpRequest',
    ]
    io_operations = sum(len(re.findall(p, code, re.IGNORECASE)) for p in io_patterns)
    
    # Count memory allocations
    memory_patterns = [
        r'\[\s*\]',
        r'\{\s*\}',
        r'new\s+Array',
        r'new\s+Object',
        r'new\s+Map',
        r'new\s+Set',
        r'\.push\s*\(',
        r'\.concat\s*\(',
        r'\.slice\s*\(',
        r'\.map\s*\(',
        r'\.filter\s*\(',
        r'\.reduce\s*\(',
    ]
    memory_allocations = sum(len(re.findall(p, code)) for p in memory_patterns)
    
    # Count function calls
    function_calls = len(re.findall(r'\b\w+\s*\(', code))
    
    # Count async operations
    async_patterns = [
        r'\basync\s+function\b',
        r'\basync\s*\(',
        r'\bawait\b',
        r'Promise\.',
        r'\.then\s*\(',
        r'\.catch\s*\(',
    ]
    async_operations = sum(len(re.findall(p, code)) for p in async_patterns)
    
    # Calculate cyclomatic complexity
    decision_patterns = [
        r'\bif\b',
        r'\belse\s+if\b',
        r'\bfor\b',
        r'\bwhile\b',
        r'\bswitch\b',
        r'\bcase\b',
        r'\?\s*:',  # Ternary
        r'&&',
        r'\|\|',
        r'\btry\b',
        r'\bcatch\b',
    ]
    complexity = 1 + sum(len(re.findall(p, code)) for p in decision_patterns)
    
    return CodeMetrics(
        lines_of_code=loc,
        cyclomatic_complexity=complexity,
        nested_loop_depth=nested_loop_depth,
        io_operations=io_operations,
        memory_allocations=memory_allocations,
        function_calls=function_calls,
        async_operations=async_operations,
        functions=[],
        hotspots=[]
    )


def _analyze_generic(code: str, file_path: str) -> CodeMetrics:
    """Analyze code with language-agnostic patterns."""
    lines = code.split('\n')
    loc = len([l for l in lines if l.strip()])
    
    return CodeMetrics(
        lines_of_code=loc,
        cyclomatic_complexity=loc / 10,
        nested_loop_depth=2,
        io_operations=len(re.findall(r'(read|write|print|send|recv)', code, re.IGNORECASE)),
        memory_allocations=len(re.findall(r'(new|alloc|malloc|create)', code, re.IGNORECASE)),
        function_calls=len(re.findall(r'\w+\s*\(', code)),
        async_operations=len(re.findall(r'(async|await|promise|thread)', code, re.IGNORECASE)),
        functions=[],
        hotspots=[]
    )


def _estimate_function_complexity(lines: list) -> float:
    """Estimate complexity of a function."""
    code = '\n'.join(lines)
    decision_points = len(re.findall(r'\b(if|elif|for|while|and|or|try|except)\b', code))
    return 1 + decision_points


def _estimate_energy_impact(complexity: float, loop_depth: int, io_ops: int) -> float:
    """Estimate energy impact score (0-100)."""
    impact = (complexity * 2 + loop_depth * 15 + io_ops * 5) / 3
    return min(100, max(0, impact))


def _detect_issues(code: str) -> list[str]:
    """Detect potential energy issues in code."""
    issues = []
    
    # Check for nested loops
    if re.search(r'for.*:\s*\n.*for.*:', code):
        issues.append("nested_loops")
    
    # Check for blocking IO
    if re.search(r'\btime\.sleep\b', code):
        issues.append("blocking_sleep")
    
    # Check for inefficient string concatenation
    if re.search(r'\+=\s*["\']', code):
        issues.append("string_concatenation")
    
    # Check for global variable access in loops
    if re.search(r'global\s+\w+', code):
        issues.append("global_variable")
    
    return issues


def _detect_hotspots(code: str, file_path: str, functions: list) -> list[Hotspot]:
    """Detect energy hotspots in code."""
    hotspots = []
    
    # Check for nested loops
    nested_loop_match = re.search(r'(for\s+.*:\s*\n\s+.*for\s+.*:)', code)
    if nested_loop_match:
        line_start = code[:nested_loop_match.start()].count('\n') + 1
        hotspots.append(Hotspot(
            file_path=file_path,
            function_name="",
            line_start=line_start,
            line_end=line_start + 5,
            energy_impact=35.0,
            complexity_score=25.0,
            issue_type="nested_loops",
            severity="high",
            code_snippet=nested_loop_match.group(0)[:200],
            explanation="Nested loops increase time complexity exponentially. Consider using vectorized operations or optimized algorithms."
        ))
    
    # Check for synchronous IO in loops
    sync_io_match = re.search(r'(for\s+.*:\s*\n[^\n]*(?:open|read|write|requests)[^\n]*)', code)
    if sync_io_match:
        line_start = code[:sync_io_match.start()].count('\n') + 1
        hotspots.append(Hotspot(
            file_path=file_path,
            function_name="",
            line_start=line_start,
            line_end=line_start + 3,
            energy_impact=45.0,
            complexity_score=20.0,
            issue_type="blocking_io_in_loop",
            severity="critical",
            code_snippet=sync_io_match.group(0)[:200],
            explanation="Synchronous IO operations inside loops cause significant energy waste. Use batch operations or async IO."
        ))
    
    # Check for repeated memory allocations in loops
    mem_alloc_match = re.search(r'(for\s+.*:\s*\n[^\n]*(?:\.append|list\(|dict\(|\[\]|\{\})[^\n]*)', code)
    if mem_alloc_match:
        line_start = code[:mem_alloc_match.start()].count('\n') + 1
        hotspots.append(Hotspot(
            file_path=file_path,
            function_name="",
            line_start=line_start,
            line_end=line_start + 3,
            energy_impact=25.0,
            complexity_score=15.0,
            issue_type="memory_allocation_in_loop",
            severity="medium",
            code_snippet=mem_alloc_match.group(0)[:200],
            explanation="Creating new objects in loops increases memory pressure and GC overhead. Pre-allocate when possible."
        ))
    
    return hotspots


def extract_features(
    code_metrics: CodeMetrics,
    cpu_cores: float = 4.0,
    ram_gb: float = 8.0,
    execution_time_ms: float = 1000.0
) -> FeatureSet:
    """Convert code metrics to ML feature set."""
    return FeatureSet(
        cpu_cores=cpu_cores,
        ram_gb=ram_gb,
        execution_time_ms=execution_time_ms,
        lines_of_code=code_metrics.lines_of_code,
        cyclomatic_complexity=code_metrics.cyclomatic_complexity,
        nested_loop_depth=code_metrics.nested_loop_depth,
        io_operations=code_metrics.io_operations,
        memory_allocations=code_metrics.memory_allocations,
        function_calls=code_metrics.function_calls,
        async_operations=code_metrics.async_operations
    )
