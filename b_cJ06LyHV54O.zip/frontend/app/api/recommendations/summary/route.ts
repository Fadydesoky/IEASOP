import { createAdminClient } from "@/lib/supabase/admin"
import { NextResponse } from "next/server"

export async function GET() {
  try {
    const supabase = createAdminClient()
    
    // Count recommendations by status
    const { data: recommendations, error } = await supabase
      .from("recommendations")
      .select("status")
    
    if (error) {
      console.error("[v0] Error fetching recommendations:", error)
      return NextResponse.json(
        { error: error.message },
        { status: 500 }
      )
    }
    
    // Calculate counts by status
    const pending = recommendations?.filter(r => r.status === "pending").length ?? 0
    const applied = recommendations?.filter(r => r.status === "applied").length ?? 0
    const dismissed = recommendations?.filter(r => r.status === "dismissed").length ?? 0
    const total = recommendations?.length ?? 0
    
    return NextResponse.json({
      pending,
      applied,
      dismissed,
      total
    })
  } catch (err) {
    console.error("[v0] Error in GET /api/recommendations/summary:", err)
    return NextResponse.json(
      { error: "Failed to fetch recommendations summary" },
      { status: 500 }
    )
  }
}
