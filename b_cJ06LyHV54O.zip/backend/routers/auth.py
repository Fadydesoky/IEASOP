"""
Authentication Router
Handles user authentication and profile management
Works in lite mode without database
"""

from fastapi import APIRouter, HTTPException, Header
from pydantic import BaseModel
from typing import Optional
import secrets
import hashlib
from db import get_client, is_db_available

router = APIRouter()

# Demo user for lite mode
_DEMO_USER = {
    "id": "demo-user-001",
    "email": "demo@ieasop.dev",
    "full_name": "Demo User",
    "avatar_url": None,
    "subscription_tier": "free",
    "api_key": "ieasop_demo_" + hashlib.md5(b"demo").hexdigest()[:24]
}


class UserProfile(BaseModel):
    """User profile response model."""
    id: str
    email: Optional[str] = None
    full_name: Optional[str] = None
    avatar_url: Optional[str] = None
    subscription_tier: str = "free"
    api_key: Optional[str] = None


class MockUser:
    """Mock user object for lite mode."""
    def __init__(self, data: dict):
        self.id = data["id"]
        self.email = data.get("email")


async def get_current_user(authorization: str = Header(None)) -> MockUser:
    """Extract and validate user from JWT token or API key."""
    # Allow demo mode without auth
    if not authorization:
        if not is_db_available():
            return MockUser(_DEMO_USER)
        raise HTTPException(status_code=401, detail="Missing authorization header")
    
    token = authorization.replace("Bearer ", "").strip()
    
    # Check for API key auth (for CLI)
    if token.startswith("ieasop_"):
        client = await get_client()
        result = await client.table("profiles").select("*").eq("api_key", token).single().execute()
        if result.data:
            return MockUser(result.data)
        # In demo mode, accept demo key
        if not is_db_available() and token == _DEMO_USER["api_key"]:
            return MockUser(_DEMO_USER)
        raise HTTPException(status_code=401, detail="Invalid API key")
    
    # JWT token auth
    if is_db_available():
        client = await get_client()
        try:
            user_response = await client.auth.get_user(token)
            if user_response and user_response.user:
                return MockUser({"id": user_response.user.id, "email": user_response.user.email})
        except Exception:
            pass
    
    # Fall back to demo user in lite mode
    if not is_db_available():
        return MockUser(_DEMO_USER)
    
    raise HTTPException(status_code=401, detail="Invalid token")


@router.get("/me", response_model=UserProfile)
async def get_profile(authorization: str = Header(None)):
    """Get current user's profile."""
    user = await get_current_user(authorization)
    
    if not is_db_available():
        return UserProfile(**_DEMO_USER)
    
    client = await get_client()
    result = await client.table("profiles").select("*").eq("id", user.id).single().execute()
    
    if not result.data:
        # Return demo profile if not found
        return UserProfile(id=user.id, email=user.email)
    
    return UserProfile(**result.data)


@router.get("/api-key")
async def get_api_key(authorization: str = Header(None)):
    """Get user's API key for CLI authentication."""
    user = await get_current_user(authorization)
    
    if not is_db_available():
        return {"api_key": _DEMO_USER["api_key"]}
    
    client = await get_client()
    result = await client.table("profiles").select("api_key").eq("id", user.id).single().execute()
    
    if not result.data or not result.data.get("api_key"):
        # Generate one on the fly
        return {"api_key": f"ieasop_{secrets.token_hex(24)}"}
    
    return {"api_key": result.data.get("api_key")}


@router.post("/regenerate-api-key")
async def regenerate_api_key(authorization: str = Header(None)):
    """Regenerate user's API key."""
    user = await get_current_user(authorization)
    new_key = f"ieasop_{secrets.token_hex(24)}"
    
    if not is_db_available():
        return {"api_key": new_key}
    
    client = await get_client()
    await client.table("profiles").update({"api_key": new_key}).eq("id", user.id).execute()
    
    return {"api_key": new_key}


@router.get("/status")
async def auth_status():
    """Get authentication system status."""
    return {
        "db_available": is_db_available(),
        "mode": "full" if is_db_available() else "demo",
        "demo_api_key": None if is_db_available() else _DEMO_USER["api_key"]
    }
