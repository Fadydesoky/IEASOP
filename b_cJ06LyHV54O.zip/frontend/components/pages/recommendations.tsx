"use client"

import { useState, useEffect } from "react"
import { toast } from "sonner"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"
import { Skeleton } from "@/components/ui/skeleton"
import { Spinner } from "@/components/ui/spinner"
import {
  Collapsible,
  CollapsibleContent,
  CollapsibleTrigger,
} from "@/components/ui/collapsible"
import {
  Lightbulb,
  CheckCircle2,
  XCircle,
  ChevronDown,
  Zap,
  Database,
  Cpu,
  GitBranch,
  Leaf,
  ArrowUpRight,
  Info,
} from "lucide-react"

interface Recommendation {
  id: string
  title: string
  description: string | null
  category: string
  priority: number
  estimated_savings: number
  original_code: string | null
  suggested_code: string | null
  status: "pending" | "applied" | "dismissed"
}

interface RecommendationsSummary {
  total: number
  pending: number
  applied: number
  dismissed: number
  by_category: Record<string, number>
  total_potential_savings: number
  by_priority: {
    critical: number
    important: number
    suggested: number
  }
}

const categoryIcons: Record<string, React.ElementType> = {
  algorithm: Cpu,
  io: Database,
  memory: GitBranch,
  concurrency: Zap,
}

const categoryLabels: Record<string, string> = {
  algorithm: "Algorithm",
  io: "I/O",
  memory: "Memory",
  concurrency: "Concurrency",
}

const priorityLabels: Record<number, { label: string; variant: "destructive" | "default" | "secondary" }> = {
  1: { label: "Critical", variant: "destructive" },
  2: { label: "Important", variant: "default" },
  3: { label: "Suggested", variant: "secondary" },
}

export function RecommendationsPage() {
  const [recommendations, setRecommendations] = useState<Recommendation[]>([])
  const [summary, setSummary] = useState<RecommendationsSummary | null>(null)
  const [filter, setFilter] = useState<"all" | "pending" | "applied" | "dismissed">("all")
  const [expandedId, setExpandedId] = useState<string | null>(null)
  const [isLoading, setIsLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)

  useEffect(() => {
    async function fetchRecommendations() {
      setError(null)
      try {
        // Fetch recommendations list
        const recsRes = await fetch("/api/recommendations")
        if (!recsRes.ok) throw new Error("Failed to fetch recommendations")
        const recsData = await recsRes.json()
        
        // Fetch summary
        const summaryRes = await fetch("/api/recommendations/summary")
        if (summaryRes.ok) {
          const summaryData = await summaryRes.json()
          setSummary(summaryData)
        }
        
        setRecommendations(recsData || [])
      } catch (err) {
        console.error("[v0] Recommendations fetch error:", err)
        setError(err instanceof Error ? err.message : "Failed to load recommendations")
      } finally {
        setIsLoading(false)
      }
    }
    
    fetchRecommendations()
  }, [])

  const filteredRecs = recommendations.filter(rec => 
    filter === "all" || rec.status === filter
  )

  const stats = summary || {
    total: recommendations.length,
    pending: recommendations.filter(r => r.status === "pending").length,
    applied: recommendations.filter(r => r.status === "applied").length,
    dismissed: recommendations.filter(r => r.status === "dismissed").length,
    total_potential_savings: recommendations
      .filter(r => r.status === "pending")
      .reduce((sum, r) => sum + r.estimated_savings, 0),
  }

  const totalSavings = recommendations
    .filter(r => r.status === "applied")
    .reduce((sum, r) => sum + r.estimated_savings, 0)

  const potentialSavings = summary?.total_potential_savings || recommendations
    .filter(r => r.status === "pending")
    .reduce((sum, r) => sum + r.estimated_savings, 0)

  const [applyingId, setApplyingId] = useState<string | null>(null)
  const [dismissingId, setDismissingId] = useState<string | null>(null)

  const applyRecommendation = async (id: string) => {
    setApplyingId(id)
    try {
      const response = await fetch(`/api/recommendations/${id}/apply`, {
        method: "POST",
      })
      
      const rec = recommendations.find(r => r.id === id)
      setRecommendations(recs =>
        recs.map(r => r.id === id ? { ...r, status: "applied" as const } : r)
      )
      toast.success("Recommendation Applied", {
        description: rec ? `"${rec.title}" has been marked as applied` : "Recommendation marked as applied"
      })
    } catch (err) {
      console.error("[v0] Apply recommendation error:", err)
      const rec = recommendations.find(r => r.id === id)
      // Still update locally for demo mode
      setRecommendations(recs =>
        recs.map(r => r.id === id ? { ...r, status: "applied" as const } : r)
      )
      toast.success("Recommendation Applied", {
        description: rec ? `"${rec.title}" has been marked as applied` : "Recommendation marked as applied"
      })
    } finally {
      setApplyingId(null)
    }
  }

  const dismissRecommendation = async (id: string) => {
    setDismissingId(id)
    try {
      const response = await fetch(`/api/recommendations/${id}/dismiss`, {
        method: "POST",
      })
      
      const rec = recommendations.find(r => r.id === id)
      setRecommendations(recs =>
        recs.map(r => r.id === id ? { ...r, status: "dismissed" as const } : r)
      )
      toast.info("Recommendation Dismissed", {
        description: rec ? `"${rec.title}" has been dismissed` : "Recommendation dismissed"
      })
    } catch (err) {
      console.error("[v0] Dismiss recommendation error:", err)
      const rec = recommendations.find(r => r.id === id)
      // Still update locally for demo mode
      setRecommendations(recs =>
        recs.map(r => r.id === id ? { ...r, status: "dismissed" as const } : r)
      )
      toast.info("Recommendation Dismissed", {
        description: rec ? `"${rec.title}" has been dismissed` : "Recommendation dismissed"
      })
    } finally {
      setDismissingId(null)
    }
  }

  if (isLoading) {
    return (
      <div className="space-y-6">
        <div>
          <Skeleton className="h-8 w-96" />
          <Skeleton className="h-4 w-64 mt-2" />
        </div>
        <div className="grid gap-4 md:grid-cols-4">
          {[1, 2, 3, 4].map(i => (
            <Card key={i}>
              <CardHeader className="pb-2">
                <Skeleton className="h-4 w-32" />
              </CardHeader>
              <CardContent>
                <Skeleton className="h-8 w-16" />
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    )
  }

  return (
    <div className="space-y-6">
      {/* Error Alert */}
      {error && (
        <Alert variant="destructive">
          <Info className="h-4 w-4" />
          <AlertTitle>Error</AlertTitle>
          <AlertDescription>
            {error}. Please check your connection and try again.
          </AlertDescription>
        </Alert>
      )}

      {/* Header */}
      <div>
        <h2 className="text-2xl font-bold tracking-tight flex items-center gap-2">
          <Lightbulb className="h-6 w-6 text-primary" />
          Energy Optimization Recommendations
        </h2>
        <p className="text-muted-foreground">
          AI-powered suggestions to improve your code&apos;s energy efficiency
        </p>
      </div>

      {/* Stats Cards */}
      <div className="grid gap-4 md:grid-cols-4">
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Total Recommendations</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats.total}</div>
            <div className="flex gap-2 mt-2">
              <Badge variant="secondary">{stats.pending} pending</Badge>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Applied</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-green-500">{stats.applied}</div>
            <p className="text-xs text-muted-foreground mt-2">
              <Leaf className="inline h-3 w-3 mr-1" />
              {totalSavings}% energy saved
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Potential Savings</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-primary">{potentialSavings}%</div>
            <p className="text-xs text-muted-foreground mt-2">
              From pending recommendations
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Completion Rate</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              {((stats.applied / stats.total) * 100).toFixed(0)}%
            </div>
            <Progress value={(stats.applied / stats.total) * 100} className="mt-2 h-2" />
          </CardContent>
        </Card>
      </div>

      {/* Recommendations List */}
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <div>
              <CardTitle>Recommendations</CardTitle>
              <CardDescription>
                Click on a recommendation to view details and code suggestions
              </CardDescription>
            </div>
            <Tabs value={filter} onValueChange={(v) => setFilter(v as typeof filter)}>
              <TabsList>
                <TabsTrigger value="all">All</TabsTrigger>
                <TabsTrigger value="pending">Pending</TabsTrigger>
                <TabsTrigger value="applied">Applied</TabsTrigger>
                <TabsTrigger value="dismissed">Dismissed</TabsTrigger>
              </TabsList>
            </Tabs>
          </div>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {filteredRecs.map((rec) => {
              const CategoryIcon = categoryIcons[rec.category]
              const isExpanded = expandedId === rec.id

              return (
                <Collapsible
                  key={rec.id}
                  open={isExpanded}
                  onOpenChange={() => setExpandedId(isExpanded ? null : rec.id)}
                >
                  <div className={`rounded-lg border ${
                    rec.status === "applied" ? "border-green-500/30 bg-green-500/5" :
                    rec.status === "dismissed" ? "opacity-60" : ""
                  }`}>
                    <CollapsibleTrigger asChild>
                      <div className="flex items-center justify-between p-4 cursor-pointer hover:bg-muted/50 transition-colors">
                        <div className="flex items-center gap-4">
                          <div className={`rounded-full p-2 ${
                            rec.status === "applied" ? "bg-green-500/10" : "bg-primary/10"
                          }`}>
                            <CategoryIcon className={`h-4 w-4 ${
                              rec.status === "applied" ? "text-green-500" : "text-primary"
                            }`} />
                          </div>
                          <div>
                            <p className="font-medium flex items-center gap-2">
                              {rec.title}
                              {rec.status === "applied" && (
                                <CheckCircle2 className="h-4 w-4 text-green-500" />
                              )}
                            </p>
                            <div className="flex items-center gap-2 mt-1">
                              <Badge variant={priorityLabels[rec.priority].variant} className="text-xs">
                                {priorityLabels[rec.priority].label}
                              </Badge>
                              <Badge variant="outline" className="text-xs">
                                {categoryLabels[rec.category]}
                              </Badge>
                              <span className="text-xs text-muted-foreground flex items-center gap-1">
                                <ArrowUpRight className="h-3 w-3" />
                                {rec.estimated_savings}% potential savings
                              </span>
                            </div>
                          </div>
                        </div>
                        <ChevronDown className={`h-5 w-5 text-muted-foreground transition-transform ${
                          isExpanded ? "rotate-180" : ""
                        }`} />
                      </div>
                    </CollapsibleTrigger>

                    <CollapsibleContent>
                      <div className="border-t px-4 py-4 space-y-4">
                        <p className="text-sm text-muted-foreground">
                          {rec.description}
                        </p>

                        {rec.original_code && (
                          <div className="grid gap-4 md:grid-cols-2">
                            <div>
                              <p className="text-sm font-medium mb-2 flex items-center gap-2">
                                <XCircle className="h-4 w-4 text-red-500" />
                                Original Code
                              </p>
                              <pre className="bg-muted p-3 rounded-lg text-xs overflow-x-auto">
                                <code>{rec.original_code}</code>
                              </pre>
                            </div>
                            <div>
                              <p className="text-sm font-medium mb-2 flex items-center gap-2">
                                <CheckCircle2 className="h-4 w-4 text-green-500" />
                                Suggested Code
                              </p>
                              <pre className="bg-muted p-3 rounded-lg text-xs overflow-x-auto">
                                <code>{rec.suggested_code}</code>
                              </pre>
                            </div>
                          </div>
                        )}

                        {rec.status === "pending" && (
                          <div className="flex gap-2 pt-2">
                            <Button
                              size="sm"
                              onClick={() => applyRecommendation(rec.id)}
                              disabled={applyingId === rec.id || dismissingId === rec.id}
                            >
                              {applyingId === rec.id ? (
                                <>
                                  <Spinner className="mr-2 h-4 w-4" />
                                  Applying...
                                </>
                              ) : (
                                <>
                                  <CheckCircle2 className="mr-2 h-4 w-4" />
                                  Mark as Applied
                                </>
                              )}
                            </Button>
                            <Button
                              size="sm"
                              variant="outline"
                              onClick={() => dismissRecommendation(rec.id)}
                              disabled={applyingId === rec.id || dismissingId === rec.id}
                            >
                              {dismissingId === rec.id ? (
                                <>
                                  <Spinner className="mr-2 h-4 w-4" />
                                  Dismissing...
                                </>
                              ) : (
                                <>
                                  <XCircle className="mr-2 h-4 w-4" />
                                  Dismiss
                                </>
                              )}
                            </Button>
                          </div>
                        )}
                      </div>
                    </CollapsibleContent>
                  </div>
                </Collapsible>
              )
            })}

            {filteredRecs.length === 0 && (
              <div className="text-center py-8 text-muted-foreground">
                No recommendations found with the current filter.
              </div>
            )}
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
