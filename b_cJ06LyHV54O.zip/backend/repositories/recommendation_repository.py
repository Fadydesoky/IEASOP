"""
Recommendation Repository
Database operations for Recommendation entities
"""

from typing import Sequence
from sqlalchemy import select, func
from sqlalchemy.ext.asyncio import AsyncSession

from models.recommendation import Recommendation
from .base import BaseRepository


class RecommendationRepository(BaseRepository[Recommendation]):
    """Repository for Recommendation entity operations."""
    
    def __init__(self, session: AsyncSession) -> None:
        super().__init__(session, Recommendation)
    
    async def get_by_analysis_id(
        self,
        analysis_id: str,
        skip: int = 0,
        limit: int = 100
    ) -> Sequence[Recommendation]:
        """Get all recommendations for a specific analysis."""
        result = await self._session.execute(
            select(Recommendation)
            .where(Recommendation.analysis_id == analysis_id)
            .offset(skip)
            .limit(limit)
        )
        return result.scalars().all()
    
    async def get_by_impact_level(
        self,
        analysis_id: str,
        impact_level: str
    ) -> Sequence[Recommendation]:
        """Get recommendations filtered by impact level."""
        result = await self._session.execute(
            select(Recommendation)
            .where(Recommendation.analysis_id == analysis_id)
            .where(Recommendation.impact_level == impact_level)
        )
        return result.scalars().all()
    
    async def count_by_analysis(self, analysis_id: str) -> int:
        """Count recommendations for a specific analysis."""
        result = await self._session.execute(
            select(func.count())
            .select_from(Recommendation)
            .where(Recommendation.analysis_id == analysis_id)
        )
        return result.scalar_one()
    
    async def create_recommendation(
        self,
        analysis_id: str,
        suggestion: str | None = None,
        impact_level: str | None = None
    ) -> Recommendation:
        """Create a new recommendation for an analysis."""
        recommendation = Recommendation(
            analysis_id=analysis_id,
            suggestion=suggestion,
            impact_level=impact_level
        )
        return await self.create(recommendation)
    
    async def create_many_recommendations(
        self,
        analysis_id: str,
        recommendations_data: list[dict]
    ) -> list[Recommendation]:
        """Create multiple recommendations for an analysis."""
        recommendations = [
            Recommendation(
                analysis_id=analysis_id,
                suggestion=data.get("suggestion"),
                impact_level=data.get("impact_level")
            )
            for data in recommendations_data
        ]
        return await self.create_many(recommendations)
