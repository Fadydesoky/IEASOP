"""
Metric Repository
Database operations for Metric entities
"""

from typing import Sequence
from sqlalchemy import select, func
from sqlalchemy.ext.asyncio import AsyncSession

from models.metric import Metric
from .base import BaseRepository


class MetricRepository(BaseRepository[Metric]):
    """Repository for Metric entity operations."""
    
    def __init__(self, session: AsyncSession) -> None:
        super().__init__(session, Metric)
    
    async def get_by_analysis_id(
        self,
        analysis_id: str,
        skip: int = 0,
        limit: int = 100
    ) -> Sequence[Metric]:
        """Get all metrics for a specific analysis."""
        result = await self._session.execute(
            select(Metric)
            .where(Metric.analysis_id == analysis_id)
            .order_by(Metric.created_at.desc())
            .offset(skip)
            .limit(limit)
        )
        return result.scalars().all()
    
    async def get_latest_by_analysis(self, analysis_id: str) -> Metric | None:
        """Get the most recent metric for an analysis."""
        result = await self._session.execute(
            select(Metric)
            .where(Metric.analysis_id == analysis_id)
            .order_by(Metric.created_at.desc())
            .limit(1)
        )
        return result.scalar_one_or_none()
    
    async def get_averages_by_analysis(self, analysis_id: str) -> dict:
        """Get average metrics for an analysis."""
        result = await self._session.execute(
            select(
                func.avg(Metric.cpu_usage).label("avg_cpu"),
                func.avg(Metric.ram_usage).label("avg_ram"),
                func.avg(Metric.execution_time).label("avg_execution_time"),
                func.avg(Metric.temperature).label("avg_temperature"),
            )
            .where(Metric.analysis_id == analysis_id)
        )
        row = result.one()
        return {
            "avg_cpu_usage": row.avg_cpu,
            "avg_ram_usage": row.avg_ram,
            "avg_execution_time": row.avg_execution_time,
            "avg_temperature": row.avg_temperature,
        }
    
    async def count_by_analysis(self, analysis_id: str) -> int:
        """Count metrics for a specific analysis."""
        result = await self._session.execute(
            select(func.count())
            .select_from(Metric)
            .where(Metric.analysis_id == analysis_id)
        )
        return result.scalar_one()
    
    async def create_metric(
        self,
        analysis_id: str,
        cpu_usage: float | None = None,
        ram_usage: float | None = None,
        execution_time: float | None = None,
        temperature: float | None = None
    ) -> Metric:
        """Create a new metric for an analysis."""
        metric = Metric(
            analysis_id=analysis_id,
            cpu_usage=cpu_usage,
            ram_usage=ram_usage,
            execution_time=execution_time,
            temperature=temperature
        )
        return await self.create(metric)
