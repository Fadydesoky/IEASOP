"""
IEASOP Database Client
Optional Supabase async client - falls back to in-memory storage
"""

import os
from typing import Optional, Any
from datetime import datetime
import uuid

_DB_AVAILABLE = False
_supabase = None

try:
    from supabase import acreate_client, AsyncClient
    _DB_AVAILABLE = True
except ImportError:
    AsyncClient = None
    acreate_client = None

# In-memory storage for lite mode
_memory_store: dict[str, list[dict]] = {
    "profiles": [],
    "projects": [],
    "analyses": [],
    "code_hotspots": [],
    "recommendations": [],
    "energy_metrics": [],
    "ci_cd_integrations": [],
    "pipeline_runs": [],
}


class MockQueryBuilder:
    """Mock query builder for in-memory operations."""
    
    def __init__(self, table_name: str, data: list[dict]):
        self._table = table_name
        self._data = data
        self._filters: list[tuple] = []
        self._select_cols = "*"
        self._order_col = None
        self._order_desc = False
        self._limit_val = None
        self._single = False
    
    def select(self, cols: str = "*"):
        self._select_cols = cols
        return self
    
    def eq(self, col: str, val: Any):
        self._filters.append(("eq", col, val))
        return self
    
    def neq(self, col: str, val: Any):
        self._filters.append(("neq", col, val))
        return self
    
    def gt(self, col: str, val: Any):
        self._filters.append(("gt", col, val))
        return self
    
    def gte(self, col: str, val: Any):
        self._filters.append(("gte", col, val))
        return self
    
    def lt(self, col: str, val: Any):
        self._filters.append(("lt", col, val))
        return self
    
    def lte(self, col: str, val: Any):
        self._filters.append(("lte", col, val))
        return self
    
    def order(self, col: str, desc: bool = False):
        self._order_col = col
        self._order_desc = desc
        return self
    
    def limit(self, val: int):
        self._limit_val = val
        return self
    
    def single(self):
        self._single = True
        return self
    
    def _apply_filters(self, items: list[dict]) -> list[dict]:
        result = items.copy()
        for op, col, val in self._filters:
            if op == "eq":
                result = [r for r in result if r.get(col) == val]
            elif op == "neq":
                result = [r for r in result if r.get(col) != val]
            elif op == "gt":
                result = [r for r in result if r.get(col, 0) > val]
            elif op == "gte":
                result = [r for r in result if r.get(col, 0) >= val]
            elif op == "lt":
                result = [r for r in result if r.get(col, 0) < val]
            elif op == "lte":
                result = [r for r in result if r.get(col, 0) <= val]
        return result
    
    async def execute(self):
        result = self._apply_filters(self._data)
        
        if self._order_col:
            result = sorted(result, key=lambda x: x.get(self._order_col, 0), reverse=self._order_desc)
        
        if self._limit_val:
            result = result[:self._limit_val]
        
        if self._single:
            return MockResponse(result[0] if result else None)
        
        return MockResponse(result)


class MockInsertBuilder:
    """Mock insert builder."""
    
    def __init__(self, table_name: str, store: dict, data: dict | list[dict]):
        self._table = table_name
        self._store = store
        self._data = data if isinstance(data, list) else [data]
    
    async def execute(self):
        results = []
        for item in self._data:
            new_item = {
                "id": item.get("id", str(uuid.uuid4())),
                "created_at": datetime.utcnow().isoformat(),
                **item
            }
            self._store[self._table].append(new_item)
            results.append(new_item)
        return MockResponse(results)


class MockUpdateBuilder:
    """Mock update builder."""
    
    def __init__(self, table_name: str, store: dict, data: dict):
        self._table = table_name
        self._store = store
        self._data = data
        self._filters: list[tuple] = []
    
    def eq(self, col: str, val: Any):
        self._filters.append(("eq", col, val))
        return self
    
    async def execute(self):
        updated = []
        for item in self._store[self._table]:
            match = True
            for op, col, val in self._filters:
                if op == "eq" and item.get(col) != val:
                    match = False
                    break
            if match:
                item.update(self._data)
                item["updated_at"] = datetime.utcnow().isoformat()
                updated.append(item)
        return MockResponse(updated)


class MockDeleteBuilder:
    """Mock delete builder."""
    
    def __init__(self, table_name: str, store: dict):
        self._table = table_name
        self._store = store
        self._filters: list[tuple] = []
    
    def eq(self, col: str, val: Any):
        self._filters.append(("eq", col, val))
        return self
    
    async def execute(self):
        deleted = []
        remaining = []
        for item in self._store[self._table]:
            match = True
            for op, col, val in self._filters:
                if op == "eq" and item.get(col) != val:
                    match = False
                    break
            if match:
                deleted.append(item)
            else:
                remaining.append(item)
        self._store[self._table] = remaining
        return MockResponse(deleted)


class MockResponse:
    """Mock response."""
    def __init__(self, data: Any):
        self.data = data


class MockTable:
    """Mock table interface."""
    
    def __init__(self, table_name: str, store: dict):
        self._table = table_name
        self._store = store
        if table_name not in self._store:
            self._store[table_name] = []
    
    def select(self, cols: str = "*") -> MockQueryBuilder:
        return MockQueryBuilder(self._table, self._store[self._table]).select(cols)
    
    def insert(self, data: dict | list[dict]) -> MockInsertBuilder:
        return MockInsertBuilder(self._table, self._store, data)
    
    def update(self, data: dict) -> MockUpdateBuilder:
        return MockUpdateBuilder(self._table, self._store, data)
    
    def delete(self) -> MockDeleteBuilder:
        return MockDeleteBuilder(self._table, self._store)


class MockClient:
    """Mock Supabase client using in-memory storage."""
    
    def __init__(self, store: dict):
        self._store = store
    
    def table(self, name: str) -> MockTable:
        return MockTable(name, self._store)


async def get_client():
    """Get database client (Supabase or mock)."""
    global _supabase
    
    if _DB_AVAILABLE:
        if _supabase is None:
            url = os.environ.get("SUPABASE_URL", "")
            key = os.environ.get("SUPABASE_ANON_KEY", "")
            if url and key:
                _supabase = await acreate_client(url, key)
                return _supabase
    
    # Fall back to mock client
    return MockClient(_memory_store)


async def get_service_client():
    """Get service client (Supabase or mock)."""
    if _DB_AVAILABLE:
        url = os.environ.get("SUPABASE_URL", "")
        key = os.environ.get("SUPABASE_SERVICE_ROLE_KEY", "")
        if url and key:
            return await acreate_client(url, key)
    
    return MockClient(_memory_store)


def is_db_available() -> bool:
    """Check if real database is available."""
    return _DB_AVAILABLE and bool(os.environ.get("SUPABASE_URL"))
