"use client"

import { useState, useEffect } from "react"
import { toast } from "sonner"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"
import { Skeleton } from "@/components/ui/skeleton"
import {
  Zap,
  Leaf,
  TrendingUp,
  AlertTriangle,
  CheckCircle2,
  ArrowUpRight,
  ArrowDownRight,
  Activity,
  Code2,
  Clock,
} from "lucide-react"
import {
  AreaChart,
  Area,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  BarChart,
  Bar,
} from "recharts"

interface EnergyTrendItem {
  date: string
  score: number
  carbon: number
}

interface ProjectScore {
  name: string
  score: number
}

interface ActivityItem {
  id: number
  type: string
  project: string
  score?: number
  status?: string
  action?: string
  savings?: number
  time: string
  delta?: number
}

interface DashboardData {
  totalScore: number
  carbonSaved: number
  totalAnalyses: number
  activeHotspots: number
  totalProjects: number
  energyTrend: EnergyTrendItem[]
  projectScores: ProjectScore[]
  recentActivity: ActivityItem[]
}

interface OverviewPageProps {
  onNavigate?: (page: "overview" | "code-insights" | "simulation-lab" | "recommendations" | "cicd" | "settings") => void
}

export function OverviewPage({ onNavigate }: OverviewPageProps) {
  const [data, setData] = useState<DashboardData>({
    totalScore: 0,
    carbonSaved: 0,
    totalAnalyses: 0,
    activeHotspots: 0,
    totalProjects: 0,
    energyTrend: [],
    projectScores: [],
    recentActivity: [],
  })
  const [isLoading, setIsLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)

  useEffect(() => {
    async function fetchDashboard() {
      setError(null)
      try {
        // Fetch dashboard summary
        const summaryRes = await fetch("/api/dashboard/summary")
        if (!summaryRes.ok) throw new Error("Failed to fetch dashboard summary")
        const summary = await summaryRes.json()
        
        // Fetch projects for project scores
        let projectScores: ProjectScore[] = []
        const projectsRes = await fetch("/api/projects")
        if (!projectsRes.ok) throw new Error("Failed to fetch projects")
        const projects = await projectsRes.json()
        projectScores = projects
          .filter((p: { latest_energy_score?: number }) => p.latest_energy_score !== null && p.latest_energy_score !== undefined)
          .map((p: { name: string; latest_energy_score: number }) => ({
            name: p.name,
            score: Math.round(p.latest_energy_score)
          }))
          .slice(0, 5)
        
        // Fetch recent analyses for activity
        let recentActivity: ActivityItem[] = []
        const analysesRes = await fetch("/api/analyses?limit=5")
        if (!analysesRes.ok) throw new Error("Failed to fetch analyses")
        const analyses = await analysesRes.json()
        recentActivity = analyses.map((a: { id: string; project_id: string; energy_score: number; created_at: string }, i: number) => ({
          id: i + 1,
          type: "analysis",
          project: a.project_id?.substring(0, 8) || "unknown",
          score: Math.round(a.energy_score || 0),
          time: formatTimeAgo(new Date(a.created_at)),
          delta: 0
        }))
        
        // Fetch recommendations summary
        let activeHotspots = 0
        const recsRes = await fetch("/api/recommendations/summary")
        if (recsRes.ok) {
          const recsSummary = await recsRes.json()
          activeHotspots = recsSummary.pending || 0
        }
        
        // Calculate energy trend from metrics (if available)
        const energyTrend = summary.energy_trend?.length 
          ? summary.energy_trend 
          : []
        
        setData({
          totalScore: Math.round(summary.avg_energy_score || 0),
          carbonSaved: summary.total_carbon_saved || 0,
          totalAnalyses: summary.total_analyses || 0,
          activeHotspots: activeHotspots,
          totalProjects: summary.total_projects || 0,
          energyTrend: energyTrend,
          projectScores: projectScores,
          recentActivity: recentActivity,
        })
      } catch (err) {
        console.error("[v0] Dashboard fetch error:", err)
        const errorMessage = err instanceof Error ? err.message : "Failed to load dashboard data"
        setError(errorMessage)
        toast.error("Failed to load dashboard", {
          description: errorMessage
        })
      } finally {
        setIsLoading(false)
      }
    }
    
    fetchDashboard()
  }, [])
  
  function formatTimeAgo(date: Date): string {
    const now = new Date()
    const diffMs = now.getTime() - date.getTime()
    const diffHours = Math.floor(diffMs / (1000 * 60 * 60))
    const diffDays = Math.floor(diffHours / 24)
    
    if (diffHours < 1) return "just now"
    if (diffHours < 24) return `${diffHours} hour${diffHours > 1 ? 's' : ''} ago`
    if (diffDays < 7) return `${diffDays} day${diffDays > 1 ? 's' : ''} ago`
    return date.toLocaleDateString()
  }

  return (
    <div className="space-y-6">
      {/* Error Alert */}
      {error && !isLoading && (
        <Alert variant="destructive">
          <AlertTriangle className="h-4 w-4" />
          <AlertTitle>Error</AlertTitle>
          <AlertDescription>
            {error}. Please check your connection and try again.
          </AlertDescription>
        </Alert>
      )}

      {/* Header Stats */}
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Energy Score</CardTitle>
            <Zap className="h-4 w-4 text-primary" />
          </CardHeader>
          <CardContent>
            {isLoading ? (
              <Skeleton className="h-8 w-24" />
            ) : (
              <>
                <div className="text-2xl font-bold">{data.totalScore}/100</div>
                <div className="flex items-center text-xs text-muted-foreground">
                  <TrendingUp className="mr-1 h-3 w-3 text-primary" />
                  +5% from last month
                </div>
                <Progress value={data.totalScore} className="mt-2 h-2" />
              </>
            )}
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Carbon Saved</CardTitle>
            <Leaf className="h-4 w-4 text-primary" />
          </CardHeader>
          <CardContent>
            {isLoading ? (
              <Skeleton className="h-8 w-24" />
            ) : (
              <>
                <div className="text-2xl font-bold">{data.carbonSaved} kg</div>
                <p className="text-xs text-muted-foreground">
                  CO2 equivalent this quarter
                </p>
              </>
            )}
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Analyses</CardTitle>
            <Activity className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            {isLoading ? (
              <Skeleton className="h-8 w-24" />
            ) : (
              <>
                <div className="text-2xl font-bold">{data.totalAnalyses}</div>
              <p className="text-xs text-muted-foreground">
                Across {data.totalProjects || 5} projects
              </p>
              </>
            )}
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Active Hotspots</CardTitle>
            <AlertTriangle className="h-4 w-4 text-orange-500" />
          </CardHeader>
          <CardContent>
            {isLoading ? (
              <Skeleton className="h-8 w-24" />
            ) : (
              <>
                <div className="text-2xl font-bold">{data.activeHotspots}</div>
                <p className="text-xs text-muted-foreground">
                  Requiring attention
                </p>
              </>
            )}
          </CardContent>
        </Card>
      </div>

      {/* Charts Row */}
      <div className="grid gap-4 md:grid-cols-2">
        <Card>
          <CardHeader>
            <CardTitle>Energy Score Trend</CardTitle>
            <CardDescription>
              Your overall energy efficiency over time
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="h-[240px]">
              <ResponsiveContainer width="100%" height="100%">
                <AreaChart data={data.energyTrend}>
                  <defs>
                    <linearGradient id="colorScore" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="hsl(var(--primary))" stopOpacity={0.3} />
                      <stop offset="95%" stopColor="hsl(var(--primary))" stopOpacity={0} />
                    </linearGradient>
                  </defs>
                  <CartesianGrid strokeDasharray="3 3" className="stroke-muted" />
                  <XAxis dataKey="date" className="text-xs" />
                  <YAxis domain={[0, 100]} className="text-xs" />
                  <Tooltip
                    contentStyle={{
                      backgroundColor: "hsl(var(--card))",
                      border: "1px solid hsl(var(--border))",
                      borderRadius: "var(--radius)",
                    }}
                  />
                  <Area
                    type="monotone"
                    dataKey="score"
                    stroke="hsl(var(--primary))"
                    fillOpacity={1}
                    fill="url(#colorScore)"
                    strokeWidth={2}
                  />
                </AreaChart>
              </ResponsiveContainer>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Project Scores</CardTitle>
            <CardDescription>
              Energy efficiency by project
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="h-[240px]">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={data.projectScores} layout="vertical">
                  <CartesianGrid strokeDasharray="3 3" className="stroke-muted" horizontal={false} />
                  <XAxis type="number" domain={[0, 100]} className="text-xs" />
                  <YAxis dataKey="name" type="category" width={100} className="text-xs" />
                  <Tooltip
                    contentStyle={{
                      backgroundColor: "hsl(var(--card))",
                      border: "1px solid hsl(var(--border))",
                      borderRadius: "var(--radius)",
                    }}
                  />
                  <Bar
                    dataKey="score"
                    fill="hsl(var(--primary))"
                    radius={[0, 4, 4, 0]}
                  />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Recent Activity */}
      <Card>
        <CardHeader>
          <CardTitle>Recent Activity</CardTitle>
          <CardDescription>
            Latest analyses and optimizations
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {data.recentActivity.map((item) => (
              <div
                key={item.id}
                className="flex items-center justify-between rounded-lg border p-4"
              >
                <div className="flex items-center gap-4">
                  <div className={`rounded-full p-2 ${
                    item.type === "analysis" ? "bg-primary/10" :
                    item.type === "cicd" ? "bg-blue-500/10" :
                    "bg-green-500/10"
                  }`}>
                    {item.type === "analysis" ? (
                      <Code2 className="h-4 w-4 text-primary" />
                    ) : item.type === "cicd" ? (
                      <CheckCircle2 className="h-4 w-4 text-blue-500" />
                    ) : (
                      <Zap className="h-4 w-4 text-green-500" />
                    )}
                  </div>
                  <div>
                    <p className="text-sm font-medium">{item.project}</p>
                    <p className="text-xs text-muted-foreground">
                      {item.type === "analysis" && `Energy Score: ${item.score}`}
                      {item.type === "cicd" && `Pipeline ${item.status}`}
                      {item.type === "recommendation" && `Recommendation ${item.action}`}
                    </p>
                  </div>
                </div>
                <div className="flex items-center gap-4">
                  {item.type === "analysis" && item.delta !== undefined && (
                    <Badge variant={item.delta > 0 ? "default" : "destructive"} className="gap-1">
                      {item.delta > 0 ? (
                        <ArrowUpRight className="h-3 w-3" />
                      ) : (
                        <ArrowDownRight className="h-3 w-3" />
                      )}
                      {item.delta > 0 ? "+" : ""}{item.delta}
                    </Badge>
                  )}
                  {item.type === "recommendation" && item.savings && (
                    <Badge variant="secondary" className="gap-1">
                      <Leaf className="h-3 w-3" />
                      {item.savings}% saved
                    </Badge>
                  )}
                  <div className="flex items-center text-xs text-muted-foreground">
                    <Clock className="mr-1 h-3 w-3" />
                    {item.time}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Quick Actions */}
      <Card>
        <CardHeader>
          <CardTitle>Quick Actions</CardTitle>
        </CardHeader>
        <CardContent className="flex gap-4">
          <Button onClick={() => onNavigate?.("code-insights")}>
            <Code2 className="mr-2 h-4 w-4" />
            New Analysis
          </Button>
          <Button variant="outline" onClick={() => onNavigate?.("simulation-lab")}>
            <Activity className="mr-2 h-4 w-4" />
            Run Simulation
          </Button>
          <Button variant="outline" onClick={() => onNavigate?.("recommendations")}>
            <Leaf className="mr-2 h-4 w-4" />
            View Recommendations
          </Button>
        </CardContent>
      </Card>
    </div>
  )
}
