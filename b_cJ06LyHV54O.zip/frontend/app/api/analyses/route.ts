import { createClient } from "@/lib/supabase/server"
import { createAdminClient } from "@/lib/supabase/admin"
import { NextResponse } from "next/server"

// Demo user ID for unauthenticated analyses
const DEMO_USER_ID = "00000000-0000-0000-0000-000000000001"
const DEMO_PROJECT_ID = "00000000-0000-0000-0000-000000000002"

export async function GET() {
  try {
    // Use admin client to fetch all analyses (including demo ones)
    const supabase = createAdminClient()

    const { data, error } = await supabase
      .from("analyses")
      .select(`
        *,
        code_hotspots (*),
        recommendations (*)
      `)
      .order("created_at", { ascending: false })
      .limit(50)

    if (error) {
      console.error("[v0] Supabase error fetching analyses:", error)
      return NextResponse.json(
        { error: error.message },
        { status: 500 }
      )
    }

    return NextResponse.json(data ?? [])
  } catch (err) {
    console.error("[v0] Error in GET /api/analyses:", err)
    return NextResponse.json(
      { error: "Failed to fetch analyses" },
      { status: 500 }
    )
  }
}

export async function POST(request: Request) {
  try {
    const userSupabase = await createClient()
    const serviceKey = process.env.SUPABASE_SERVICE_ROLE_KEY

    if (!serviceKey) {
      console.error("Missing SUPABASE_SERVICE_ROLE_KEY")
      return NextResponse.json({ error: "Server misconfigured" }, { status: 500 })
    }

    const adminSupabase = createAdminClient()
    const body = await request.json()

    const { code, language, cpu_cores, ram_gb, execution_time_ms, project_id, user_id } = body

    if (!code) {
      return NextResponse.json(
        { error: "Code is required" },
        { status: 400 }
      )
    }

    // Analyze the code to extract metrics
    const metrics = analyzeCode(code, language)

    // Calculate energy score and carbon footprint using metrics
    const energyScore = calculateEnergyScore(metrics)
    const carbonFootprint = calculateCarbonFootprint(metrics, execution_time_ms || 1000, cpu_cores || 4)

    // Detect hotspots
    const hotspots = detectHotspots(code, language)

    // Generate recommendations based on hotspots
    const recommendations = generateRecommendations(hotspots)

    // Get the current user or use demo user
    const { data: { user } } = await userSupabase.auth.getUser()
    let effectiveUserId = user?.id || user_id || null
    let effectiveProjectId = project_id

    // Use admin client to handle demo user setup (bypasses RLS)
    if (!effectiveUserId) {
      // Ensure demo profile exists
      const { data: demoProfile } = await adminSupabase
        .from("profiles")
        .select("id")
        .eq("id", DEMO_USER_ID)
        .single()

      if (!demoProfile) {
        await adminSupabase
          .from("profiles")
          .insert({
            id: DEMO_USER_ID,
            full_name: "Demo User",
            email: "demo@ieasop.local",
            subscription_tier: "free"
          })
      }
      effectiveUserId = DEMO_USER_ID
    }

    // Ensure project exists
    if (!effectiveProjectId) {
      const targetProjectId = effectiveUserId === DEMO_USER_ID ? DEMO_PROJECT_ID : undefined

      // Check for existing project
      const projectQuery = adminSupabase
        .from("projects")
        .select("id")
        .eq("user_id", effectiveUserId)
        .eq("name", "Demo Project")
        .single()

      const { data: existingProject } = await projectQuery

      if (existingProject) {
        effectiveProjectId = existingProject.id
      } else {
        // Create demo project
        const projectInsert: Record<string, unknown> = {
          user_id: effectiveUserId,
          name: "Demo Project",
          description: "Auto-created project for code analysis",
          language: language || "python",
          status: "active"
        }
        if (targetProjectId) {
          projectInsert.id = targetProjectId
        }

        const { data: newProject, error: projectError } = await adminSupabase
          .from("projects")
          .insert(projectInsert)
          .select()
          .single()

        if (projectError) {
          console.error("[v0] Error creating project:", projectError)
        } else {
          effectiveProjectId = newProject?.id
        }
      }
    }

    // Insert the analysis record using admin client (bypasses RLS)
    const analysisData = {
      project_id: effectiveProjectId,
      user_id: effectiveUserId,
      status: "completed",
      energy_score: energyScore,
      carbon_footprint: carbonFootprint,
      total_functions: metrics.function_calls || 1,
      hotspot_count: hotspots.length,
      analysis_type: "quick",
      results: {
        code_snippet: code.substring(0, 500),
        language,
        metrics
      },
      ml_features: metrics,
      started_at: new Date().toISOString(),
      completed_at: new Date().toISOString()
    }

    const { data: analysis, error: analysisError } = await adminSupabase
      .from("analyses")
      .insert(analysisData)
      .select()
      .single()

    if (analysisError) {
      console.error("[v0] Error inserting analysis:", analysisError)
      // Return computed result even if DB insert fails
      return NextResponse.json({
        energy_score: energyScore,
        carbon_footprint: carbonFootprint,
        metrics,
        hotspots,
        recommendations,
        feature_contributions: calculateFeatureContributions(metrics),
        db_error: analysisError.message
      })
    }

    // Insert hotspots
    if (hotspots.length > 0 && analysis) {
      const hotspotsToInsert = hotspots.map(h => ({
        analysis_id: analysis.id,
        file_path: "inline-code",
        function_name: h.function_name || null,
        line_start: h.line_start,
        line_end: h.line_end || h.line_start,
        energy_impact: h.energy_impact,
        complexity_score: h.complexity_score || 50,
        issue_type: h.issue_type,
        severity: h.severity,
        shap_interpretation: h.explanation,
        code_snippet: h.code_snippet
      }))

      const { error: hotspotsError } = await adminSupabase
        .from("code_hotspots")
        .insert(hotspotsToInsert)

      if (hotspotsError) {
        console.error("[v0] Error inserting hotspots:", hotspotsError)
      }
    }

    // Insert recommendations
    if (recommendations.length > 0 && analysis) {
      const recsToInsert = recommendations.map(r => ({
        analysis_id: analysis.id,
        title: r.title,
        description: r.description,
        category: r.category,
        priority: r.priority,
        estimated_savings: r.estimated_savings,
        original_code: r.original_code,
        suggested_code: r.suggested_code,
        status: "pending"
      }))

      const { error: recsError } = await adminSupabase
        .from("recommendations")
        .insert(recsToInsert)

      if (recsError) {
        console.error("[v0] Error inserting recommendations:", recsError)
      }
    }

    // Insert energy metrics for tracking
    if (effectiveProjectId) {
      const { error: metricsError } = await adminSupabase
        .from("energy_metrics")
        .insert({
          project_id: effectiveProjectId,
          energy_score: energyScore,
          carbon_footprint: carbonFootprint,
          execution_time: execution_time_ms || 1000,
          metric_type: "analysis"
        })

      if (metricsError) {
        console.error("[v0] Error inserting metrics:", metricsError)
      }

      // Update project's latest scores
      await adminSupabase
        .from("projects")
        .update({
          latest_energy_score: energyScore,
          latest_carbon_footprint: carbonFootprint,
          updated_at: new Date().toISOString()
        })
        .eq("id", effectiveProjectId)
    }

    // Return the full analysis result
    return NextResponse.json({
      id: analysis.id,
      energy_score: energyScore,
      carbon_footprint: carbonFootprint,
      metrics,
      hotspots,
      recommendations,
      feature_contributions: calculateFeatureContributions(metrics),
      prediction: {
        energy_score: energyScore,
        carbon_footprint: carbonFootprint,
        feature_contributions: calculateFeatureContributions(metrics)
      }
    })

  } catch (err) {
    console.error("[v0] Error in POST /api/analyses:", err)
    return NextResponse.json(
      { error: err instanceof Error ? err.message : "Analysis failed" },
      { status: 500 }
    )
  }
}

// Helper functions for code analysis

function analyzeCode(code: string, language: string) {
  const lines = code.split("\n")
  const linesOfCode = lines.filter(l => l.trim() && !l.trim().startsWith("#") && !l.trim().startsWith("//")).length

  // Count various patterns
  const forLoops = (code.match(/\bfor\b/gi) || []).length
  const whileLoops = (code.match(/\bwhile\b/gi) || []).length
  const nestedLoopDepth = detectNestedLoopDepth(code)
  const ioOperations = (code.match(/\b(open|read|write|print|console|fetch|request)\b/gi) || []).length
  const memoryAllocations = (code.match(/\b(new |malloc|alloc|list\(|dict\(|\[\]|{})\b/gi) || []).length
  const functionCalls = (code.match(/\w+\s*\(/g) || []).length
  const asyncOperations = (code.match(/\b(async|await|Promise|setTimeout|setInterval)\b/gi) || []).length

  // Calculate cyclomatic complexity (simplified)
  const conditionals = (code.match(/\b(if|else|elif|switch|case|catch|&&|\|\||\?)\b/gi) || []).length
  const cyclomaticComplexity = conditionals + forLoops + whileLoops + 1

  return {
    lines_of_code: linesOfCode,
    cyclomatic_complexity: cyclomaticComplexity,
    nested_loop_depth: nestedLoopDepth,
    io_operations: ioOperations,
    memory_allocations: memoryAllocations,
    function_calls: functionCalls,
    async_operations: asyncOperations,
    for_loops: forLoops,
    while_loops: whileLoops
  }
}

function detectNestedLoopDepth(code: string): number {
  let maxDepth = 0
  let currentDepth = 0
  const lines = code.split("\n")

  for (const line of lines) {
    if (/\b(for|while)\b/i.test(line)) {
      currentDepth++
      maxDepth = Math.max(maxDepth, currentDepth)
    }
    // Simple heuristic: decrease depth on dedent or closing brace
    if (/^\s*(}|end|$)/.test(line) && currentDepth > 0) {
      currentDepth--
    }
  }

  return maxDepth
}

function calculateEnergyScore(metrics: Record<string, number>): number {
  // Higher complexity = lower score
  let score = 100

  // Penalize for complexity
  score -= Math.min(30, metrics.cyclomatic_complexity * 2)

  // Penalize for nested loops
  score -= Math.min(25, metrics.nested_loop_depth * 8)

  // Penalize for I/O operations
  score -= Math.min(15, metrics.io_operations * 3)

  // Penalize for memory allocations
  score -= Math.min(15, metrics.memory_allocations * 2)

  // Small penalty for large codebases
  score -= Math.min(10, Math.floor(metrics.lines_of_code / 50))

  // Bonus for async operations (more efficient)
  score += Math.min(5, metrics.async_operations * 2)

  return Math.max(0, Math.min(100, Math.round(score)))
}

function calculateCarbonFootprint(metrics: Record<string, number>, executionTime: number, cpuCores: number): number {
  // Simplified carbon calculation: kg CO2e per execution
  // Based on typical server energy consumption
  const baseWatts = 50 // Base server power consumption
  const perCoreWatts = 10
  const totalWatts = baseWatts + (cpuCores * perCoreWatts)

  // Convert execution time to hours
  const hours = executionTime / (1000 * 60 * 60)

  // Energy in kWh
  const energyKwh = (totalWatts / 1000) * hours

  // CO2 emissions factor (global average: ~0.5 kg CO2/kWh)
  const co2Factor = 0.5

  // Complexity multiplier
  const complexityMultiplier = 1 + (metrics.cyclomatic_complexity / 100) + (metrics.nested_loop_depth / 10)

  return energyKwh * co2Factor * complexityMultiplier
}

function calculateFeatureContributions(metrics: Record<string, number>): Record<string, number> {
  const total = Object.values(metrics).reduce((a, b) => a + b, 1)

  return {
    cyclomatic_complexity: (metrics.cyclomatic_complexity / total) * 0.3,
    nested_loop_depth: (metrics.nested_loop_depth / total) * 0.25,
    io_operations: (metrics.io_operations / total) * 0.15,
    memory_allocations: (metrics.memory_allocations / total) * 0.1,
    function_calls: (metrics.function_calls / total) * 0.1,
    async_operations: -(metrics.async_operations / total) * 0.05,
    lines_of_code: (metrics.lines_of_code / total) * 0.05
  }
}

interface Hotspot {
  issue_type: string
  severity: string
  energy_impact: number
  line_start: number
  line_end?: number
  explanation: string
  function_name?: string
  complexity_score?: number
  code_snippet?: string
}

function detectHotspots(code: string, language: string): Hotspot[] {
  const hotspots: Hotspot[] = []
  const lines = code.split("\n")

  lines.forEach((line, index) => {
    const lineNum = index + 1

    // Detect nested loops
    if (/\b(for|while)\b.*\b(for|while)\b/i.test(line)) {
      hotspots.push({
        issue_type: "nested_loop",
        severity: "high",
        energy_impact: 35,
        line_start: lineNum,
        explanation: "Nested loops increase computational complexity exponentially. Consider using more efficient algorithms.",
        code_snippet: line.trim()
      })
    }

    // Detect inefficient list operations
    if (/\.append\(.*for\b|list\(.*for\b/i.test(line)) {
      hotspots.push({
        issue_type: "inefficient_list_comprehension",
        severity: "medium",
        energy_impact: 20,
        line_start: lineNum,
        explanation: "Consider using list comprehensions or generators for better memory efficiency.",
        code_snippet: line.trim()
      })
    }

    // Detect synchronous I/O in loops
    if (/\b(for|while)\b/.test(lines.slice(Math.max(0, index - 5), index).join("\n")) &&
      /\b(open|read|write|fetch|request)\b/i.test(line)) {
      hotspots.push({
        issue_type: "io_in_loop",
        severity: "critical",
        energy_impact: 45,
        line_start: lineNum,
        explanation: "I/O operations inside loops cause significant performance overhead. Consider batching operations.",
        code_snippet: line.trim()
      })
    }

    // Detect string concatenation in loops
    if (/\b(for|while)\b/.test(lines.slice(Math.max(0, index - 3), index).join("\n")) &&
      /\+\s*=.*["']|["'].*\+/.test(line)) {
      hotspots.push({
        issue_type: "string_concat_in_loop",
        severity: "medium",
        energy_impact: 25,
        line_start: lineNum,
        explanation: "String concatenation in loops creates many intermediate objects. Use join() or StringBuilder.",
        code_snippet: line.trim()
      })
    }

    // Detect potential memory leaks
    if (/\b(global|static)\b.*\[\]|\.push\(|\.append\(/i.test(line)) {
      hotspots.push({
        issue_type: "potential_memory_leak",
        severity: "medium",
        energy_impact: 20,
        line_start: lineNum,
        explanation: "Growing collections without bounds can lead to memory issues. Consider using fixed-size buffers.",
        code_snippet: line.trim()
      })
    }

    // Detect blocking operations
    if (/\b(sleep|wait|time\.sleep|Thread\.sleep)\b/i.test(line)) {
      hotspots.push({
        issue_type: "blocking_operation",
        severity: "low",
        energy_impact: 10,
        line_start: lineNum,
        explanation: "Blocking operations waste CPU cycles. Consider event-driven approaches.",
        code_snippet: line.trim()
      })
    }
  })

  return hotspots
}

interface Recommendation {
  title: string
  description: string
  category: string
  priority: number
  estimated_savings: number
  original_code?: string
  suggested_code?: string
}

function generateRecommendations(hotspots: Hotspot[]): Recommendation[] {
  const recommendations: Recommendation[] = []
  const seenTypes = new Set<string>()

  for (const hotspot of hotspots) {
    if (seenTypes.has(hotspot.issue_type)) continue
    seenTypes.add(hotspot.issue_type)

    switch (hotspot.issue_type) {
      case "nested_loop":
        recommendations.push({
          title: "Optimize Nested Loops",
          description: "Replace nested loops with more efficient algorithms like hash maps, sorting, or matrix operations to reduce time complexity.",
          category: "algorithm",
          priority: 1,
          estimated_savings: 35,
          original_code: "for i in items:\n    for j in items:\n        if i == j: ...",
          suggested_code: "item_set = set(items)\nfor i in items:\n    if i in item_set: ..."
        })
        break
      case "io_in_loop":
        recommendations.push({
          title: "Batch I/O Operations",
          description: "Move I/O operations outside loops by batching reads/writes. This significantly reduces system call overhead.",
          category: "io",
          priority: 1,
          estimated_savings: 45,
          original_code: "for item in items:\n    file.write(item)",
          suggested_code: "file.writelines(items)  # Single write operation"
        })
        break
      case "string_concat_in_loop":
        recommendations.push({
          title: "Use Efficient String Building",
          description: "Replace string concatenation in loops with join() or StringBuilder for better memory efficiency.",
          category: "memory",
          priority: 2,
          estimated_savings: 25,
          original_code: "result = ''\nfor s in strings:\n    result += s",
          suggested_code: "result = ''.join(strings)"
        })
        break
      case "potential_memory_leak":
        recommendations.push({
          title: "Implement Collection Bounds",
          description: "Add size limits to growing collections to prevent unbounded memory growth.",
          category: "memory",
          priority: 2,
          estimated_savings: 20
        })
        break
      case "blocking_operation":
        recommendations.push({
          title: "Use Async/Event-Driven Pattern",
          description: "Replace blocking sleep/wait calls with async patterns or event-driven approaches.",
          category: "concurrency",
          priority: 3,
          estimated_savings: 10
        })
        break
    }
  }

  // Add general recommendations if few hotspots found
  if (recommendations.length < 2) {
    recommendations.push({
      title: "Enable Code Profiling",
      description: "Run a profiler to identify hidden performance bottlenecks not detected by static analysis.",
      category: "configuration",
      priority: 3,
      estimated_savings: 10
    })
  }

  return recommendations.sort((a, b) => a.priority - b.priority)
}
