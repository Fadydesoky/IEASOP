"""
Database Session Management
Async SQLAlchemy session configuration for Supabase PostgreSQL
"""

import os
from typing import AsyncGenerator
from sqlalchemy.ext.asyncio import (
    AsyncSession,
    async_sessionmaker,
    create_async_engine,
)
from sqlalchemy.pool import NullPool


def get_database_url() -> str:
    """
    Construct the async database URL from Supabase credentials.
    Converts the Supabase URL to a PostgreSQL connection string.
    """
    supabase_url = os.environ.get("SUPABASE_URL", "")
    db_password = os.environ.get("SUPABASE_DB_PASSWORD", "")
    
    # Extract the project reference from the Supabase URL
    # Format: https://<project-ref>.supabase.co
    if supabase_url:
        project_ref = supabase_url.replace("https://", "").replace(".supabase.co", "")
        # Construct PostgreSQL connection string
        # Supabase uses pooled connections on port 6543
        return f"postgresql+asyncpg://postgres.{project_ref}:{db_password}@aws-0-us-east-1.pooler.supabase.com:6543/postgres"
    
    # Fallback for local development
    return os.environ.get(
        "DATABASE_URL",
        "postgresql+asyncpg://postgres:postgres@localhost:5432/ieasop"
    )


# Create async engine with connection pooling disabled for serverless
engine = create_async_engine(
    get_database_url(),
    poolclass=NullPool,  # Disable pooling for serverless environments
    echo=os.environ.get("DEBUG", "").lower() == "true",
)

# Create async session factory
async_session_factory = async_sessionmaker(
    engine,
    class_=AsyncSession,
    expire_on_commit=False,
    autocommit=False,
    autoflush=False,
)


async def get_async_session() -> AsyncGenerator[AsyncSession, None]:
    """
    Dependency that yields an async database session.
    Automatically handles commit/rollback and session cleanup.
    """
    async with async_session_factory() as session:
        try:
            yield session
            await session.commit()
        except Exception:
            await session.rollback()
            raise
        finally:
            await session.close()


async def get_db() -> AsyncGenerator[AsyncSession, None]:
    """Alias for get_async_session for FastAPI dependency injection."""
    async for session in get_async_session():
        yield session
