"""
Analyses Router
Code analysis endpoints with ML prediction and SHAP explainability
"""

from fastapi import APIRouter, HTTPException, Header, BackgroundTasks
from pydantic import BaseModel
from typing import Optional
from datetime import datetime
from db import get_client
from routers.auth import get_current_user
from services.code_analyzer import analyze_code, extract_features
from services.ml_pipeline import predict_energy, get_shap_waterfall, get_shap_force
from services.recommendations_engine import generate_recommendations, get_recommendation_summary

router = APIRouter()


class AnalysisCreate(BaseModel):
    """Analysis creation model."""
    project_id: str
    code: str
    file_path: str = "main.py"
    language: str = "python"
    analysis_type: str = "quick"  # quick, deep, simulation
    cpu_cores: float = 4.0
    ram_gb: float = 8.0
    execution_time_ms: float = 1000.0


class AnalysisResponse(BaseModel):
    """Analysis response model."""
    id: str
    project_id: str
    user_id: str
    status: str
    energy_score: Optional[float] = None
    carbon_footprint: Optional[float] = None
    total_functions: Optional[int] = None
    hotspot_count: Optional[int] = None
    analysis_type: str
    results: Optional[dict] = None
    created_at: datetime
    completed_at: Optional[datetime] = None


@router.get("")
async def list_analyses(
    limit: int = 10,
    authorization: str = Header(None)
):
    """List all analyses for current user."""
    try:
        user = await get_current_user(authorization)
        client = await get_client()
        
        result = await client.table("analyses").select("*").eq("user_id", user.id).order("created_at", desc=True).limit(limit).execute()
        
        return result.data or []
    except Exception:
        # Return empty list if unauthorized or error
        return []


@router.post("", response_model=AnalysisResponse)
async def create_analysis(
    analysis: AnalysisCreate,
    background_tasks: BackgroundTasks,
    authorization: str = Header(None)
):
    """Create a new code analysis."""
    user = await get_current_user(authorization)
    client = await get_client()
    
    # Verify project ownership
    project = await client.table("projects").select("id").eq("id", analysis.project_id).eq("user_id", user.id).single().execute()
    if not project.data:
        raise HTTPException(status_code=404, detail="Project not found")
    
    # Analyze code
    metrics = analyze_code(analysis.code, analysis.file_path, analysis.language)
    
    # Extract features for ML
    features = extract_features(
        metrics,
        cpu_cores=analysis.cpu_cores,
        ram_gb=analysis.ram_gb,
        execution_time_ms=analysis.execution_time_ms
    )
    
    # Get ML prediction
    prediction = predict_energy(features)
    
    if prediction is None:
        raise HTTPException(status_code=500, detail="ML prediction failed")
    
    # Generate recommendations
    recommendations = generate_recommendations(
        metrics.hotspots,
        {
            "cyclomatic_complexity": metrics.cyclomatic_complexity,
            "io_operations": metrics.io_operations,
            "async_operations": metrics.async_operations
        },
        prediction.energy_score
    )
    
    rec_summary = get_recommendation_summary(recommendations)
    
    # Prepare results
    results = {
        "metrics": {
            "lines_of_code": metrics.lines_of_code,
            "cyclomatic_complexity": metrics.cyclomatic_complexity,
            "nested_loop_depth": metrics.nested_loop_depth,
            "io_operations": metrics.io_operations,
            "memory_allocations": metrics.memory_allocations,
            "function_calls": metrics.function_calls,
            "async_operations": metrics.async_operations
        },
        "functions": metrics.functions,
        "hotspots": metrics.hotspots,
        "prediction": {
            "energy_score": prediction.energy_score,
            "carbon_footprint": prediction.carbon_footprint,
            "confidence": prediction.confidence,
            "feature_contributions": prediction.feature_contributions
        },
        "recommendations_summary": rec_summary
    }
    
    # Save analysis
    analysis_data = {
        "project_id": analysis.project_id,
        "user_id": user.id,
        "status": "completed",
        "energy_score": prediction.energy_score,
        "carbon_footprint": prediction.carbon_footprint,
        "total_functions": len(metrics.functions),
        "hotspot_count": len(metrics.hotspots),
        "analysis_type": analysis.analysis_type,
        "results": results,
        "ml_features": features.to_dict(),
        "shap_summary": prediction.feature_contributions,
        "started_at": datetime.utcnow().isoformat(),
        "completed_at": datetime.utcnow().isoformat()
    }
    
    result = await client.table("analyses").insert(analysis_data).execute()
    
    if not result.data:
        raise HTTPException(status_code=500, detail="Failed to save analysis")
    
    analysis_id = result.data[0]["id"]
    
    # Save hotspots
    for hotspot in metrics.hotspots:
        hotspot_data = {
            "analysis_id": analysis_id,
            **hotspot
        }
        await client.table("code_hotspots").insert(hotspot_data).execute()
    
    # Save recommendations
    for rec in recommendations:
        rec_data = {
            "analysis_id": analysis_id,
            "title": rec.title,
            "description": rec.description,
            "category": rec.category,
            "priority": rec.priority,
            "estimated_savings": rec.estimated_savings,
            "original_code": rec.original_code,
            "suggested_code": rec.suggested_code
        }
        await client.table("recommendations").insert(rec_data).execute()
    
    # Update project's latest scores
    await client.table("projects").update({
        "latest_energy_score": prediction.energy_score,
        "latest_carbon_footprint": prediction.carbon_footprint,
        "updated_at": datetime.utcnow().isoformat()
    }).eq("id", analysis.project_id).execute()
    
    # Record metrics
    await client.table("energy_metrics").insert({
        "project_id": analysis.project_id,
        "energy_score": prediction.energy_score,
        "carbon_footprint": prediction.carbon_footprint,
        "cpu_usage": analysis.cpu_cores * 10,  # Simplified
        "memory_usage": (analysis.ram_gb / 16) * 100,
        "execution_time": analysis.execution_time_ms,
        "metric_type": "analysis"
    }).execute()
    
    return result.data[0]


@router.get("/{analysis_id}", response_model=AnalysisResponse)
async def get_analysis(analysis_id: str, authorization: str = Header(None)):
    """Get a specific analysis."""
    user = await get_current_user(authorization)
    client = await get_client()
    
    result = await client.table("analyses").select("*").eq("id", analysis_id).eq("user_id", user.id).single().execute()
    
    if not result.data:
        raise HTTPException(status_code=404, detail="Analysis not found")
    
    return result.data


@router.get("/{analysis_id}/hotspots")
async def get_analysis_hotspots(analysis_id: str, authorization: str = Header(None)):
    """Get hotspots for an analysis."""
    user = await get_current_user(authorization)
    client = await get_client()
    
    # Verify ownership
    analysis = await client.table("analyses").select("id").eq("id", analysis_id).eq("user_id", user.id).single().execute()
    if not analysis.data:
        raise HTTPException(status_code=404, detail="Analysis not found")
    
    result = await client.table("code_hotspots").select("*").eq("analysis_id", analysis_id).order("energy_impact", desc=True).execute()
    
    return result.data or []


@router.get("/{analysis_id}/recommendations")
async def get_analysis_recommendations(analysis_id: str, authorization: str = Header(None)):
    """Get recommendations for an analysis."""
    user = await get_current_user(authorization)
    client = await get_client()
    
    # Verify ownership
    analysis = await client.table("analyses").select("id").eq("id", analysis_id).eq("user_id", user.id).single().execute()
    if not analysis.data:
        raise HTTPException(status_code=404, detail="Analysis not found")
    
    result = await client.table("recommendations").select("*").eq("analysis_id", analysis_id).order("priority").execute()
    
    return result.data or []
