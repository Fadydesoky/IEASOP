import { createClient } from "@/lib/supabase/server"
import { createAdminClient } from "@/lib/supabase/admin"
import { NextResponse } from "next/server"

export async function GET() {
  try {
    // Use admin client to fetch all projects (including demo)
    const supabase = createAdminClient()
    
    const { data, error } = await supabase
      .from("projects")
      .select("*")
      .order("updated_at", { ascending: false })
    
    if (error) {
      console.error("[v0] Supabase error fetching projects:", error)
      return NextResponse.json(
        { error: error.message },
        { status: 500 }
      )
    }
    
    return NextResponse.json(data ?? [])
  } catch (err) {
    console.error("[v0] Error in GET /api/projects:", err)
    return NextResponse.json(
      { error: "Failed to fetch projects" },
      { status: 500 }
    )
  }
}

export async function POST(request: Request) {
  try {
    const supabase = await createClient()
    const body = await request.json()
    
    console.log("[v0] Creating project:", body)
    
    const { name, description, repository_url, language, framework } = body
    
    if (!name) {
      return NextResponse.json(
        { error: "Project name is required" },
        { status: 400 }
      )
    }
    
    // Get the current user
    const { data: { user } } = await supabase.auth.getUser()
    
    if (!user) {
      return NextResponse.json(
        { error: "Authentication required" },
        { status: 401 }
      )
    }
    
    const { data: project, error } = await supabase
      .from("projects")
      .insert({
        user_id: user.id,
        name,
        description,
        repository_url,
        language,
        framework,
        status: "active"
      })
      .select()
      .single()
    
    if (error) {
      console.error("[v0] Error creating project:", error)
      return NextResponse.json(
        { error: error.message },
        { status: 500 }
      )
    }
    
    console.log("[v0] Project created:", project?.id)
    return NextResponse.json(project)
  } catch (err) {
    console.error("[v0] Error in POST /api/projects:", err)
    return NextResponse.json(
      { error: "Failed to create project" },
      { status: 500 }
    )
  }
}
