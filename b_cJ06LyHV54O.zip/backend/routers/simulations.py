"""
Simulations Router
Scenario simulation endpoints for energy prediction
"""

from fastapi import APIRouter, HTTPException, Header
from pydantic import BaseModel
from typing import Optional, List
from datetime import datetime
from db import get_client
from routers.auth import get_current_user
from services.ml_pipeline import FeatureSet, simulate_scenario, predict_energy

router = APIRouter()


class SimulationCreate(BaseModel):
    """Simulation creation model."""
    project_id: str
    name: str
    base_cpu_cores: float = 4.0
    base_ram_gb: float = 8.0
    base_execution_time_ms: float = 1000.0
    base_lines_of_code: int = 500
    base_cyclomatic_complexity: float = 10.0
    base_nested_loop_depth: int = 2
    base_io_operations: int = 10
    base_memory_allocations: int = 100
    base_function_calls: int = 50
    base_async_operations: int = 5
    # Scenario parameters
    scenario_cpu_cores: Optional[float] = None
    scenario_ram_gb: Optional[float] = None
    scenario_execution_time_ms: Optional[float] = None


class QuickSimulation(BaseModel):
    """Quick simulation without saving."""
    cpu_cores: float = 4.0
    ram_gb: float = 8.0
    execution_time_ms: float = 1000.0
    lines_of_code: int = 500
    cyclomatic_complexity: float = 10.0
    nested_loop_depth: int = 2
    io_operations: int = 10
    memory_allocations: int = 100
    function_calls: int = 50
    async_operations: int = 5


class ScenarioComparison(BaseModel):
    """Compare multiple scenarios."""
    base_scenario: QuickSimulation
    scenarios: List[QuickSimulation]


class SimulationResponse(BaseModel):
    """Simulation response model."""
    id: str
    project_id: str
    user_id: str
    name: str
    scenario_config: dict
    baseline_metrics: Optional[dict] = None
    optimized_metrics: Optional[dict] = None
    savings_summary: Optional[dict] = None
    status: str
    created_at: datetime
    completed_at: Optional[datetime] = None


@router.post("/quick")
async def quick_simulation(
    params: QuickSimulation,
    authorization: str = Header(None)
):
    """Run a quick simulation without saving to database."""
    await get_current_user(authorization)
    
    features = FeatureSet(
        cpu_cores=params.cpu_cores,
        ram_gb=params.ram_gb,
        execution_time_ms=params.execution_time_ms,
        lines_of_code=params.lines_of_code,
        cyclomatic_complexity=params.cyclomatic_complexity,
        nested_loop_depth=params.nested_loop_depth,
        io_operations=params.io_operations,
        memory_allocations=params.memory_allocations,
        function_calls=params.function_calls,
        async_operations=params.async_operations
    )
    
    prediction = predict_energy(features)
    
    if prediction is None:
        raise HTTPException(status_code=500, detail="Simulation failed")
    
    return {
        "energy_score": prediction.energy_score,
        "carbon_footprint": prediction.carbon_footprint,
        "confidence": prediction.confidence,
        "feature_contributions": prediction.feature_contributions,
        "features": features.to_dict()
    }


@router.post("/compare")
async def compare_scenarios(
    comparison: ScenarioComparison,
    authorization: str = Header(None)
):
    """Compare multiple scenarios against a baseline."""
    await get_current_user(authorization)
    
    # Get baseline prediction
    base_features = FeatureSet(
        cpu_cores=comparison.base_scenario.cpu_cores,
        ram_gb=comparison.base_scenario.ram_gb,
        execution_time_ms=comparison.base_scenario.execution_time_ms,
        lines_of_code=comparison.base_scenario.lines_of_code,
        cyclomatic_complexity=comparison.base_scenario.cyclomatic_complexity,
        nested_loop_depth=comparison.base_scenario.nested_loop_depth,
        io_operations=comparison.base_scenario.io_operations,
        memory_allocations=comparison.base_scenario.memory_allocations,
        function_calls=comparison.base_scenario.function_calls,
        async_operations=comparison.base_scenario.async_operations
    )
    
    baseline = predict_energy(base_features)
    if baseline is None:
        raise HTTPException(status_code=500, detail="Baseline prediction failed")
    
    results = []
    for i, scenario in enumerate(comparison.scenarios):
        scenario_features = FeatureSet(
            cpu_cores=scenario.cpu_cores,
            ram_gb=scenario.ram_gb,
            execution_time_ms=scenario.execution_time_ms,
            lines_of_code=scenario.lines_of_code,
            cyclomatic_complexity=scenario.cyclomatic_complexity,
            nested_loop_depth=scenario.nested_loop_depth,
            io_operations=scenario.io_operations,
            memory_allocations=scenario.memory_allocations,
            function_calls=scenario.function_calls,
            async_operations=scenario.async_operations
        )
        
        prediction = predict_energy(scenario_features)
        if prediction:
            results.append({
                "scenario_index": i + 1,
                "energy_score": prediction.energy_score,
                "carbon_footprint": prediction.carbon_footprint,
                "delta_score": round(prediction.energy_score - baseline.energy_score, 2),
                "delta_carbon": round(prediction.carbon_footprint - baseline.carbon_footprint, 6),
                "improvement_percent": round(
                    ((prediction.energy_score - baseline.energy_score) / max(baseline.energy_score, 1)) * 100, 2
                ),
                "features": scenario_features.to_dict()
            })
    
    return {
        "baseline": {
            "energy_score": baseline.energy_score,
            "carbon_footprint": baseline.carbon_footprint,
            "features": base_features.to_dict()
        },
        "scenarios": results,
        "best_scenario": max(results, key=lambda x: x["energy_score"]) if results else None,
        "total_scenarios": len(results)
    }


@router.post("", response_model=SimulationResponse)
async def create_simulation(
    simulation: SimulationCreate,
    authorization: str = Header(None)
):
    """Create and run a saved simulation."""
    user = await get_current_user(authorization)
    client = await get_client()
    
    # Verify project ownership
    project = await client.table("projects").select("id").eq("id", simulation.project_id).eq("user_id", user.id).single().execute()
    if not project.data:
        raise HTTPException(status_code=404, detail="Project not found")
    
    # Create base features
    base_features = FeatureSet(
        cpu_cores=simulation.base_cpu_cores,
        ram_gb=simulation.base_ram_gb,
        execution_time_ms=simulation.base_execution_time_ms,
        lines_of_code=simulation.base_lines_of_code,
        cyclomatic_complexity=simulation.base_cyclomatic_complexity,
        nested_loop_depth=simulation.base_nested_loop_depth,
        io_operations=simulation.base_io_operations,
        memory_allocations=simulation.base_memory_allocations,
        function_calls=simulation.base_function_calls,
        async_operations=simulation.base_async_operations
    )
    
    # Run simulation
    result = simulate_scenario(
        base_features,
        cpu_cores=simulation.scenario_cpu_cores,
        ram_gb=simulation.scenario_ram_gb,
        execution_time_ms=simulation.scenario_execution_time_ms
    )
    
    if result is None:
        raise HTTPException(status_code=500, detail="Simulation failed")
    
    # Save simulation
    sim_data = {
        "project_id": simulation.project_id,
        "user_id": user.id,
        "name": simulation.name,
        "scenario_config": {
            "base": base_features.to_dict(),
            "scenario_cpu_cores": simulation.scenario_cpu_cores,
            "scenario_ram_gb": simulation.scenario_ram_gb,
            "scenario_execution_time_ms": simulation.scenario_execution_time_ms
        },
        "baseline_metrics": result["baseline"],
        "optimized_metrics": result["simulated"],
        "savings_summary": result["delta"],
        "status": "completed",
        "completed_at": datetime.utcnow().isoformat()
    }
    
    db_result = await client.table("simulations").insert(sim_data).execute()
    
    if not db_result.data:
        raise HTTPException(status_code=500, detail="Failed to save simulation")
    
    return db_result.data[0]


@router.get("", response_model=List[SimulationResponse])
async def list_simulations(
    project_id: Optional[str] = None,
    authorization: str = Header(None)
):
    """List all simulations for current user."""
    user = await get_current_user(authorization)
    client = await get_client()
    
    query = client.table("simulations").select("*").eq("user_id", user.id)
    
    if project_id:
        query = query.eq("project_id", project_id)
    
    result = await query.order("created_at", desc=True).execute()
    
    return result.data or []


@router.get("/{simulation_id}", response_model=SimulationResponse)
async def get_simulation(simulation_id: str, authorization: str = Header(None)):
    """Get a specific simulation."""
    user = await get_current_user(authorization)
    client = await get_client()
    
    result = await client.table("simulations").select("*").eq("id", simulation_id).eq("user_id", user.id).single().execute()
    
    if not result.data:
        raise HTTPException(status_code=404, detail="Simulation not found")
    
    return result.data


@router.delete("/{simulation_id}")
async def delete_simulation(simulation_id: str, authorization: str = Header(None)):
    """Delete a simulation."""
    user = await get_current_user(authorization)
    client = await get_client()
    
    await client.table("simulations").delete().eq("id", simulation_id).eq("user_id", user.id).execute()
    
    return {"message": "Simulation deleted"}
