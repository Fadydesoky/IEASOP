"""
CLI API Router
Endpoints for the IEASOP CLI tool
"""

from fastapi import APIRouter, HTTPException, Header
from pydantic import BaseModel
from typing import Optional, List
from datetime import datetime
from db import get_service_client, get_client
from routers.auth import get_current_user
from services.code_analyzer import analyze_code, extract_features
from services.ml_pipeline import predict_energy, get_shap_waterfall
from services.recommendations_engine import generate_recommendations

router = APIRouter()


class ScanRequest(BaseModel):
    """Code scan request from CLI."""
    files: List[dict]  # List of {path: str, content: str, language: str}
    project_name: Optional[str] = None
    cpu_cores: float = 4.0
    ram_gb: float = 8.0
    execution_time_ms: float = 1000.0


class QuickScanRequest(BaseModel):
    """Quick single-file scan request."""
    code: str
    file_path: str = "main.py"
    language: str = "python"


async def verify_api_key(api_key: str) -> dict:
    """Verify API key and return user profile."""
    if not api_key or not api_key.startswith("ieasop_"):
        raise HTTPException(status_code=401, detail="Invalid API key format")
    
    client = await get_service_client()
    result = await client.table("profiles").select("*").eq("api_key", api_key).single().execute()
    
    if not result.data:
        raise HTTPException(status_code=401, detail="Invalid API key")
    
    return result.data


@router.post("/scan")
async def scan_project(
    request: ScanRequest,
    x_api_key: str = Header(None, alias="X-API-Key")
):
    """Scan multiple files from a project directory."""
    profile = await verify_api_key(x_api_key)
    
    if not request.files:
        raise HTTPException(status_code=400, detail="No files provided")
    
    results = []
    total_score = 0
    total_carbon = 0
    all_hotspots = []
    all_recommendations = []
    
    for file_info in request.files:
        file_path = file_info.get("path", "unknown")
        content = file_info.get("content", "")
        language = file_info.get("language", "python")
        
        if not content.strip():
            continue
        
        # Analyze file
        metrics = analyze_code(content, file_path, language)
        features = extract_features(
            metrics,
            cpu_cores=request.cpu_cores,
            ram_gb=request.ram_gb,
            execution_time_ms=request.execution_time_ms
        )
        
        prediction = predict_energy(features)
        
        if prediction:
            file_result = {
                "file": file_path,
                "language": language,
                "lines_of_code": metrics.lines_of_code,
                "energy_score": prediction.energy_score,
                "carbon_footprint": prediction.carbon_footprint,
                "hotspots": len(metrics.hotspots),
                "complexity": metrics.cyclomatic_complexity
            }
            results.append(file_result)
            total_score += prediction.energy_score
            total_carbon += prediction.carbon_footprint
            
            # Collect hotspots with file info
            for hotspot in metrics.hotspots:
                hotspot["file"] = file_path
                all_hotspots.append(hotspot)
            
            # Generate recommendations
            recs = generate_recommendations(
                metrics.hotspots,
                {
                    "cyclomatic_complexity": metrics.cyclomatic_complexity,
                    "io_operations": metrics.io_operations,
                    "async_operations": metrics.async_operations
                },
                prediction.energy_score
            )
            for rec in recs:
                if rec.title not in [r["title"] for r in all_recommendations]:
                    all_recommendations.append({
                        "title": rec.title,
                        "description": rec.description,
                        "category": rec.category,
                        "priority": rec.priority,
                        "estimated_savings": rec.estimated_savings
                    })
    
    if not results:
        raise HTTPException(status_code=400, detail="No valid files to analyze")
    
    avg_score = total_score / len(results)
    
    # Sort hotspots by energy impact
    all_hotspots.sort(key=lambda x: x.get("energy_impact", 0), reverse=True)
    
    # Sort recommendations by priority
    all_recommendations.sort(key=lambda x: (x["priority"], -x["estimated_savings"]))
    
    return {
        "project_name": request.project_name or "Unnamed Project",
        "summary": {
            "total_files": len(results),
            "total_lines": sum(r["lines_of_code"] for r in results),
            "average_energy_score": round(avg_score, 2),
            "total_carbon_footprint": round(total_carbon, 6),
            "total_hotspots": len(all_hotspots),
            "grade": _get_grade(avg_score)
        },
        "files": results,
        "top_hotspots": all_hotspots[:10],
        "recommendations": all_recommendations[:10],
        "scan_time": datetime.utcnow().isoformat()
    }


@router.post("/quick-scan")
async def quick_scan(
    request: QuickScanRequest,
    x_api_key: str = Header(None, alias="X-API-Key")
):
    """Quick scan of a single file."""
    profile = await verify_api_key(x_api_key)
    
    # Analyze code
    metrics = analyze_code(request.code, request.file_path, request.language)
    features = extract_features(metrics)
    
    prediction = predict_energy(features)
    
    if prediction is None:
        raise HTTPException(status_code=500, detail="Analysis failed")
    
    # Get SHAP explanation
    waterfall = get_shap_waterfall(features)
    
    # Generate recommendations
    recs = generate_recommendations(
        metrics.hotspots,
        {
            "cyclomatic_complexity": metrics.cyclomatic_complexity,
            "io_operations": metrics.io_operations,
            "async_operations": metrics.async_operations
        },
        prediction.energy_score
    )
    
    return {
        "file": request.file_path,
        "energy_score": prediction.energy_score,
        "carbon_footprint": prediction.carbon_footprint,
        "grade": _get_grade(prediction.energy_score),
        "metrics": {
            "lines_of_code": metrics.lines_of_code,
            "cyclomatic_complexity": metrics.cyclomatic_complexity,
            "nested_loop_depth": metrics.nested_loop_depth,
            "io_operations": metrics.io_operations,
            "async_operations": metrics.async_operations
        },
        "hotspots": metrics.hotspots,
        "feature_contributions": prediction.feature_contributions,
        "recommendations": [
            {
                "title": r.title,
                "description": r.description,
                "category": r.category,
                "priority": r.priority,
                "estimated_savings": r.estimated_savings
            }
            for r in recs[:5]
        ]
    }


@router.get("/me")
async def get_cli_profile(x_api_key: str = Header(None, alias="X-API-Key")):
    """Get profile info for CLI user."""
    profile = await verify_api_key(x_api_key)
    
    return {
        "id": profile["id"],
        "email": profile.get("email"),
        "full_name": profile.get("full_name"),
        "subscription_tier": profile.get("subscription_tier", "free")
    }


@router.get("/projects")
async def list_cli_projects(x_api_key: str = Header(None, alias="X-API-Key")):
    """List projects for CLI user."""
    profile = await verify_api_key(x_api_key)
    client = await get_service_client()
    
    result = await client.table("projects").select("id, name, language, latest_energy_score, updated_at").eq("user_id", profile["id"]).order("updated_at", desc=True).execute()
    
    return result.data or []


@router.post("/init")
async def init_project(
    project_name: str,
    language: Optional[str] = None,
    x_api_key: str = Header(None, alias="X-API-Key")
):
    """Initialize a new project from CLI."""
    profile = await verify_api_key(x_api_key)
    client = await get_service_client()
    
    project_data = {
        "user_id": profile["id"],
        "name": project_name,
        "language": language
    }
    
    result = await client.table("projects").insert(project_data).execute()
    
    if not result.data:
        raise HTTPException(status_code=500, detail="Failed to create project")
    
    return {
        "message": f"Project '{project_name}' created successfully",
        "project_id": result.data[0]["id"]
    }


def _get_grade(score: float) -> str:
    """Convert energy score to letter grade."""
    if score >= 90:
        return "A+"
    elif score >= 85:
        return "A"
    elif score >= 80:
        return "A-"
    elif score >= 75:
        return "B+"
    elif score >= 70:
        return "B"
    elif score >= 65:
        return "B-"
    elif score >= 60:
        return "C+"
    elif score >= 55:
        return "C"
    elif score >= 50:
        return "C-"
    elif score >= 45:
        return "D"
    else:
        return "F"
