"""
CI/CD Router
CI/CD integration endpoints for energy threshold checks
"""

from fastapi import APIRouter, HTTPException, Header
from pydantic import BaseModel
from typing import Optional, List
from datetime import datetime
from db import get_client, get_service_client
from routers.auth import get_current_user
from services.code_analyzer import analyze_code, extract_features
from services.ml_pipeline import predict_energy

router = APIRouter()


class CICDConfigCreate(BaseModel):
    """CI/CD configuration creation model."""
    project_id: str
    threshold: float = 70.0
    notify_on_fail: bool = True
    notify_email: Optional[str] = None
    webhook_url: Optional[str] = None


class CICDConfigUpdate(BaseModel):
    """CI/CD configuration update model."""
    threshold: Optional[float] = None
    notify_on_fail: Optional[bool] = None
    notify_email: Optional[str] = None
    webhook_url: Optional[str] = None


class PipelineCheck(BaseModel):
    """Pipeline energy check request."""
    project_id: str
    commit_sha: Optional[str] = None
    branch: Optional[str] = None
    code: str
    file_path: str = "main.py"
    language: str = "python"
    cpu_cores: float = 4.0
    ram_gb: float = 8.0
    execution_time_ms: float = 1000.0


class WebhookPayload(BaseModel):
    """Webhook payload for CI/CD triggers."""
    api_key: str
    project_id: str
    commit_sha: Optional[str] = None
    branch: Optional[str] = None
    code: str
    file_path: str = "main.py"
    language: str = "python"


class CICDRunResponse(BaseModel):
    """CI/CD run response model."""
    id: str
    project_id: str
    analysis_id: Optional[str] = None
    commit_sha: Optional[str] = None
    branch: Optional[str] = None
    status: str
    energy_score: float
    threshold: float
    triggered_by: str
    comparison_to_previous: Optional[dict] = None
    created_at: datetime


@router.post("/config")
async def create_or_update_config(
    config: CICDConfigCreate,
    authorization: str = Header(None)
):
    """Create or update CI/CD configuration for a project."""
    user = await get_current_user(authorization)
    client = await get_client()
    
    # Verify project ownership
    project = await client.table("projects").select("id").eq("id", config.project_id).eq("user_id", user.id).single().execute()
    if not project.data:
        raise HTTPException(status_code=404, detail="Project not found")
    
    # Check if config exists
    existing = await client.table("cicd_config").select("id").eq("project_id", config.project_id).single().execute()
    
    config_data = {
        "project_id": config.project_id,
        "threshold": config.threshold,
        "notify_on_fail": config.notify_on_fail,
        "notify_email": config.notify_email,
        "webhook_url": config.webhook_url,
        "updated_at": datetime.utcnow().isoformat()
    }
    
    if existing.data:
        result = await client.table("cicd_config").update(config_data).eq("id", existing.data["id"]).execute()
    else:
        result = await client.table("cicd_config").insert(config_data).execute()
    
    return result.data[0]


@router.get("/config/{project_id}")
async def get_config(project_id: str, authorization: str = Header(None)):
    """Get CI/CD configuration for a project."""
    user = await get_current_user(authorization)
    client = await get_client()
    
    # Verify project ownership
    project = await client.table("projects").select("id").eq("id", project_id).eq("user_id", user.id).single().execute()
    if not project.data:
        raise HTTPException(status_code=404, detail="Project not found")
    
    result = await client.table("cicd_config").select("*").eq("project_id", project_id).single().execute()
    
    if not result.data:
        return {
            "project_id": project_id,
            "threshold": 70.0,
            "notify_on_fail": True,
            "configured": False
        }
    
    result.data["configured"] = True
    return result.data


@router.put("/config/{project_id}")
async def update_config(
    project_id: str,
    update: CICDConfigUpdate,
    authorization: str = Header(None)
):
    """Update CI/CD configuration."""
    user = await get_current_user(authorization)
    client = await get_client()
    
    # Verify project ownership
    project = await client.table("projects").select("id").eq("id", project_id).eq("user_id", user.id).single().execute()
    if not project.data:
        raise HTTPException(status_code=404, detail="Project not found")
    
    update_data = {k: v for k, v in update.model_dump().items() if v is not None}
    update_data["updated_at"] = datetime.utcnow().isoformat()
    
    result = await client.table("cicd_config").update(update_data).eq("project_id", project_id).execute()
    
    if not result.data:
        raise HTTPException(status_code=404, detail="Configuration not found")
    
    return result.data[0]


@router.post("/check", response_model=CICDRunResponse)
async def pipeline_check(
    check: PipelineCheck,
    authorization: str = Header(None)
):
    """Run energy check for CI/CD pipeline."""
    user = await get_current_user(authorization)
    client = await get_client()
    
    # Verify project ownership
    project = await client.table("projects").select("id").eq("id", check.project_id).eq("user_id", user.id).single().execute()
    if not project.data:
        raise HTTPException(status_code=404, detail="Project not found")
    
    # Get config
    config = await client.table("cicd_config").select("*").eq("project_id", check.project_id).single().execute()
    threshold = config.data["threshold"] if config.data else 70.0
    
    # Analyze code
    metrics = analyze_code(check.code, check.file_path, check.language)
    features = extract_features(
        metrics,
        cpu_cores=check.cpu_cores,
        ram_gb=check.ram_gb,
        execution_time_ms=check.execution_time_ms
    )
    
    prediction = predict_energy(features)
    if prediction is None:
        raise HTTPException(status_code=500, detail="Energy prediction failed")
    
    # Determine pass/fail
    status = "pass" if prediction.energy_score >= threshold else "fail"
    
    # Get previous run for comparison
    previous = await client.table("cicd_runs").select("energy_score").eq("project_id", check.project_id).order("created_at", desc=True).limit(1).execute()
    
    comparison = None
    if previous.data:
        prev_score = previous.data[0]["energy_score"]
        comparison = {
            "previous_score": prev_score,
            "current_score": prediction.energy_score,
            "delta": round(prediction.energy_score - prev_score, 2),
            "improved": prediction.energy_score > prev_score
        }
    
    # Save run
    run_data = {
        "project_id": check.project_id,
        "commit_sha": check.commit_sha,
        "branch": check.branch,
        "status": status,
        "energy_score": prediction.energy_score,
        "threshold": threshold,
        "triggered_by": "manual",
        "comparison_to_previous": comparison
    }
    
    result = await client.table("cicd_runs").insert(run_data).execute()
    
    return result.data[0]


@router.post("/webhook")
async def webhook_trigger(payload: WebhookPayload):
    """Webhook endpoint for CI/CD triggers (GitHub Actions, GitLab CI, etc.)."""
    client = await get_service_client()
    
    # Verify API key
    profile = await client.table("profiles").select("id").eq("api_key", payload.api_key).single().execute()
    if not profile.data:
        raise HTTPException(status_code=401, detail="Invalid API key")
    
    user_id = profile.data["id"]
    
    # Verify project ownership
    project = await client.table("projects").select("id").eq("id", payload.project_id).eq("user_id", user_id).single().execute()
    if not project.data:
        raise HTTPException(status_code=404, detail="Project not found")
    
    # Get config
    config = await client.table("cicd_config").select("*").eq("project_id", payload.project_id).single().execute()
    threshold = config.data["threshold"] if config.data else 70.0
    
    # Analyze code
    metrics = analyze_code(payload.code, payload.file_path, payload.language)
    features = extract_features(metrics)
    
    prediction = predict_energy(features)
    if prediction is None:
        raise HTTPException(status_code=500, detail="Energy prediction failed")
    
    status = "pass" if prediction.energy_score >= threshold else "fail"
    
    # Get previous run
    previous = await client.table("cicd_runs").select("energy_score").eq("project_id", payload.project_id).order("created_at", desc=True).limit(1).execute()
    
    comparison = None
    if previous.data:
        prev_score = previous.data[0]["energy_score"]
        comparison = {
            "previous_score": prev_score,
            "current_score": prediction.energy_score,
            "delta": round(prediction.energy_score - prev_score, 2),
            "improved": prediction.energy_score > prev_score
        }
    
    # Save run
    run_data = {
        "project_id": payload.project_id,
        "commit_sha": payload.commit_sha,
        "branch": payload.branch,
        "status": status,
        "energy_score": prediction.energy_score,
        "threshold": threshold,
        "triggered_by": "webhook",
        "comparison_to_previous": comparison
    }
    
    await client.table("cicd_runs").insert(run_data).execute()
    
    # Return CI/CD compatible response
    return {
        "status": status,
        "passed": status == "pass",
        "energy_score": prediction.energy_score,
        "threshold": threshold,
        "carbon_footprint": prediction.carbon_footprint,
        "comparison": comparison,
        "message": f"Energy score: {prediction.energy_score}/100 (threshold: {threshold})"
    }


@router.get("/runs/{project_id}", response_model=List[CICDRunResponse])
async def list_runs(
    project_id: str,
    limit: int = 20,
    authorization: str = Header(None)
):
    """List CI/CD runs for a project."""
    user = await get_current_user(authorization)
    client = await get_client()
    
    # Verify project ownership
    project = await client.table("projects").select("id").eq("id", project_id).eq("user_id", user.id).single().execute()
    if not project.data:
        raise HTTPException(status_code=404, detail="Project not found")
    
    result = await client.table("cicd_runs").select("*").eq("project_id", project_id).order("created_at", desc=True).limit(limit).execute()
    
    return result.data or []


@router.get("/runs/{project_id}/stats")
async def run_stats(project_id: str, authorization: str = Header(None)):
    """Get CI/CD run statistics for a project."""
    user = await get_current_user(authorization)
    client = await get_client()
    
    # Verify project ownership
    project = await client.table("projects").select("id").eq("id", project_id).eq("user_id", user.id).single().execute()
    if not project.data:
        raise HTTPException(status_code=404, detail="Project not found")
    
    result = await client.table("cicd_runs").select("*").eq("project_id", project_id).execute()
    runs = result.data or []
    
    if not runs:
        return {
            "total_runs": 0,
            "pass_rate": 0,
            "average_score": 0,
            "trend": "stable"
        }
    
    total = len(runs)
    passed = len([r for r in runs if r["status"] == "pass"])
    scores = [r["energy_score"] for r in runs]
    
    # Calculate trend
    if len(scores) >= 2:
        recent_avg = sum(scores[:5]) / min(5, len(scores))
        older_avg = sum(scores[-5:]) / min(5, len(scores))
        if recent_avg > older_avg + 2:
            trend = "improving"
        elif recent_avg < older_avg - 2:
            trend = "declining"
        else:
            trend = "stable"
    else:
        trend = "stable"
    
    return {
        "total_runs": total,
        "pass_rate": round((passed / total) * 100, 1),
        "fail_count": total - passed,
        "average_score": round(sum(scores) / len(scores), 2),
        "best_score": max(scores),
        "worst_score": min(scores),
        "trend": trend
    }
