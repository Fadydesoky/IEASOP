"""
Project Repository
Database operations for Project entities
"""

from typing import Sequence
from sqlalchemy import select, func
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.orm import selectinload

from models.project import Project
from models.analysis import Analysis
from .base import BaseRepository


class ProjectRepository(BaseRepository[Project]):
    """Repository for Project entity operations."""
    
    def __init__(self, session: AsyncSession) -> None:
        super().__init__(session, Project)
    
    async def get_by_user_id(
        self,
        user_id: str,
        skip: int = 0,
        limit: int = 100
    ) -> Sequence[Project]:
        """Get all projects for a specific user."""
        result = await self._session.execute(
            select(Project)
            .where(Project.user_id == user_id)
            .order_by(Project.created_at.desc())
            .offset(skip)
            .limit(limit)
        )
        return result.scalars().all()
    
    async def get_with_analyses(self, project_id: str) -> Project | None:
        """Get a project with its analyses eagerly loaded."""
        result = await self._session.execute(
            select(Project)
            .where(Project.id == project_id)
            .options(selectinload(Project.analyses))
        )
        return result.scalar_one_or_none()
    
    async def get_by_name_and_user(
        self,
        name: str,
        user_id: str
    ) -> Project | None:
        """Find a project by name for a specific user."""
        result = await self._session.execute(
            select(Project)
            .where(Project.name == name)
            .where(Project.user_id == user_id)
        )
        return result.scalar_one_or_none()
    
    async def count_by_user(self, user_id: str) -> int:
        """Count projects for a specific user."""
        result = await self._session.execute(
            select(func.count())
            .select_from(Project)
            .where(Project.user_id == user_id)
        )
        return result.scalar_one()
    
    async def get_latest_analysis_score(self, project_id: str) -> float | None:
        """Get the energy score from the most recent analysis."""
        result = await self._session.execute(
            select(Analysis.energy_score)
            .where(Analysis.project_id == project_id)
            .order_by(Analysis.created_at.desc())
            .limit(1)
        )
        return result.scalar_one_or_none()
    
    async def create_project(self, user_id: str, name: str) -> Project:
        """Create a new project for a user."""
        project = Project(user_id=user_id, name=name)
        return await self.create(project)
