import { createAdminClient } from "@/lib/supabase/admin"
import { NextResponse } from "next/server"

export async function GET() {
  try {
    // Use admin client to fetch all data (including demo user's)
    const supabase = createAdminClient()
    
    // Fetch analyses count and stats
    const { data: analyses, error: analysesError } = await supabase
      .from("analyses")
      .select("id, energy_score, carbon_footprint, created_at")
      .order("created_at", { ascending: false })
    
    if (analysesError) {
      console.error("[v0] Error fetching analyses:", analysesError)
    }
    
    // Fetch projects count
    const { data: projects, error: projectsError } = await supabase
      .from("projects")
      .select("id, latest_energy_score")
    
    if (projectsError) {
      console.error("[v0] Error fetching projects:", projectsError)
    }
    
    // Fetch active hotspots (from recent analyses)
    const { data: hotspots, error: hotspotsError } = await supabase
      .from("code_hotspots")
      .select("id")
    
    if (hotspotsError) {
      console.error("[v0] Error fetching hotspots:", hotspotsError)
    }
    
    // Calculate totals
    const totalAnalyses = analyses?.length ?? 0
    const totalProjects = projects?.length ?? 0
    const activeHotspots = hotspots?.length ?? 0
    
    // Calculate average energy score
    const avgScore = analyses && analyses.length > 0
      ? analyses.reduce((sum, a) => sum + (a.energy_score || 0), 0) / analyses.length
      : 0
    
    // Calculate total carbon saved (assume baseline of 0.001 kg CO2 per analysis)
    const baselineCarbon = 0.001
    const actualCarbon = analyses && analyses.length > 0
      ? analyses.reduce((sum, a) => sum + (a.carbon_footprint || 0), 0)
      : 0
    const carbonSaved = Math.max(0, (baselineCarbon * totalAnalyses) - actualCarbon)
    
    // Generate energy trend from recent analyses (last 7 days)
    const energyTrend = generateEnergyTrend(analyses || [])
    
    console.log("[v0] Dashboard summary:", { 
      totalScore: avgScore, 
      totalAnalyses, 
      totalProjects, 
      activeHotspots 
    })
    
    return NextResponse.json({
      totalScore: Math.round(avgScore * 10) / 10,
      carbonSaved: Math.round(carbonSaved * 10000) / 10000,
      totalAnalyses,
      activeHotspots,
      totalProjects,
      energyTrend
    })
  } catch (err) {
    console.error("[v0] Error in GET /api/dashboard/summary:", err)
    return NextResponse.json(
      { error: "Failed to fetch dashboard summary" },
      { status: 500 }
    )
  }
}

function generateEnergyTrend(analyses: Array<{ created_at: string; energy_score: number | null; carbon_footprint: number | null }>) {
  // Group analyses by date
  const dateMap = new Map<string, { scores: number[]; carbons: number[] }>()
  
  // Generate last 7 days
  for (let i = 6; i >= 0; i--) {
    const date = new Date()
    date.setDate(date.getDate() - i)
    const dateStr = date.toLocaleDateString("en-US", { weekday: "short" })
    dateMap.set(dateStr, { scores: [], carbons: [] })
  }
  
  // Add analysis data to dates
  for (const analysis of analyses) {
    const date = new Date(analysis.created_at)
    const dateStr = date.toLocaleDateString("en-US", { weekday: "short" })
    if (dateMap.has(dateStr)) {
      const entry = dateMap.get(dateStr)!
      if (analysis.energy_score !== null) {
        entry.scores.push(analysis.energy_score)
      }
      if (analysis.carbon_footprint !== null) {
        entry.carbons.push(analysis.carbon_footprint * 1000) // Convert to grams
      }
    }
  }
  
  // Calculate averages
  return Array.from(dateMap.entries()).map(([date, data]) => ({
    date,
    score: data.scores.length > 0 
      ? Math.round(data.scores.reduce((a, b) => a + b, 0) / data.scores.length)
      : 70 + Math.floor(Math.random() * 15), // Default value for demo
    carbon: data.carbons.length > 0
      ? Math.round(data.carbons.reduce((a, b) => a + b, 0) / data.carbons.length * 100) / 100
      : 0.1 + Math.random() * 0.15 // Default value for demo
  }))
}
