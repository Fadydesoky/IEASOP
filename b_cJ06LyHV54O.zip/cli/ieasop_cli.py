#!/usr/bin/env python3
"""
IEASOP CLI - Command-line interface for the Intelligent Energy-Aware Software Optimization Platform.

Usage:
    ieasop analyze <path> [--output=<format>] [--threshold=<value>]
    ieasop simulate <path> [--scenarios=<list>]
    ieasop recommend <path> [--priority=<type>]
    ieasop report <project_id> [--format=<type>]
    ieasop login
    ieasop config [--set=<key=value>]
    ieasop --version
    ieasop --help

Options:
    -h --help           Show this help message
    --version           Show version
    --output=<format>   Output format: json, table, csv [default: table]
    --threshold=<value> Energy threshold for warnings [default: 50]
    --scenarios=<list>  Comma-separated simulation scenarios
    --priority=<type>   Priority: energy, performance, balanced [default: balanced]
    --format=<type>     Report format: pdf, html, markdown [default: markdown]
    --set=<key=value>   Set configuration value
"""

import argparse
import json
import os
import sys
from pathlib import Path
from typing import Optional
import urllib.request
import urllib.error

__version__ = "1.0.0"

# Default API endpoint
DEFAULT_API_URL = os.environ.get("IEASOP_API_URL", "http://localhost:8000")

# Config file path
CONFIG_PATH = Path.home() / ".ieasop" / "config.json"


class Colors:
    """ANSI color codes for terminal output."""
    HEADER = '\033[95m'
    BLUE = '\033[94m'
    CYAN = '\033[96m'
    GREEN = '\033[92m'
    WARNING = '\033[93m'
    FAIL = '\033[91m'
    ENDC = '\033[0m'
    BOLD = '\033[1m'
    UNDERLINE = '\033[4m'


def colored(text: str, color: str) -> str:
    """Apply color to text if terminal supports it."""
    if sys.stdout.isatty():
        return f"{color}{text}{Colors.ENDC}"
    return text


def load_config() -> dict:
    """Load configuration from file."""
    if CONFIG_PATH.exists():
        with open(CONFIG_PATH, "r") as f:
            return json.load(f)
    return {"api_url": DEFAULT_API_URL, "token": None}


def save_config(config: dict) -> None:
    """Save configuration to file."""
    CONFIG_PATH.parent.mkdir(parents=True, exist_ok=True)
    with open(CONFIG_PATH, "w") as f:
        json.dump(config, f, indent=2)


def api_request(endpoint: str, method: str = "GET", data: Optional[dict] = None) -> dict:
    """Make an API request to the IEASOP backend."""
    config = load_config()
    url = f"{config['api_url']}{endpoint}"
    
    headers = {"Content-Type": "application/json"}
    if config.get("token"):
        headers["Authorization"] = f"Bearer {config['token']}"
    
    request_data = json.dumps(data).encode() if data else None
    req = urllib.request.Request(url, data=request_data, headers=headers, method=method)
    
    try:
        with urllib.request.urlopen(req, timeout=30) as response:
            return json.loads(response.read().decode())
    except urllib.error.HTTPError as e:
        error_body = e.read().decode() if e.fp else str(e)
        raise Exception(f"API Error ({e.code}): {error_body}")
    except urllib.error.URLError as e:
        raise Exception(f"Connection Error: {e.reason}")


def print_table(headers: list, rows: list) -> None:
    """Print data as a formatted table."""
    if not rows:
        print("No data to display.")
        return
    
    # Calculate column widths
    widths = [len(h) for h in headers]
    for row in rows:
        for i, cell in enumerate(row):
            widths[i] = max(widths[i], len(str(cell)))
    
    # Print header
    header_line = " | ".join(h.ljust(widths[i]) for i, h in enumerate(headers))
    print(colored(header_line, Colors.BOLD))
    print("-" * len(header_line))
    
    # Print rows
    for row in rows:
        print(" | ".join(str(cell).ljust(widths[i]) for i, cell in enumerate(row)))


def analyze_code(path: str, output_format: str, threshold: float) -> None:
    """Analyze code for energy efficiency."""
    print(colored(f"\n[IEASOP] Analyzing: {path}\n", Colors.HEADER))
    
    # Check if path exists
    target_path = Path(path)
    if not target_path.exists():
        print(colored(f"Error: Path '{path}' does not exist.", Colors.FAIL))
        sys.exit(1)
    
    # Collect files to analyze
    files = []
    if target_path.is_file():
        files = [target_path]
    else:
        for ext in [".py", ".js", ".ts", ".tsx", ".java", ".cpp", ".c", ".go", ".rs"]:
            files.extend(target_path.rglob(f"*{ext}"))
    
    if not files:
        print(colored("No supported source files found.", Colors.WARNING))
        return
    
    print(f"Found {len(files)} source files to analyze.\n")
    
    # Prepare analysis request
    file_contents = {}
    for file_path in files[:50]:  # Limit to 50 files
        try:
            with open(file_path, "r", encoding="utf-8", errors="ignore") as f:
                content = f.read()
                if len(content) < 100000:  # Skip very large files
                    file_contents[str(file_path)] = content
        except Exception:
            continue
    
    try:
        result = api_request("/cli/analyze", "POST", {
            "files": file_contents,
            "threshold": threshold
        })
    except Exception as e:
        # Fallback to local analysis simulation
        print(colored("API unavailable. Running local analysis simulation...\n", Colors.WARNING))
        result = simulate_local_analysis(file_contents, threshold)
    
    # Output results
    if output_format == "json":
        print(json.dumps(result, indent=2))
    elif output_format == "csv":
        print("file,energy_score,hotspots,recommendations")
        for file_result in result.get("files", []):
            print(f"{file_result['path']},{file_result['energy_score']},{file_result['hotspot_count']},{file_result['recommendation_count']}")
    else:
        # Table format
        print(colored("=== Energy Analysis Results ===\n", Colors.BOLD))
        
        # Summary
        summary = result.get("summary", {})
        print(f"Total Files Analyzed: {summary.get('total_files', len(file_contents))}")
        print(f"Overall Energy Score: {colored(str(summary.get('overall_score', 'N/A')), Colors.GREEN if summary.get('overall_score', 0) >= 70 else Colors.WARNING)}")
        print(f"Estimated CO2 Impact: {summary.get('co2_estimate', 'N/A')} kg/month")
        print(f"Potential Savings: {summary.get('potential_savings', 'N/A')}%\n")
        
        # Hotspots
        hotspots = result.get("hotspots", [])
        if hotspots:
            print(colored("=== Energy Hotspots ===\n", Colors.BOLD))
            headers = ["File", "Line", "Severity", "Issue", "Impact"]
            rows = [
                [h["file"][:40], h["line"], h["severity"], h["issue"][:30], h["impact"]]
                for h in hotspots[:10]
            ]
            print_table(headers, rows)
            print()
        
        # Top recommendations
        recommendations = result.get("recommendations", [])
        if recommendations:
            print(colored("=== Top Recommendations ===\n", Colors.BOLD))
            for i, rec in enumerate(recommendations[:5], 1):
                severity_color = Colors.FAIL if rec.get("priority") == "high" else Colors.WARNING if rec.get("priority") == "medium" else Colors.GREEN
                print(f"{i}. [{colored(rec.get('priority', 'medium').upper(), severity_color)}] {rec.get('title', 'N/A')}")
                print(f"   {rec.get('description', '')[:80]}...")
                print(f"   Estimated savings: {rec.get('savings', 'N/A')}%\n")


def simulate_local_analysis(file_contents: dict, threshold: float) -> dict:
    """Simulate local analysis when API is unavailable."""
    import hashlib
    import re
    
    hotspots = []
    recommendations = []
    total_score = 0
    
    patterns = {
        "nested_loops": (r"for.*:\s*\n\s*for|while.*:\s*\n\s*while", "Nested loop detected", "high", 15),
        "recursive_call": (r"def\s+(\w+).*\n(?:.*\n)*?\s+\1\s*\(", "Recursive function", "medium", 8),
        "global_var": (r"^\s*global\s+\w+", "Global variable usage", "low", 3),
        "large_list_comp": (r"\[.*for.*for.*\]", "Nested list comprehension", "medium", 10),
        "sleep_call": (r"time\.sleep|asyncio\.sleep", "Sleep/delay detected", "info", 2),
        "print_in_loop": (r"for.*:\s*\n(?:\s+.*\n)*?\s+print\(", "Print statement in loop", "low", 5),
    }
    
    for file_path, content in file_contents.items():
        file_score = 85  # Base score
        lines = content.split("\n")
        
        for pattern_name, (pattern, issue, severity, impact) in patterns.items():
            matches = list(re.finditer(pattern, content, re.MULTILINE))
            for match in matches:
                line_no = content[:match.start()].count("\n") + 1
                file_score -= impact
                hotspots.append({
                    "file": file_path.split("/")[-1],
                    "line": line_no,
                    "severity": severity,
                    "issue": issue,
                    "impact": f"-{impact}%"
                })
        
        total_score += max(0, min(100, file_score))
    
    avg_score = total_score // len(file_contents) if file_contents else 0
    
    # Generate recommendations based on hotspots
    if any(h["issue"] == "Nested loop detected" for h in hotspots):
        recommendations.append({
            "priority": "high",
            "title": "Optimize nested loops",
            "description": "Consider using vectorized operations, caching, or algorithmic improvements to reduce nested loop complexity.",
            "savings": "15-25"
        })
    
    if any(h["issue"] == "Print statement in loop" for h in hotspots):
        recommendations.append({
            "priority": "medium",
            "title": "Remove debug prints from loops",
            "description": "I/O operations inside loops significantly impact performance and energy consumption.",
            "savings": "5-10"
        })
    
    recommendations.append({
        "priority": "low",
        "title": "Enable code caching",
        "description": "Implement memoization for frequently called functions with deterministic outputs.",
        "savings": "3-8"
    })
    
    return {
        "summary": {
            "total_files": len(file_contents),
            "overall_score": avg_score,
            "co2_estimate": round(len(file_contents) * 0.02, 2),
            "potential_savings": 15 if hotspots else 5
        },
        "hotspots": hotspots[:20],
        "recommendations": recommendations
    }


def run_simulation(path: str, scenarios: Optional[str]) -> None:
    """Run energy simulation for code."""
    print(colored(f"\n[IEASOP] Running simulation for: {path}\n", Colors.HEADER))
    
    scenario_list = scenarios.split(",") if scenarios else ["baseline", "optimized"]
    
    print(f"Scenarios: {', '.join(scenario_list)}\n")
    
    try:
        result = api_request("/cli/simulate", "POST", {
            "path": path,
            "scenarios": scenario_list
        })
    except Exception:
        # Simulate locally
        print(colored("API unavailable. Running local simulation...\n", Colors.WARNING))
        result = {
            "scenarios": [
                {"name": s, "energy_kwh": round(0.5 + hash(s) % 10 / 10, 2), "co2_kg": round(0.2 + hash(s) % 5 / 10, 2)}
                for s in scenario_list
            ]
        }
    
    print(colored("=== Simulation Results ===\n", Colors.BOLD))
    headers = ["Scenario", "Energy (kWh/month)", "CO2 (kg/month)", "Relative"]
    
    baseline = result["scenarios"][0]["energy_kwh"] if result["scenarios"] else 1
    rows = [
        [s["name"], f"{s['energy_kwh']:.2f}", f"{s['co2_kg']:.2f}", f"{(s['energy_kwh']/baseline)*100:.0f}%"]
        for s in result["scenarios"]
    ]
    print_table(headers, rows)


def generate_recommendations(path: str, priority: str) -> None:
    """Generate optimization recommendations."""
    print(colored(f"\n[IEASOP] Generating recommendations for: {path}\n", Colors.HEADER))
    print(f"Priority focus: {priority}\n")
    
    try:
        result = api_request("/cli/recommend", "POST", {
            "path": path,
            "priority": priority
        })
    except Exception:
        # Local recommendations
        print(colored("API unavailable. Generating local recommendations...\n", Colors.WARNING))
        result = {
            "recommendations": [
                {"id": 1, "title": "Use lazy evaluation", "category": "performance", "impact": "medium", "effort": "low"},
                {"id": 2, "title": "Implement connection pooling", "category": "resources", "impact": "high", "effort": "medium"},
                {"id": 3, "title": "Add response caching", "category": "energy", "impact": "high", "effort": "low"},
                {"id": 4, "title": "Optimize database queries", "category": "energy", "impact": "high", "effort": "high"},
                {"id": 5, "title": "Use async/await patterns", "category": "performance", "impact": "medium", "effort": "medium"},
            ]
        }
    
    print(colored("=== Optimization Recommendations ===\n", Colors.BOLD))
    headers = ["#", "Recommendation", "Category", "Impact", "Effort"]
    rows = [
        [r["id"], r["title"][:35], r["category"], r["impact"], r["effort"]]
        for r in result["recommendations"]
    ]
    print_table(headers, rows)


def generate_report(project_id: str, report_format: str) -> None:
    """Generate an analysis report."""
    print(colored(f"\n[IEASOP] Generating {report_format.upper()} report for project: {project_id}\n", Colors.HEADER))
    
    try:
        result = api_request(f"/cli/report/{project_id}?format={report_format}")
        
        if report_format == "markdown":
            print(result.get("content", "No report content available."))
        else:
            output_file = f"ieasop_report_{project_id}.{report_format}"
            with open(output_file, "w") as f:
                f.write(result.get("content", ""))
            print(colored(f"Report saved to: {output_file}", Colors.GREEN))
    except Exception as e:
        print(colored(f"Error generating report: {e}", Colors.FAIL))


def login() -> None:
    """Authenticate with IEASOP API."""
    print(colored("\n[IEASOP] Login\n", Colors.HEADER))
    
    email = input("Email: ")
    password = input("Password: ")
    
    try:
        result = api_request("/auth/login", "POST", {
            "email": email,
            "password": password
        })
        
        config = load_config()
        config["token"] = result.get("access_token")
        save_config(config)
        
        print(colored("\nLogin successful!", Colors.GREEN))
    except Exception as e:
        print(colored(f"\nLogin failed: {e}", Colors.FAIL))


def configure(set_value: Optional[str]) -> None:
    """View or update configuration."""
    config = load_config()
    
    if set_value:
        key, value = set_value.split("=", 1)
        config[key] = value
        save_config(config)
        print(colored(f"Set {key} = {value}", Colors.GREEN))
    else:
        print(colored("\n[IEASOP] Configuration\n", Colors.HEADER))
        for key, value in config.items():
            display_value = "***" if key == "token" and value else value
            print(f"  {key}: {display_value}")


def main():
    """Main entry point for CLI."""
    parser = argparse.ArgumentParser(
        description="IEASOP - Intelligent Energy-Aware Software Optimization Platform CLI",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  ieasop analyze ./src --output=table
  ieasop simulate ./src --scenarios=baseline,optimized,aggressive
  ieasop recommend ./src --priority=energy
  ieasop report proj_123 --format=markdown
  ieasop login
  ieasop config --set=api_url=https://api.ieasop.io
        """
    )
    
    parser.add_argument("--version", action="version", version=f"IEASOP CLI v{__version__}")
    
    subparsers = parser.add_subparsers(dest="command", help="Available commands")
    
    # Analyze command
    analyze_parser = subparsers.add_parser("analyze", help="Analyze code for energy efficiency")
    analyze_parser.add_argument("path", help="Path to analyze (file or directory)")
    analyze_parser.add_argument("--output", "-o", choices=["json", "table", "csv"], default="table", help="Output format")
    analyze_parser.add_argument("--threshold", "-t", type=float, default=50, help="Energy threshold for warnings")
    
    # Simulate command
    simulate_parser = subparsers.add_parser("simulate", help="Run energy simulations")
    simulate_parser.add_argument("path", help="Path to simulate")
    simulate_parser.add_argument("--scenarios", "-s", help="Comma-separated list of scenarios")
    
    # Recommend command
    recommend_parser = subparsers.add_parser("recommend", help="Generate optimization recommendations")
    recommend_parser.add_argument("path", help="Path to analyze")
    recommend_parser.add_argument("--priority", "-p", choices=["energy", "performance", "balanced"], default="balanced", help="Optimization priority")
    
    # Report command
    report_parser = subparsers.add_parser("report", help="Generate analysis report")
    report_parser.add_argument("project_id", help="Project ID")
    report_parser.add_argument("--format", "-f", choices=["pdf", "html", "markdown"], default="markdown", help="Report format")
    
    # Login command
    subparsers.add_parser("login", help="Authenticate with IEASOP API")
    
    # Config command
    config_parser = subparsers.add_parser("config", help="View or update configuration")
    config_parser.add_argument("--set", help="Set configuration value (key=value)")
    
    args = parser.parse_args()
    
    if not args.command:
        parser.print_help()
        sys.exit(0)
    
    try:
        if args.command == "analyze":
            analyze_code(args.path, args.output, args.threshold)
        elif args.command == "simulate":
            run_simulation(args.path, args.scenarios)
        elif args.command == "recommend":
            generate_recommendations(args.path, args.priority)
        elif args.command == "report":
            generate_report(args.project_id, args.format)
        elif args.command == "login":
            login()
        elif args.command == "config":
            configure(args.set)
    except KeyboardInterrupt:
        print(colored("\n\nOperation cancelled.", Colors.WARNING))
        sys.exit(130)
    except Exception as e:
        print(colored(f"\nError: {e}", Colors.FAIL))
        sys.exit(1)


if __name__ == "__main__":
    main()
