"use client"

import { useState } from "react"
import { AppSidebar } from "@/components/app-sidebar"
import { SidebarProvider, SidebarInset, SidebarTrigger } from "@/components/ui/sidebar"
import { Separator } from "@/components/ui/separator"
import {
  Breadcrumb,
  BreadcrumbItem,
  BreadcrumbList,
  BreadcrumbPage,
} from "@/components/ui/breadcrumb"
import { OverviewPage } from "@/components/pages/overview"
import { CodeInsightsPage } from "@/components/pages/code-insights"
import { SimulationLabPage } from "@/components/pages/simulation-lab"
import { RecommendationsPage } from "@/components/pages/recommendations"
import { CICDPage } from "@/components/pages/cicd"
import { SettingsPage } from "@/components/pages/settings"

export type PageType = "overview" | "code-insights" | "simulation-lab" | "recommendations" | "cicd" | "settings"

const pageNames: Record<PageType, string> = {
  "overview": "Dashboard Overview",
  "code-insights": "Code Insights",
  "simulation-lab": "Simulation Lab",
  "recommendations": "Recommendations",
  "cicd": "CI/CD Integration",
  "settings": "Settings"
}

export default function HomePage() {
  const [currentPage, setCurrentPage] = useState<PageType>("overview")

  const renderPage = () => {
    switch (currentPage) {
      case "overview":
        return <OverviewPage onNavigate={setCurrentPage} />
      case "code-insights":
        return <CodeInsightsPage />
      case "simulation-lab":
        return <SimulationLabPage />
      case "recommendations":
        return <RecommendationsPage />
      case "cicd":
        return <CICDPage />
      case "settings":
        return <SettingsPage />
      default:
        return <OverviewPage />
    }
  }

  return (
    <SidebarProvider>
      <AppSidebar currentPage={currentPage} onNavigate={setCurrentPage} />
      <SidebarInset>
        <header className="flex h-16 shrink-0 items-center gap-2 border-b px-4">
          <SidebarTrigger className="-ml-1" />
          <Separator orientation="vertical" className="mr-2 h-4" />
          <Breadcrumb>
            <BreadcrumbList>
              <BreadcrumbItem>
                <BreadcrumbPage>{pageNames[currentPage]}</BreadcrumbPage>
              </BreadcrumbItem>
            </BreadcrumbList>
          </Breadcrumb>
        </header>
        <main className="flex-1 overflow-auto p-6">
          {renderPage()}
        </main>
      </SidebarInset>
    </SidebarProvider>
  )
}
