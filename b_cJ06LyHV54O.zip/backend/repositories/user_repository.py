"""
User Repository
Database operations for User entities
"""

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.orm import selectinload

from models.user import User
from .base import BaseRepository


class UserRepository(BaseRepository[User]):
    """Repository for User entity operations."""
    
    def __init__(self, session: AsyncSession) -> None:
        super().__init__(session, User)
    
    async def get_by_email(self, email: str) -> User | None:
        """Find a user by their email address."""
        result = await self._session.execute(
            select(User).where(User.email == email)
        )
        return result.scalar_one_or_none()
    
    async def get_with_projects(self, user_id: str) -> User | None:
        """Get a user with their projects eagerly loaded."""
        result = await self._session.execute(
            select(User)
            .where(User.id == user_id)
            .options(selectinload(User.projects))
        )
        return result.scalar_one_or_none()
    
    async def email_exists(self, email: str) -> bool:
        """Check if an email is already registered."""
        result = await self._session.execute(
            select(User.id).where(User.email == email)
        )
        return result.scalar_one_or_none() is not None
    
    async def create_user(self, email: str) -> User:
        """Create a new user with the given email."""
        user = User(email=email)
        return await self.create(user)
