"""
IEASOP Backend Configuration
"""

import os
from functools import lru_cache
from pydantic import BaseModel


class Settings(BaseModel):
    """Application settings."""
    supabase_url: str = os.environ.get("SUPABASE_URL", "")
    supabase_key: str = os.environ.get("SUPABASE_ANON_KEY", "")
    supabase_service_key: str = os.environ.get("SUPABASE_SERVICE_ROLE_KEY", "")
    
    # ML Model settings
    model_path: str = "models/xgboost_energy.json"
    feature_config_path: str = "models/feature_config.json"
    
    # Energy calculation constants
    base_energy_per_loc: float = 0.001  # kWh per line of code
    carbon_per_kwh: float = 0.4  # kg CO2 per kWh (global average)


@lru_cache
def get_settings() -> Settings:
    """Get cached settings."""
    return Settings()
