"""
Unit of Work Pattern
Manages database transactions and repository access
"""

from typing import Self
from sqlalchemy.ext.asyncio import AsyncSession

from .session import async_session_factory
from repositories import (
    UserRepository,
    ProjectRepository,
    AnalysisRepository,
    IssueRepository,
    RecommendationRepository,
    MetricRepository,
)


class UnitOfWork:
    """
    Unit of Work pattern implementation.
    Provides a single point of access to all repositories
    and manages database transactions.
    """
    
    def __init__(self) -> None:
        self._session: AsyncSession | None = None
    
    async def __aenter__(self) -> Self:
        """Enter the context manager and create a session."""
        self._session = async_session_factory()
        
        # Initialize repositories with the session
        self.users = UserRepository(self._session)
        self.projects = ProjectRepository(self._session)
        self.analyses = AnalysisRepository(self._session)
        self.issues = IssueRepository(self._session)
        self.recommendations = RecommendationRepository(self._session)
        self.metrics = MetricRepository(self._session)
        
        return self
    
    async def __aexit__(self, exc_type, exc_val, exc_tb) -> None:
        """Exit the context manager, handling commit/rollback."""
        if exc_type is not None:
            await self.rollback()
        await self._session.close()
    
    async def commit(self) -> None:
        """Commit the current transaction."""
        if self._session:
            await self._session.commit()
    
    async def rollback(self) -> None:
        """Rollback the current transaction."""
        if self._session:
            await self._session.rollback()
    
    async def flush(self) -> None:
        """Flush pending changes to the database."""
        if self._session:
            await self._session.flush()
