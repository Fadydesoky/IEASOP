"""
Metric Model
"""

from sqlalchemy import String, Float, ForeignKey
from sqlalchemy.orm import Mapped, mapped_column, relationship
from typing import TYPE_CHECKING, Optional

from .base import Base, TimestampMixin, generate_uuid

if TYPE_CHECKING:
    from .analysis import Analysis


class Metric(Base, TimestampMixin):
    """Metric model matching the existing metrics table."""
    
    __tablename__ = "metrics"
    
    id: Mapped[str] = mapped_column(
        String,
        primary_key=True,
        default=generate_uuid
    )
    analysis_id: Mapped[str] = mapped_column(
        String,
        ForeignKey("analyses.id", ondelete="CASCADE"),
        nullable=False,
        index=True
    )
    cpu_usage: Mapped[Optional[float]] = mapped_column(
        Float,
        nullable=True
    )
    ram_usage: Mapped[Optional[float]] = mapped_column(
        Float,
        nullable=True
    )
    execution_time: Mapped[Optional[float]] = mapped_column(
        Float,
        nullable=True
    )
    temperature: Mapped[Optional[float]] = mapped_column(
        Float,
        nullable=True
    )
    
    # Relationships
    analysis: Mapped["Analysis"] = relationship(
        "Analysis",
        back_populates="metrics"
    )
    
    def __repr__(self) -> str:
        return f"<Metric(id={self.id}, cpu_usage={self.cpu_usage})>"
