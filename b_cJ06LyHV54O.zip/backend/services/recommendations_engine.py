"""
IEASOP Recommendations Engine
Generate energy optimization recommendations based on analysis
"""

from dataclasses import dataclass
from typing import Optional


@dataclass
class Recommendation:
    """Energy optimization recommendation."""
    title: str
    description: str
    category: str
    priority: int
    estimated_savings: float
    original_code: Optional[str]
    suggested_code: Optional[str]


# Recommendation templates for different issue types
RECOMMENDATION_TEMPLATES = {
    "nested_loops": Recommendation(
        title="Optimize Nested Loop Structure",
        description="Nested loops can lead to O(n^2) or worse time complexity, significantly increasing energy consumption. Consider using vectorized operations, hash-based lookups, or algorithm optimization.",
        category="algorithm",
        priority=1,
        estimated_savings=25.0,
        original_code="""for i in items:
    for j in other_items:
        if i.id == j.id:
            process(i, j)""",
        suggested_code="""# Use a hash map for O(n) lookup
lookup = {item.id: item for item in other_items}
for i in items:
    if i.id in lookup:
        process(i, lookup[i.id])"""
    ),
    
    "blocking_io_in_loop": Recommendation(
        title="Replace Blocking IO with Batch Operations",
        description="Synchronous IO operations inside loops cause the CPU to wait, wasting energy. Use batch operations or async IO to process multiple items efficiently.",
        category="io",
        priority=1,
        estimated_savings=40.0,
        original_code="""for url in urls:
    response = requests.get(url)
    process(response)""",
        suggested_code="""import asyncio
import aiohttp

async def fetch_all(urls):
    async with aiohttp.ClientSession() as session:
        tasks = [fetch(session, url) for url in urls]
        return await asyncio.gather(*tasks)

results = asyncio.run(fetch_all(urls))"""
    ),
    
    "memory_allocation_in_loop": Recommendation(
        title="Pre-allocate Memory Outside Loops",
        description="Creating new objects inside loops increases garbage collection pressure and memory fragmentation. Pre-allocate collections when the size is known.",
        category="memory",
        priority=2,
        estimated_savings=15.0,
        original_code="""results = []
for item in items:
    results.append(transform(item))""",
        suggested_code="""# List comprehension is more efficient
results = [transform(item) for item in items]

# Or pre-allocate if size is known
results = [None] * len(items)
for i, item in enumerate(items):
    results[i] = transform(item)"""
    ),
    
    "string_concatenation": Recommendation(
        title="Use String Builder Pattern",
        description="String concatenation in loops creates many intermediate strings, increasing memory usage and GC overhead. Use join() or StringIO for efficient string building.",
        category="memory",
        priority=2,
        estimated_savings=10.0,
        original_code="""result = ""
for item in items:
    result += str(item) + ", " """,
        suggested_code="""# Use join for efficiency
result = ", ".join(str(item) for item in items)"""
    ),
    
    "blocking_sleep": Recommendation(
        title="Replace Sleep with Async Wait",
        description="time.sleep() blocks the entire thread, preventing any useful work. Use asyncio.sleep() in async contexts or consider event-driven patterns.",
        category="concurrency",
        priority=2,
        estimated_savings=20.0,
        original_code="""import time
while not condition:
    time.sleep(1)
    check_condition()""",
        suggested_code="""import asyncio

async def wait_for_condition():
    while not condition:
        await asyncio.sleep(1)
        check_condition()"""
    ),
    
    "global_variable": Recommendation(
        title="Avoid Global Variable Access in Hot Paths",
        description="Accessing global variables is slower than local variables due to scope lookup. Cache globals in local variables for frequently accessed values.",
        category="algorithm",
        priority=3,
        estimated_savings=5.0,
        original_code="""GLOBAL_CONFIG = {...}

def process_items(items):
    for item in items:
        if item.type == GLOBAL_CONFIG['type']:
            ....""",
        suggested_code="""GLOBAL_CONFIG = {...}

def process_items(items):
    # Cache in local variable
    config_type = GLOBAL_CONFIG['type']
    for item in items:
        if item.type == config_type:
            ...."""
    ),
    
    "high_complexity": Recommendation(
        title="Reduce Cyclomatic Complexity",
        description="High cyclomatic complexity indicates many decision paths, making code harder to optimize and often less energy-efficient. Consider extracting methods or using polymorphism.",
        category="algorithm",
        priority=2,
        estimated_savings=15.0,
        original_code=None,
        suggested_code=None
    ),
    
    "no_async": Recommendation(
        title="Consider Async Processing for IO-Bound Work",
        description="IO-bound operations can benefit significantly from async processing, allowing the CPU to do useful work while waiting for IO completion.",
        category="concurrency",
        priority=3,
        estimated_savings=30.0,
        original_code=None,
        suggested_code=None
    ),
}


def generate_recommendations(
    hotspots: list[dict],
    code_metrics: dict,
    energy_score: float
) -> list[Recommendation]:
    """Generate recommendations based on detected issues and metrics."""
    recommendations = []
    
    # Add recommendations for each hotspot
    seen_types = set()
    for hotspot in hotspots:
        issue_type = hotspot.get("issue_type", "")
        if issue_type in RECOMMENDATION_TEMPLATES and issue_type not in seen_types:
            rec = RECOMMENDATION_TEMPLATES[issue_type]
            recommendations.append(rec)
            seen_types.add(issue_type)
    
    # Add general recommendations based on metrics
    if code_metrics.get("cyclomatic_complexity", 0) > 20 and "high_complexity" not in seen_types:
        recommendations.append(RECOMMENDATION_TEMPLATES["high_complexity"])
    
    if code_metrics.get("io_operations", 0) > 5 and code_metrics.get("async_operations", 0) == 0:
        if "no_async" not in seen_types:
            recommendations.append(RECOMMENDATION_TEMPLATES["no_async"])
    
    # Sort by priority and estimated savings
    recommendations.sort(key=lambda r: (r.priority, -r.estimated_savings))
    
    return recommendations


def get_recommendation_summary(recommendations: list[Recommendation]) -> dict:
    """Get summary statistics for recommendations."""
    if not recommendations:
        return {
            "total_recommendations": 0,
            "total_potential_savings": 0,
            "categories": {},
            "priority_distribution": {}
        }
    
    categories = {}
    priorities = {1: 0, 2: 0, 3: 0}
    total_savings = 0
    
    for rec in recommendations:
        categories[rec.category] = categories.get(rec.category, 0) + 1
        priorities[rec.priority] = priorities.get(rec.priority, 0) + 1
        total_savings += rec.estimated_savings
    
    return {
        "total_recommendations": len(recommendations),
        "total_potential_savings": round(total_savings, 2),
        "categories": categories,
        "priority_distribution": {
            "critical": priorities[1],
            "important": priorities[2],
            "suggested": priorities[3]
        }
    }
