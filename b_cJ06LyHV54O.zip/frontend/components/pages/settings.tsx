"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Switch } from "@/components/ui/switch"
import { Separator } from "@/components/ui/separator"
import { Badge } from "@/components/ui/badge"
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select"
import {
  Settings,
  User,
  Key,
  Bell,
  Palette,
  Shield,
  Copy,
  RefreshCw,
  Check,
  Terminal,
} from "lucide-react"

export function SettingsPage() {
  const [apiKey, setApiKey] = useState("ieasop_a1b2c3d4e5f6g7h8i9j0...")
  const [showFullKey, setShowFullKey] = useState(false)
  const [copiedKey, setCopiedKey] = useState(false)
  const [defaultLanguage, setDefaultLanguage] = useState("python")
  const [notifications, setNotifications] = useState({
    analysisComplete: true,
    cicdFail: true,
    weeklyReport: false,
    newRecommendations: true
  })

  const copyApiKey = () => {
    navigator.clipboard.writeText(apiKey)
    setCopiedKey(true)
    setTimeout(() => setCopiedKey(false), 2000)
  }

  const regenerateKey = () => {
    // In real app, this would call the API
    setApiKey("ieasop_" + Math.random().toString(36).substring(2, 26) + "...")
  }

  return (
    <div className="space-y-6 max-w-4xl">
      {/* Header */}
      <div>
        <h2 className="text-2xl font-bold tracking-tight flex items-center gap-2">
          <Settings className="h-6 w-6 text-primary" />
          Settings
        </h2>
        <p className="text-muted-foreground">
          Manage your account and application preferences
        </p>
      </div>

      {/* Profile Section */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <User className="h-5 w-5" />
            Profile
          </CardTitle>
          <CardDescription>
            Your account information
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid gap-4 md:grid-cols-2">
            <div className="space-y-2">
              <Label htmlFor="name">Full Name</Label>
              <Input id="name" placeholder="Your name" defaultValue="Developer" />
            </div>
            <div className="space-y-2">
              <Label htmlFor="email">Email</Label>
              <Input id="email" type="email" placeholder="Email" defaultValue="dev@example.com" />
            </div>
          </div>
          <div className="flex items-center gap-4">
            <Badge variant="secondary">Free Plan</Badge>
            <Button variant="outline" size="sm">Upgrade to Pro</Button>
          </div>
        </CardContent>
      </Card>

      {/* API Key Section */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Key className="h-5 w-5" />
            API Key
          </CardTitle>
          <CardDescription>
            Use this key to authenticate CLI and API requests
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex items-center gap-2">
            <Input
              type={showFullKey ? "text" : "password"}
              value={apiKey}
              readOnly
              className="font-mono"
            />
            <Button variant="outline" size="icon" onClick={copyApiKey}>
              {copiedKey ? (
                <Check className="h-4 w-4 text-green-500" />
              ) : (
                <Copy className="h-4 w-4" />
              )}
            </Button>
          </div>
          <div className="flex items-center gap-4">
            <div className="flex items-center gap-2">
              <Switch
                id="showKey"
                checked={showFullKey}
                onCheckedChange={setShowFullKey}
              />
              <Label htmlFor="showKey">Show full key</Label>
            </div>
            <Button variant="outline" size="sm" onClick={regenerateKey}>
              <RefreshCw className="mr-2 h-4 w-4" />
              Regenerate Key
            </Button>
          </div>
          <p className="text-xs text-muted-foreground">
            Keep this key secret. If compromised, regenerate it immediately.
          </p>
        </CardContent>
      </Card>

      {/* CLI Quick Start */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Terminal className="h-5 w-5" />
            CLI Quick Start
          </CardTitle>
          <CardDescription>
            Install and configure the IEASOP CLI tool
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="space-y-2">
            <Label>Install CLI</Label>
            <pre className="bg-muted p-3 rounded-lg text-sm font-mono">
              npm install -g ieasop
            </pre>
          </div>
          <div className="space-y-2">
            <Label>Configure API Key</Label>
            <pre className="bg-muted p-3 rounded-lg text-sm font-mono">
              ieasop config set api_key YOUR_API_KEY
            </pre>
          </div>
          <div className="space-y-2">
            <Label>Scan a Project</Label>
            <pre className="bg-muted p-3 rounded-lg text-sm font-mono">
              ieasop scan ./your-project
            </pre>
          </div>
        </CardContent>
      </Card>

      {/* Notifications Section */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Bell className="h-5 w-5" />
            Notifications
          </CardTitle>
          <CardDescription>
            Configure how you receive updates
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="flex items-center justify-between">
            <div className="space-y-0.5">
              <Label>Analysis Complete</Label>
              <p className="text-sm text-muted-foreground">
                Notify when code analysis finishes
              </p>
            </div>
            <Switch
              checked={notifications.analysisComplete}
              onCheckedChange={(v) => setNotifications({ ...notifications, analysisComplete: v })}
            />
          </div>
          <Separator />
          <div className="flex items-center justify-between">
            <div className="space-y-0.5">
              <Label>CI/CD Failures</Label>
              <p className="text-sm text-muted-foreground">
                Alert when pipeline checks fail
              </p>
            </div>
            <Switch
              checked={notifications.cicdFail}
              onCheckedChange={(v) => setNotifications({ ...notifications, cicdFail: v })}
            />
          </div>
          <Separator />
          <div className="flex items-center justify-between">
            <div className="space-y-0.5">
              <Label>Weekly Report</Label>
              <p className="text-sm text-muted-foreground">
                Receive weekly energy efficiency summary
              </p>
            </div>
            <Switch
              checked={notifications.weeklyReport}
              onCheckedChange={(v) => setNotifications({ ...notifications, weeklyReport: v })}
            />
          </div>
          <Separator />
          <div className="flex items-center justify-between">
            <div className="space-y-0.5">
              <Label>New Recommendations</Label>
              <p className="text-sm text-muted-foreground">
                Notify when new optimizations are available
              </p>
            </div>
            <Switch
              checked={notifications.newRecommendations}
              onCheckedChange={(v) => setNotifications({ ...notifications, newRecommendations: v })}
            />
          </div>
        </CardContent>
      </Card>

      {/* Preferences Section */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Palette className="h-5 w-5" />
            Preferences
          </CardTitle>
          <CardDescription>
            Customize your experience
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid gap-4 md:grid-cols-2">
            <div className="space-y-2">
              <Label htmlFor="language">Default Language</Label>
              <Select value={defaultLanguage} onValueChange={setDefaultLanguage}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="python">Python</SelectItem>
                  <SelectItem value="javascript">JavaScript</SelectItem>
                  <SelectItem value="typescript">TypeScript</SelectItem>
                  <SelectItem value="java">Java</SelectItem>
                  <SelectItem value="go">Go</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label htmlFor="threshold">Default Threshold</Label>
              <Input id="threshold" type="number" defaultValue="70" min="0" max="100" />
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Danger Zone */}
      <Card className="border-destructive/50">
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-destructive">
            <Shield className="h-5 w-5" />
            Danger Zone
          </CardTitle>
          <CardDescription>
            Irreversible actions
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <p className="font-medium">Delete All Data</p>
              <p className="text-sm text-muted-foreground">
                Permanently delete all your projects and analyses
              </p>
            </div>
            <Button variant="destructive">Delete All Data</Button>
          </div>
          <Separator />
          <div className="flex items-center justify-between">
            <div>
              <p className="font-medium">Delete Account</p>
              <p className="text-sm text-muted-foreground">
                Permanently delete your account and all associated data
              </p>
            </div>
            <Button variant="destructive">Delete Account</Button>
          </div>
        </CardContent>
      </Card>

      {/* Save Button */}
      <div className="flex justify-end">
        <Button size="lg">
          Save Changes
        </Button>
      </div>
    </div>
  )
}
