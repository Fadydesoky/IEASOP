"""
Analysis Model
"""

from sqlalchemy import String, Float, ForeignKey
from sqlalchemy.orm import Mapped, mapped_column, relationship
from typing import TYPE_CHECKING, List, Optional

from .base import Base, TimestampMixin, generate_uuid

if TYPE_CHECKING:
    from .project import Project
    from .issue import Issue
    from .recommendation import Recommendation
    from .metric import Metric


class Analysis(Base, TimestampMixin):
    """Analysis model matching the existing analyses table."""
    
    __tablename__ = "analyses"
    
    id: Mapped[str] = mapped_column(
        String,
        primary_key=True,
        default=generate_uuid
    )
    project_id: Mapped[str] = mapped_column(
        String,
        ForeignKey("projects.id", ondelete="CASCADE"),
        nullable=False,
        index=True
    )
    energy_score: Mapped[Optional[float]] = mapped_column(
        Float,
        nullable=True
    )
    model_used: Mapped[Optional[str]] = mapped_column(
        String,
        nullable=True
    )
    
    # Relationships
    project: Mapped["Project"] = relationship(
        "Project",
        back_populates="analyses"
    )
    issues: Mapped[List["Issue"]] = relationship(
        "Issue",
        back_populates="analysis",
        cascade="all, delete-orphan"
    )
    recommendations: Mapped[List["Recommendation"]] = relationship(
        "Recommendation",
        back_populates="analysis",
        cascade="all, delete-orphan"
    )
    metrics: Mapped[List["Metric"]] = relationship(
        "Metric",
        back_populates="analysis",
        cascade="all, delete-orphan"
    )
    
    def __repr__(self) -> str:
        return f"<Analysis(id={self.id}, energy_score={self.energy_score})>"
