"""
User Model
"""

from sqlalchemy import String
from sqlalchemy.orm import Mapped, mapped_column, relationship
from typing import TYPE_CHECKING, List

from .base import Base, TimestampMixin, generate_uuid

if TYPE_CHECKING:
    from .project import Project


class User(Base, TimestampMixin):
    """User model matching the existing users table."""
    
    __tablename__ = "users"
    
    id: Mapped[str] = mapped_column(
        String,
        primary_key=True,
        default=generate_uuid
    )
    email: Mapped[str] = mapped_column(
        String,
        unique=True,
        nullable=False,
        index=True
    )
    
    # Relationships
    projects: Mapped[List["Project"]] = relationship(
        "Project",
        back_populates="user",
        cascade="all, delete-orphan"
    )
    
    def __repr__(self) -> str:
        return f"<User(id={self.id}, email={self.email})>"
