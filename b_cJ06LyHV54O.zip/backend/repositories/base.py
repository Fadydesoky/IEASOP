"""
Base Repository
Abstract base class for all repositories
"""

from typing import TypeVar, Generic, Type, Sequence, Any
from sqlalchemy import select, update, delete
from sqlalchemy.ext.asyncio import AsyncSession

from models.base import Base

ModelType = TypeVar("ModelType", bound=Base)


class BaseRepository(Generic[ModelType]):
    """
    Generic base repository providing common CRUD operations.
    All specific repositories inherit from this class.
    """
    
    def __init__(self, session: AsyncSession, model: Type[ModelType]) -> None:
        self._session = session
        self._model = model
    
    async def get_by_id(self, id: str) -> ModelType | None:
        """Retrieve an entity by its primary key."""
        result = await self._session.execute(
            select(self._model).where(self._model.id == id)
        )
        return result.scalar_one_or_none()
    
    async def get_all(
        self,
        skip: int = 0,
        limit: int = 100
    ) -> Sequence[ModelType]:
        """Retrieve all entities with pagination."""
        result = await self._session.execute(
            select(self._model).offset(skip).limit(limit)
        )
        return result.scalars().all()
    
    async def create(self, entity: ModelType) -> ModelType:
        """Create a new entity."""
        self._session.add(entity)
        await self._session.flush()
        await self._session.refresh(entity)
        return entity
    
    async def create_many(self, entities: list[ModelType]) -> list[ModelType]:
        """Create multiple entities."""
        self._session.add_all(entities)
        await self._session.flush()
        for entity in entities:
            await self._session.refresh(entity)
        return entities
    
    async def update(
        self,
        id: str,
        values: dict[str, Any]
    ) -> ModelType | None:
        """Update an entity by ID."""
        await self._session.execute(
            update(self._model)
            .where(self._model.id == id)
            .values(**values)
        )
        await self._session.flush()
        return await self.get_by_id(id)
    
    async def delete(self, id: str) -> bool:
        """Delete an entity by ID."""
        result = await self._session.execute(
            delete(self._model).where(self._model.id == id)
        )
        await self._session.flush()
        return result.rowcount > 0
    
    async def exists(self, id: str) -> bool:
        """Check if an entity exists by ID."""
        result = await self._session.execute(
            select(self._model.id).where(self._model.id == id)
        )
        return result.scalar_one_or_none() is not None
    
    async def count(self) -> int:
        """Count all entities."""
        from sqlalchemy import func
        result = await self._session.execute(
            select(func.count()).select_from(self._model)
        )
        return result.scalar_one()
