import { createClient } from "@/lib/supabase/server"
import { createAdminClient } from "@/lib/supabase/admin"
import { NextResponse } from "next/server"

// Demo user/project IDs for unauthenticated users
const DEMO_USER_ID = "00000000-0000-0000-0000-000000000001"
const DEMO_PROJECT_ID = "00000000-0000-0000-0000-000000000002"

export async function GET() {
  try {
    const supabase = createAdminClient()
    
    const { data, error } = await supabase
      .from("simulations")
      .select("*")
      .order("created_at", { ascending: false })
    
    if (error) {
      console.error("[v0] Supabase error fetching simulations:", error)
      return NextResponse.json(
        { error: error.message },
        { status: 500 }
      )
    }
    
    return NextResponse.json(data ?? [])
  } catch (err) {
    console.error("[v0] Error in GET /api/simulations:", err)
    return NextResponse.json(
      { error: "Failed to fetch simulations" },
      { status: 500 }
    )
  }
}

export async function POST(request: Request) {
  try {
    const userSupabase = await createClient()
    const adminSupabase = createAdminClient()
    const body = await request.json()
    
    console.log("[v0] Received simulation request:", JSON.stringify(body, null, 2))
    
    const { code, language, scenarios, project_id, user_id } = body
    
    if (!code || !scenarios || scenarios.length === 0) {
      return NextResponse.json(
        { error: "Code and at least one scenario are required" },
        { status: 400 }
      )
    }
    
    // Calculate baseline metrics from code
    const baselineMetrics = analyzeCodeForSimulation(code, language, {
      cpu_cores: 4,
      ram_gb: 8,
      execution_time_ms: 1000
    })
    
    console.log("[v0] Baseline metrics:", baselineMetrics)
    
    // Run each scenario
    const scenarioResults = scenarios.map((scenario: Record<string, number | string>) => {
      const scenarioMetrics = analyzeCodeForSimulation(code, language, scenario)
      
      const deltaScore = scenarioMetrics.energy_score - baselineMetrics.energy_score
      const deltaCarbon = scenarioMetrics.carbon_footprint - baselineMetrics.carbon_footprint
      const improvementPercent = baselineMetrics.energy_score > 0 
        ? ((scenarioMetrics.energy_score - baselineMetrics.energy_score) / baselineMetrics.energy_score) * 100
        : 0
      
      return {
        name: scenario.name || "Custom Scenario",
        config: scenario,
        energy_score: scenarioMetrics.energy_score,
        carbon_footprint: scenarioMetrics.carbon_footprint,
        delta_score: deltaScore,
        delta_carbon: deltaCarbon,
        improvement_percent: improvementPercent
      }
    })
    
    // Get the current user or use demo user
    const { data: { user } } = await userSupabase.auth.getUser()
    let effectiveUserId = user?.id || user_id || DEMO_USER_ID
    let effectiveProjectId = project_id || DEMO_PROJECT_ID
    
    // Ensure demo user/project exist (using admin client)
    if (effectiveUserId === DEMO_USER_ID) {
      const { data: demoProfile } = await adminSupabase
        .from("profiles")
        .select("id")
        .eq("id", DEMO_USER_ID)
        .single()
      
      if (!demoProfile) {
        await adminSupabase
          .from("profiles")
          .insert({
            id: DEMO_USER_ID,
            full_name: "Demo User",
            email: "demo@ieasop.local",
            subscription_tier: "free"
          })
      }
      
      const { data: demoProject } = await adminSupabase
        .from("projects")
        .select("id")
        .eq("id", DEMO_PROJECT_ID)
        .single()
      
      if (!demoProject) {
        await adminSupabase
          .from("projects")
          .insert({
            id: DEMO_PROJECT_ID,
            user_id: DEMO_USER_ID,
            name: "Demo Project",
            description: "Auto-created project for simulations",
            language: language || "python",
            status: "active"
          })
      }
    }
    
    // Save simulation to database using admin client
    const simulationData = {
      project_id: effectiveProjectId,
      user_id: effectiveUserId,
      name: `Simulation ${new Date().toISOString()}`,
      scenario_config: scenarios,
      baseline_metrics: baselineMetrics,
      optimized_metrics: scenarioResults[0],
      savings_summary: {
        energy_improvement: scenarioResults[0]?.improvement_percent || 0,
        carbon_reduction: scenarioResults[0]?.delta_carbon || 0
      },
      status: "completed",
      completed_at: new Date().toISOString()
    }
    
    const { error: simError } = await adminSupabase
      .from("simulations")
      .insert(simulationData)
    
    if (simError) {
      console.error("[v0] Error inserting simulation:", simError)
    }
    
    // Return results
    return NextResponse.json({
      baseline: baselineMetrics,
      scenarios: scenarioResults
    })
    
  } catch (err) {
    console.error("[v0] Error in POST /api/simulations:", err)
    return NextResponse.json(
      { error: err instanceof Error ? err.message : "Simulation failed" },
      { status: 500 }
    )
  }
}

function analyzeCodeForSimulation(
  code: string, 
  language: string, 
  scenario: Record<string, number | string>
): { energy_score: number; carbon_footprint: number } {
  const lines = code.split("\n")
  const linesOfCode = lines.filter(l => l.trim() && !l.trim().startsWith("#")).length
  
  // Extract scenario parameters
  const cpuCores = Number(scenario.cpu_cores) || 4
  const ramGb = Number(scenario.ram_gb) || 8
  const executionTime = Number(scenario.execution_time_ms) || 1000
  
  // Calculate complexity metrics
  const forLoops = (code.match(/\bfor\b/gi) || []).length
  const whileLoops = (code.match(/\bwhile\b/gi) || []).length
  const conditionals = (code.match(/\b(if|else|elif|switch|case)\b/gi) || []).length
  const ioOps = (code.match(/\b(open|read|write|print|fetch)\b/gi) || []).length
  
  const complexity = conditionals + forLoops + whileLoops + 1
  
  // Base score starts at 100
  let energyScore = 100
  
  // Complexity penalty
  energyScore -= Math.min(25, complexity * 1.5)
  
  // I/O operations penalty
  energyScore -= Math.min(15, ioOps * 3)
  
  // Resource efficiency bonuses/penalties
  // More CPU cores = better parallelization potential
  if (cpuCores >= 8) energyScore += 5
  else if (cpuCores <= 2) energyScore -= 5
  
  // More RAM = better caching
  if (ramGb >= 16) energyScore += 3
  else if (ramGb <= 4) energyScore -= 3
  
  // Shorter execution time = better
  if (executionTime <= 500) energyScore += 5
  else if (executionTime >= 5000) energyScore -= 10
  
  energyScore = Math.max(0, Math.min(100, Math.round(energyScore)))
  
  // Carbon footprint calculation
  const baseWatts = 50 + (cpuCores * 10)
  const hours = executionTime / (1000 * 60 * 60)
  const energyKwh = (baseWatts / 1000) * hours
  const co2Factor = 0.5
  const complexityMultiplier = 1 + (complexity / 100)
  const carbonFootprint = energyKwh * co2Factor * complexityMultiplier
  
  return {
    energy_score: energyScore,
    carbon_footprint: carbonFootprint
  }
}
