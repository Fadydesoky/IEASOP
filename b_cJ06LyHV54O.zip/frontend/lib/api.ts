/**
 * IEASOP API Client
 * Handles all communication with the backend services
 */

const API_BASE_URL = process.env.NEXT_PUBLIC_API_URL || '/api'

interface ApiOptions {
  method?: 'GET' | 'POST' | 'PUT' | 'DELETE' | 'PATCH'
  body?: unknown
  headers?: Record<string, string>
}

class ApiError extends Error {
  constructor(
    public status: number,
    message: string,
    public details?: unknown
  ) {
    super(message)
    this.name = 'ApiError'
  }
}

async function apiRequest<T>(endpoint: string, options: ApiOptions = {}): Promise<T> {
  const { method = 'GET', body, headers = {} } = options

  const config: RequestInit = {
    method,
    headers: {
      'Content-Type': 'application/json',
      ...headers,
    },
    credentials: 'include',
  }

  if (body) {
    config.body = JSON.stringify(body)
  }

  const response = await fetch(`${API_BASE_URL}${endpoint}`, config)

  if (!response.ok) {
    const errorData = await response.json().catch(() => ({}))
    throw new ApiError(response.status, errorData.message || 'An error occurred', errorData)
  }

  return response.json()
}

// Project APIs
export const projectsApi = {
  list: () => apiRequest<Project[]>('/projects'),
  get: (id: string) => apiRequest<Project>(`/projects/${id}`),
  create: (data: CreateProjectData) => apiRequest<Project>('/projects', { method: 'POST', body: data }),
  update: (id: string, data: Partial<Project>) => apiRequest<Project>(`/projects/${id}`, { method: 'PUT', body: data }),
  delete: (id: string) => apiRequest<void>(`/projects/${id}`, { method: 'DELETE' }),
}

// Analysis APIs
export const analysisApi = {
  start: (projectId: string, config?: AnalysisConfig) =>
    apiRequest<Analysis>(`/analyses/projects/${projectId}/analyze`, { method: 'POST', body: config }),
  get: (id: string) => apiRequest<Analysis>(`/analyses/${id}`),
  list: (projectId: string) => apiRequest<Analysis[]>(`/analyses/projects/${projectId}`),
  getHotspots: (analysisId: string) => apiRequest<Hotspot[]>(`/analyses/${analysisId}/hotspots`),
  getMetrics: (analysisId: string) => apiRequest<Metrics>(`/analyses/${analysisId}/metrics`),
}

// Explainability APIs
export const explainabilityApi = {
  getShapValues: (analysisId: string) => apiRequest<ShapValues>(`/explainability/${analysisId}/shap`),
  getFeatureImportance: (analysisId: string) => apiRequest<FeatureImportance[]>(`/explainability/${analysisId}/features`),
  getWaterfallChart: (analysisId: string, fileId: string) =>
    apiRequest<WaterfallData>(`/explainability/${analysisId}/waterfall/${fileId}`),
  getSummaryPlot: (analysisId: string) => apiRequest<SummaryPlotData>(`/explainability/${analysisId}/summary`),
}

// Simulation APIs
export const simulationApi = {
  create: (data: CreateSimulationData) => apiRequest<Simulation>('/simulations', { method: 'POST', body: data }),
  get: (id: string) => apiRequest<Simulation>(`/simulations/${id}`),
  list: (projectId: string) => apiRequest<Simulation[]>(`/simulations/project/${projectId}`),
  runScenario: (simulationId: string, scenario: ScenarioConfig) =>
    apiRequest<ScenarioResult>(`/simulations/${simulationId}/run`, { method: 'POST', body: scenario }),
  compareScenarios: (simulationId: string, scenarioIds: string[]) =>
    apiRequest<ComparisonResult>(`/simulations/${simulationId}/compare`, { method: 'POST', body: { scenario_ids: scenarioIds } }),
}

// Recommendations APIs
export const recommendationsApi = {
  get: (analysisId: string) => apiRequest<Recommendation[]>(`/recommendations/analysis/${analysisId}`),
  getById: (id: string) => apiRequest<Recommendation>(`/recommendations/${id}`),
  apply: (id: string) => apiRequest<ApplyResult>(`/recommendations/${id}/apply`, { method: 'POST' }),
  dismiss: (id: string) => apiRequest<void>(`/recommendations/${id}/dismiss`, { method: 'POST' }),
  getPrioritized: (analysisId: string, priority: 'energy' | 'performance' | 'balanced') =>
    apiRequest<Recommendation[]>(`/recommendations/analysis/${analysisId}/prioritized?priority=${priority}`),
}

// CI/CD APIs
export const cicdApi = {
  getConfig: (projectId: string) => apiRequest<CicdConfig>(`/cicd/projects/${projectId}/config`),
  updateConfig: (projectId: string, config: Partial<CicdConfig>) =>
    apiRequest<CicdConfig>(`/cicd/projects/${projectId}/config`, { method: 'PUT', body: config }),
  getRuns: (projectId: string) => apiRequest<CicdRun[]>(`/cicd/projects/${projectId}/runs`),
  getRun: (runId: string) => apiRequest<CicdRun>(`/cicd/runs/${runId}`),
  triggerRun: (projectId: string) => apiRequest<CicdRun>(`/cicd/projects/${projectId}/trigger`, { method: 'POST' }),
  getWebhook: (projectId: string) => apiRequest<WebhookInfo>(`/cicd/projects/${projectId}/webhook`),
  generateBadge: (projectId: string) => apiRequest<BadgeInfo>(`/cicd/projects/${projectId}/badge`),
}

// Auth APIs
export const authApi = {
  login: (email: string, password: string) =>
    apiRequest<AuthResponse>('/auth/login', { method: 'POST', body: { email, password } }),
  register: (data: RegisterData) => apiRequest<AuthResponse>('/auth/register', { method: 'POST', body: data }),
  logout: () => apiRequest<void>('/auth/logout', { method: 'POST' }),
  me: () => apiRequest<User>('/auth/me'),
  updateProfile: (data: Partial<User>) => apiRequest<User>('/auth/profile', { method: 'PUT', body: data }),
}

// Types
export interface Project {
  id: string
  name: string
  description?: string
  repository_url?: string
  language?: string
  created_at: string
  updated_at: string
  owner_id: string
  last_analysis_id?: string
  energy_score?: number
  carbon_footprint?: number
}

export interface CreateProjectData {
  name: string
  description?: string
  repository_url?: string
}

export interface Analysis {
  id: string
  project_id: string
  status: 'pending' | 'running' | 'completed' | 'failed'
  started_at: string
  completed_at?: string
  energy_score: number
  carbon_footprint: number
  total_files: number
  hotspot_count: number
  recommendation_count: number
}

export interface AnalysisConfig {
  include_patterns?: string[]
  exclude_patterns?: string[]
  depth?: number
}

export interface Hotspot {
  id: string
  file_path: string
  line_start: number
  line_end: number
  severity: 'critical' | 'high' | 'medium' | 'low'
  energy_impact: number
  issue_type: string
  description: string
  suggested_fix?: string
}

export interface Metrics {
  energy_score: number
  carbon_footprint: number
  estimated_kwh_per_month: number
  estimated_co2_per_month: number
  complexity_score: number
  efficiency_rating: string
}

export interface ShapValues {
  features: string[]
  values: number[][]
  base_value: number
}

export interface FeatureImportance {
  feature: string
  importance: number
  description: string
}

export interface WaterfallData {
  features: string[]
  values: number[]
  base_value: number
  output_value: number
}

export interface SummaryPlotData {
  features: string[]
  shap_values: number[][]
  feature_values: number[][]
}

export interface Simulation {
  id: string
  project_id: string
  name: string
  created_at: string
  scenarios: ScenarioConfig[]
  status: 'draft' | 'running' | 'completed'
}

export interface CreateSimulationData {
  project_id: string
  name: string
  base_analysis_id: string
}

export interface ScenarioConfig {
  id: string
  name: string
  parameters: Record<string, number | string | boolean>
}

export interface ScenarioResult {
  scenario_id: string
  energy_estimate: number
  carbon_estimate: number
  performance_impact: number
  confidence: number
}

export interface ComparisonResult {
  scenarios: {
    id: string
    name: string
    energy: number
    carbon: number
    performance: number
  }[]
  recommendations: string[]
}

export interface Recommendation {
  id: string
  analysis_id: string
  title: string
  description: string
  category: 'algorithm' | 'resource' | 'architecture' | 'configuration'
  priority: 'critical' | 'high' | 'medium' | 'low'
  estimated_savings: number
  effort: 'low' | 'medium' | 'high'
  code_changes?: CodeChange[]
  status: 'pending' | 'applied' | 'dismissed'
}

export interface CodeChange {
  file_path: string
  line_start: number
  line_end: number
  original_code: string
  suggested_code: string
}

export interface ApplyResult {
  success: boolean
  message: string
  files_modified: string[]
}

export interface CicdConfig {
  enabled: boolean
  fail_on_regression: boolean
  threshold_score: number
  threshold_carbon: number
  notify_on_failure: boolean
  notification_email?: string
  webhook_secret?: string
}

export interface CicdRun {
  id: string
  project_id: string
  commit_sha: string
  branch: string
  status: 'pending' | 'running' | 'passed' | 'failed'
  started_at: string
  completed_at?: string
  energy_score?: number
  carbon_footprint?: number
  passed_threshold: boolean
  report_url?: string
}

export interface WebhookInfo {
  url: string
  secret: string
  events: string[]
}

export interface BadgeInfo {
  markdown: string
  html: string
  image_url: string
}

export interface User {
  id: string
  email: string
  name: string
  avatar_url?: string
  created_at: string
}

export interface AuthResponse {
  access_token: string
  token_type: string
  user: User
}

export interface RegisterData {
  email: string
  password: string
  name: string
}

export { ApiError }
