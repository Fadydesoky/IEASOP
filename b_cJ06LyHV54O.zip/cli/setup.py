#!/usr/bin/env python3
"""Setup script for IEASOP CLI."""

from setuptools import setup, find_packages

setup(
    name="ieasop-cli",
    version="1.0.0",
    description="CLI for the Intelligent Energy-Aware Software Optimization Platform",
    author="IEASOP Team",
    author_email="team@ieasop.io",
    url="https://github.com/ieasop/cli",
    py_modules=["ieasop_cli"],
    python_requires=">=3.8",
    install_requires=[],
    entry_points={
        "console_scripts": [
            "ieasop=ieasop_cli:main",
        ],
    },
    classifiers=[
        "Development Status :: 4 - Beta",
        "Environment :: Console",
        "Intended Audience :: Developers",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Programming Language :: Python :: 3.12",
        "Topic :: Software Development :: Quality Assurance",
        "Topic :: Software Development :: Testing",
    ],
    keywords="energy optimization code analysis cli green software sustainability",
)
