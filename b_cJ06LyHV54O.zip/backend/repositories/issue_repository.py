"""
Issue Repository
Database operations for Issue entities
"""

from typing import Sequence
from sqlalchemy import select, func
from sqlalchemy.ext.asyncio import AsyncSession

from models.issue import Issue
from .base import BaseRepository


class IssueRepository(BaseRepository[Issue]):
    """Repository for Issue entity operations."""
    
    def __init__(self, session: AsyncSession) -> None:
        super().__init__(session, Issue)
    
    async def get_by_analysis_id(
        self,
        analysis_id: str,
        skip: int = 0,
        limit: int = 100
    ) -> Sequence[Issue]:
        """Get all issues for a specific analysis."""
        result = await self._session.execute(
            select(Issue)
            .where(Issue.analysis_id == analysis_id)
            .offset(skip)
            .limit(limit)
        )
        return result.scalars().all()
    
    async def get_by_severity(
        self,
        analysis_id: str,
        severity: str
    ) -> Sequence[Issue]:
        """Get issues filtered by severity for an analysis."""
        result = await self._session.execute(
            select(Issue)
            .where(Issue.analysis_id == analysis_id)
            .where(Issue.severity == severity)
        )
        return result.scalars().all()
    
    async def count_by_analysis(self, analysis_id: str) -> int:
        """Count issues for a specific analysis."""
        result = await self._session.execute(
            select(func.count())
            .select_from(Issue)
            .where(Issue.analysis_id == analysis_id)
        )
        return result.scalar_one()
    
    async def count_by_severity(
        self,
        analysis_id: str,
        severity: str
    ) -> int:
        """Count issues by severity for an analysis."""
        result = await self._session.execute(
            select(func.count())
            .select_from(Issue)
            .where(Issue.analysis_id == analysis_id)
            .where(Issue.severity == severity)
        )
        return result.scalar_one()
    
    async def create_issue(
        self,
        analysis_id: str,
        severity: str | None = None,
        title: str | None = None,
        description: str | None = None
    ) -> Issue:
        """Create a new issue for an analysis."""
        issue = Issue(
            analysis_id=analysis_id,
            severity=severity,
            title=title,
            description=description
        )
        return await self.create(issue)
    
    async def create_many_issues(
        self,
        analysis_id: str,
        issues_data: list[dict]
    ) -> list[Issue]:
        """Create multiple issues for an analysis."""
        issues = [
            Issue(
                analysis_id=analysis_id,
                severity=data.get("severity"),
                title=data.get("title"),
                description=data.get("description")
            )
            for data in issues_data
        ]
        return await self.create_many(issues)
