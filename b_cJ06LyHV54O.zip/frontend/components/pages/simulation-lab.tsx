"use client"

import { useState } from "react"
import { toast } from "sonner"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Label } from "@/components/ui/label"
import { Slider } from "@/components/ui/slider"
import { Separator } from "@/components/ui/separator"
import { Spinner } from "@/components/ui/spinner"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"
import {
  FlaskConical,
  Play,
  ArrowRight,
  TrendingUp,
  TrendingDown,
  Minus,
  Cpu,
  MemoryStick,
  Clock,
  RefreshCw,
  Info,
} from "lucide-react"
import {
  RadarChart,
  PolarGrid,
  PolarAngleAxis,
  PolarRadiusAxis,
  Radar,
  ResponsiveContainer,
  Legend,
} from "recharts"

interface SimulationParams {
  cpu_cores: number
  ram_gb: number
  execution_time_ms: number
  lines_of_code: number
  cyclomatic_complexity: number
  nested_loop_depth: number
  io_operations: number
  memory_allocations: number
  function_calls: number
  async_operations: number
}

interface SimulationResult {
  baseline: {
    energy_score: number
    carbon_footprint: number
  }
  simulated: {
    energy_score: number
    carbon_footprint: number
  }
  delta: {
    energy_score: number
    carbon_footprint: number
    improvement_percent: number
  }
}

const defaultParams: SimulationParams = {
  cpu_cores: 4,
  ram_gb: 8,
  execution_time_ms: 1000,
  lines_of_code: 500,
  cyclomatic_complexity: 10,
  nested_loop_depth: 2,
  io_operations: 10,
  memory_allocations: 100,
  function_calls: 50,
  async_operations: 5
}

export function SimulationLabPage() {
  const [baseParams, setBaseParams] = useState<SimulationParams>(defaultParams)
  const [scenarioParams, setScenarioParams] = useState<SimulationParams>(defaultParams)
  const [isSimulating, setIsSimulating] = useState(false)
  const [result, setResult] = useState<SimulationResult | null>(null)
  const [error, setError] = useState<string | null>(null)

  const runSimulation = async () => {
    setIsSimulating(true)
    setError(null)
    setResult(null)
    
    try {
      // Call the real backend API for scenario comparison
      const response = await fetch("/api/simulations/compare", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          base_scenario: {
            cpu_cores: baseParams.cpu_cores,
            ram_gb: baseParams.ram_gb,
            execution_time_ms: baseParams.execution_time_ms,
            lines_of_code: baseParams.lines_of_code,
            cyclomatic_complexity: baseParams.cyclomatic_complexity,
            nested_loop_depth: baseParams.nested_loop_depth,
            io_operations: baseParams.io_operations,
            memory_allocations: baseParams.memory_allocations,
            function_calls: baseParams.function_calls,
            async_operations: baseParams.async_operations
          },
          scenarios: [{
            cpu_cores: scenarioParams.cpu_cores,
            ram_gb: scenarioParams.ram_gb,
            execution_time_ms: scenarioParams.execution_time_ms,
            lines_of_code: scenarioParams.lines_of_code,
            cyclomatic_complexity: scenarioParams.cyclomatic_complexity,
            nested_loop_depth: scenarioParams.nested_loop_depth,
            io_operations: scenarioParams.io_operations,
            memory_allocations: scenarioParams.memory_allocations,
            function_calls: scenarioParams.function_calls,
            async_operations: scenarioParams.async_operations
          }]
        }),
      })
      
      if (!response.ok) {
        const errorData = await response.json().catch(() => ({}))
        throw new Error(errorData.detail || `Simulation failed: ${response.status}`)
      }
      
      const data = await response.json()
      
      // Map API response to our result format
      const scenarioResult = data.scenarios?.[0]
      if (scenarioResult) {
        const simResult = {
          baseline: {
            energy_score: data.baseline.energy_score,
            carbon_footprint: data.baseline.carbon_footprint
          },
          simulated: {
            energy_score: scenarioResult.energy_score,
            carbon_footprint: scenarioResult.carbon_footprint
          },
          delta: {
            energy_score: scenarioResult.delta_score,
            carbon_footprint: scenarioResult.delta_carbon,
            improvement_percent: scenarioResult.improvement_percent
          }
        }
        setResult(simResult)
        const improvementText = simResult.delta.improvement_percent > 0 
          ? `+${simResult.delta.improvement_percent.toFixed(1)}% improvement`
          : `${simResult.delta.improvement_percent.toFixed(1)}% change`
        toast.success("Simulation Complete", {
          description: `Scenario score: ${simResult.simulated.energy_score.toFixed(1)}/100 (${improvementText})`
        })
      } else {
        throw new Error("No simulation results returned from server")
      }
    } catch (err) {
      console.error("[v0] Simulation error:", err)
      const errorMessage = err instanceof Error ? err.message : "Simulation failed"
      setError(errorMessage)
      toast.error("Simulation Failed", {
        description: errorMessage
      })
    } finally {
      setIsSimulating(false)
    }
  }

  const resetScenario = () => {
    setScenarioParams({ ...baseParams })
    setResult(null)
  }

  const radarData = [
    {
      metric: "CPU Efficiency",
      baseline: 100 - (baseParams.cpu_cores / 64) * 100,
      scenario: 100 - (scenarioParams.cpu_cores / 64) * 100,
    },
    {
      metric: "Memory Efficiency",
      baseline: 100 - (baseParams.ram_gb / 256) * 100,
      scenario: 100 - (scenarioParams.ram_gb / 256) * 100,
    },
    {
      metric: "Time Efficiency",
      baseline: 100 - (baseParams.execution_time_ms / 10000) * 100,
      scenario: 100 - (scenarioParams.execution_time_ms / 10000) * 100,
    },
    {
      metric: "Code Efficiency",
      baseline: 100 - (baseParams.cyclomatic_complexity / 50) * 100,
      scenario: 100 - (scenarioParams.cyclomatic_complexity / 50) * 100,
    },
    {
      metric: "I/O Efficiency",
      baseline: 100 - (baseParams.io_operations / 100) * 100,
      scenario: 100 - (scenarioParams.io_operations / 100) * 100,
    },
    {
      metric: "Async Usage",
      baseline: (baseParams.async_operations / 50) * 100,
      scenario: (scenarioParams.async_operations / 50) * 100,
    },
  ]

  const ParamSlider = ({ 
    label, 
    value, 
    onChange, 
    min, 
    max, 
    step = 1,
    unit = "",
    icon: Icon
  }: {
    label: string
    value: number
    onChange: (value: number) => void
    min: number
    max: number
    step?: number
    unit?: string
    icon?: React.ElementType
  }) => (
    <div className="space-y-2">
      <div className="flex items-center justify-between">
        <Label className="flex items-center gap-2">
          {Icon && <Icon className="h-4 w-4 text-muted-foreground" />}
          {label}
        </Label>
        <span className="text-sm font-medium">{value}{unit}</span>
      </div>
      <Slider
        value={[value]}
        onValueChange={([v]) => onChange(v)}
        min={min}
        max={max}
        step={step}
        className="cursor-pointer"
      />
    </div>
  )

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold tracking-tight flex items-center gap-2">
            <FlaskConical className="h-6 w-6 text-primary" />
            Scenario Simulation Lab
          </h2>
          <p className="text-muted-foreground">
            Experiment with different parameters to optimize energy efficiency
          </p>
        </div>
        <div className="flex gap-2">
          <Button variant="outline" onClick={resetScenario}>
            <RefreshCw className="mr-2 h-4 w-4" />
            Reset
          </Button>
          <Button onClick={runSimulation} disabled={isSimulating}>
            {isSimulating ? (
              <>
                <Spinner className="mr-2 h-4 w-4" />
                Simulating...
              </>
            ) : (
              <>
                <Play className="mr-2 h-4 w-4" />
                Run Simulation
              </>
            )}
          </Button>
        </div>
      </div>

      {/* Error Alert */}
      {error && (
        <Alert variant="destructive">
          <Info className="h-4 w-4" />
          <AlertTitle>Simulation Error</AlertTitle>
          <AlertDescription>
            {error}. Please check your parameters and try again.
          </AlertDescription>
        </Alert>
      )}

      {/* Parameter Controls */}
      <div className="grid gap-6 lg:grid-cols-2">
        {/* Baseline Parameters */}
        <Card>
          <CardHeader>
            <CardTitle className="text-lg">Baseline Configuration</CardTitle>
            <CardDescription>Current system parameters</CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            <ParamSlider
              label="CPU Cores"
              value={baseParams.cpu_cores}
              onChange={(v) => setBaseParams({ ...baseParams, cpu_cores: v })}
              min={1}
              max={64}
              icon={Cpu}
            />
            <ParamSlider
              label="RAM"
              value={baseParams.ram_gb}
              onChange={(v) => setBaseParams({ ...baseParams, ram_gb: v })}
              min={1}
              max={256}
              unit=" GB"
              icon={MemoryStick}
            />
            <ParamSlider
              label="Execution Time"
              value={baseParams.execution_time_ms}
              onChange={(v) => setBaseParams({ ...baseParams, execution_time_ms: v })}
              min={10}
              max={10000}
              step={10}
              unit=" ms"
              icon={Clock}
            />
            <Separator />
            <ParamSlider
              label="Cyclomatic Complexity"
              value={baseParams.cyclomatic_complexity}
              onChange={(v) => setBaseParams({ ...baseParams, cyclomatic_complexity: v })}
              min={1}
              max={50}
            />
            <ParamSlider
              label="Nested Loop Depth"
              value={baseParams.nested_loop_depth}
              onChange={(v) => setBaseParams({ ...baseParams, nested_loop_depth: v })}
              min={0}
              max={10}
            />
            <ParamSlider
              label="I/O Operations"
              value={baseParams.io_operations}
              onChange={(v) => setBaseParams({ ...baseParams, io_operations: v })}
              min={0}
              max={100}
            />
            <ParamSlider
              label="Async Operations"
              value={baseParams.async_operations}
              onChange={(v) => setBaseParams({ ...baseParams, async_operations: v })}
              min={0}
              max={50}
            />
          </CardContent>
        </Card>

        {/* Scenario Parameters */}
        <Card>
          <CardHeader>
            <CardTitle className="text-lg">Scenario Configuration</CardTitle>
            <CardDescription>Modified parameters to simulate</CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            <ParamSlider
              label="CPU Cores"
              value={scenarioParams.cpu_cores}
              onChange={(v) => setScenarioParams({ ...scenarioParams, cpu_cores: v })}
              min={1}
              max={64}
              icon={Cpu}
            />
            <ParamSlider
              label="RAM"
              value={scenarioParams.ram_gb}
              onChange={(v) => setScenarioParams({ ...scenarioParams, ram_gb: v })}
              min={1}
              max={256}
              unit=" GB"
              icon={MemoryStick}
            />
            <ParamSlider
              label="Execution Time"
              value={scenarioParams.execution_time_ms}
              onChange={(v) => setScenarioParams({ ...scenarioParams, execution_time_ms: v })}
              min={10}
              max={10000}
              step={10}
              unit=" ms"
              icon={Clock}
            />
            <Separator />
            <ParamSlider
              label="Cyclomatic Complexity"
              value={scenarioParams.cyclomatic_complexity}
              onChange={(v) => setScenarioParams({ ...scenarioParams, cyclomatic_complexity: v })}
              min={1}
              max={50}
            />
            <ParamSlider
              label="Nested Loop Depth"
              value={scenarioParams.nested_loop_depth}
              onChange={(v) => setScenarioParams({ ...scenarioParams, nested_loop_depth: v })}
              min={0}
              max={10}
            />
            <ParamSlider
              label="I/O Operations"
              value={scenarioParams.io_operations}
              onChange={(v) => setScenarioParams({ ...scenarioParams, io_operations: v })}
              min={0}
              max={100}
            />
            <ParamSlider
              label="Async Operations"
              value={scenarioParams.async_operations}
              onChange={(v) => setScenarioParams({ ...scenarioParams, async_operations: v })}
              min={0}
              max={50}
            />
          </CardContent>
        </Card>
      </div>

      {/* Results */}
      {result && (
        <div className="grid gap-6 lg:grid-cols-3">
          {/* Comparison Cards */}
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium">Baseline Score</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold">{result.baseline.energy_score.toFixed(1)}</div>
              <p className="text-xs text-muted-foreground">
                {(result.baseline.carbon_footprint * 1000).toFixed(2)}g CO2
              </p>
            </CardContent>
          </Card>

          <Card className="flex flex-col items-center justify-center">
            <CardContent className="pt-6 flex items-center gap-4">
              <ArrowRight className="h-6 w-6 text-muted-foreground" />
              <div className="text-center">
                <div className={`text-2xl font-bold flex items-center gap-1 ${
                  result.delta.improvement_percent > 0 ? "text-green-500" : 
                  result.delta.improvement_percent < 0 ? "text-red-500" : ""
                }`}>
                  {result.delta.improvement_percent > 0 ? (
                    <TrendingUp className="h-5 w-5" />
                  ) : result.delta.improvement_percent < 0 ? (
                    <TrendingDown className="h-5 w-5" />
                  ) : (
                    <Minus className="h-5 w-5" />
                  )}
                  {result.delta.improvement_percent > 0 ? "+" : ""}
                  {result.delta.improvement_percent.toFixed(1)}%
                </div>
                <p className="text-xs text-muted-foreground">Change</p>
              </div>
              <ArrowRight className="h-6 w-6 text-muted-foreground" />
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium">Scenario Score</CardTitle>
            </CardHeader>
            <CardContent>
              <div className={`text-3xl font-bold ${
                result.simulated.energy_score > result.baseline.energy_score ? "text-green-500" :
                result.simulated.energy_score < result.baseline.energy_score ? "text-red-500" : ""
              }`}>
                {result.simulated.energy_score.toFixed(1)}
              </div>
              <p className="text-xs text-muted-foreground">
                {(result.simulated.carbon_footprint * 1000).toFixed(2)}g CO2
              </p>
            </CardContent>
          </Card>
        </div>
      )}

      {/* Radar Chart */}
      <Card>
        <CardHeader>
          <CardTitle>Efficiency Comparison</CardTitle>
          <CardDescription>
            Visual comparison of baseline vs scenario across different metrics
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="h-[400px]">
            <ResponsiveContainer width="100%" height="100%">
              <RadarChart data={radarData}>
                <PolarGrid className="stroke-muted" />
                <PolarAngleAxis dataKey="metric" className="text-xs" />
                <PolarRadiusAxis angle={30} domain={[0, 100]} className="text-xs" />
                <Radar
                  name="Baseline"
                  dataKey="baseline"
                  stroke="hsl(var(--muted-foreground))"
                  fill="hsl(var(--muted-foreground))"
                  fillOpacity={0.3}
                />
                <Radar
                  name="Scenario"
                  dataKey="scenario"
                  stroke="hsl(var(--primary))"
                  fill="hsl(var(--primary))"
                  fillOpacity={0.3}
                />
                <Legend />
              </RadarChart>
            </ResponsiveContainer>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
