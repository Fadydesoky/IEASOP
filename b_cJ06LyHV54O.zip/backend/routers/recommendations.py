"""
Recommendations Router
Energy optimization recommendations endpoints
"""

from fastapi import APIRouter, HTTPException, Header
from pydantic import BaseModel
from typing import Optional, List
from datetime import datetime
from db import get_client
from routers.auth import get_current_user

router = APIRouter()


class RecommendationUpdate(BaseModel):
    """Recommendation update model."""
    status: str  # pending, applied, dismissed


class RecommendationResponse(BaseModel):
    """Recommendation response model."""
    id: str
    analysis_id: str
    hotspot_id: Optional[str] = None
    title: str
    description: Optional[str] = None
    category: str
    priority: int
    estimated_savings: float
    original_code: Optional[str] = None
    suggested_code: Optional[str] = None
    status: str
    created_at: datetime


@router.get("", response_model=List[RecommendationResponse])
async def list_recommendations(
    analysis_id: Optional[str] = None,
    status: Optional[str] = None,
    category: Optional[str] = None,
    authorization: str = Header(None)
):
    """List recommendations for current user."""
    user = await get_current_user(authorization)
    client = await get_client()
    
    # Get user's analyses first
    analyses = await client.table("analyses").select("id").eq("user_id", user.id).execute()
    if not analyses.data:
        return []
    
    analysis_ids = [a["id"] for a in analyses.data]
    
    query = client.table("recommendations").select("*").in_("analysis_id", analysis_ids)
    
    if analysis_id:
        query = query.eq("analysis_id", analysis_id)
    
    if status:
        query = query.eq("status", status)
    
    if category:
        query = query.eq("category", category)
    
    result = await query.order("priority").order("estimated_savings", desc=True).execute()
    
    return result.data or []


@router.get("/summary")
async def recommendations_summary(authorization: str = Header(None)):
    """Get summary of all recommendations for current user."""
    user = await get_current_user(authorization)
    client = await get_client()
    
    # Get user's analyses
    analyses = await client.table("analyses").select("id").eq("user_id", user.id).execute()
    if not analyses.data:
        return {
            "total": 0,
            "pending": 0,
            "applied": 0,
            "dismissed": 0,
            "by_category": {},
            "total_potential_savings": 0
        }
    
    analysis_ids = [a["id"] for a in analyses.data]
    
    result = await client.table("recommendations").select("*").in_("analysis_id", analysis_ids).execute()
    recs = result.data or []
    
    summary = {
        "total": len(recs),
        "pending": len([r for r in recs if r["status"] == "pending"]),
        "applied": len([r for r in recs if r["status"] == "applied"]),
        "dismissed": len([r for r in recs if r["status"] == "dismissed"]),
        "by_category": {},
        "total_potential_savings": 0,
        "by_priority": {
            "critical": len([r for r in recs if r["priority"] == 1]),
            "important": len([r for r in recs if r["priority"] == 2]),
            "suggested": len([r for r in recs if r["priority"] == 3])
        }
    }
    
    for rec in recs:
        cat = rec.get("category", "other")
        summary["by_category"][cat] = summary["by_category"].get(cat, 0) + 1
        if rec["status"] == "pending":
            summary["total_potential_savings"] += rec.get("estimated_savings", 0)
    
    summary["total_potential_savings"] = round(summary["total_potential_savings"], 2)
    
    return summary


@router.get("/{recommendation_id}", response_model=RecommendationResponse)
async def get_recommendation(recommendation_id: str, authorization: str = Header(None)):
    """Get a specific recommendation."""
    user = await get_current_user(authorization)
    client = await get_client()
    
    # Get recommendation
    rec = await client.table("recommendations").select("*").eq("id", recommendation_id).single().execute()
    
    if not rec.data:
        raise HTTPException(status_code=404, detail="Recommendation not found")
    
    # Verify ownership via analysis
    analysis = await client.table("analyses").select("id").eq("id", rec.data["analysis_id"]).eq("user_id", user.id).single().execute()
    
    if not analysis.data:
        raise HTTPException(status_code=404, detail="Recommendation not found")
    
    return rec.data


@router.put("/{recommendation_id}", response_model=RecommendationResponse)
async def update_recommendation(
    recommendation_id: str,
    update: RecommendationUpdate,
    authorization: str = Header(None)
):
    """Update recommendation status."""
    user = await get_current_user(authorization)
    client = await get_client()
    
    # Get recommendation
    rec = await client.table("recommendations").select("*").eq("id", recommendation_id).single().execute()
    
    if not rec.data:
        raise HTTPException(status_code=404, detail="Recommendation not found")
    
    # Verify ownership via analysis
    analysis = await client.table("analyses").select("id").eq("id", rec.data["analysis_id"]).eq("user_id", user.id).single().execute()
    
    if not analysis.data:
        raise HTTPException(status_code=404, detail="Recommendation not found")
    
    # Update status
    if update.status not in ["pending", "applied", "dismissed"]:
        raise HTTPException(status_code=400, detail="Invalid status")
    
    result = await client.table("recommendations").update({"status": update.status}).eq("id", recommendation_id).execute()
    
    return result.data[0]


@router.post("/{recommendation_id}/apply")
async def apply_recommendation(recommendation_id: str, authorization: str = Header(None)):
    """Mark a recommendation as applied."""
    user = await get_current_user(authorization)
    client = await get_client()
    
    # Get recommendation
    rec = await client.table("recommendations").select("*").eq("id", recommendation_id).single().execute()
    
    if not rec.data:
        raise HTTPException(status_code=404, detail="Recommendation not found")
    
    # Verify ownership via analysis
    analysis = await client.table("analyses").select("id").eq("id", rec.data["analysis_id"]).eq("user_id", user.id).single().execute()
    
    if not analysis.data:
        raise HTTPException(status_code=404, detail="Recommendation not found")
    
    result = await client.table("recommendations").update({"status": "applied"}).eq("id", recommendation_id).execute()
    
    return {
        "message": "Recommendation marked as applied",
        "recommendation": result.data[0],
        "estimated_savings": rec.data.get("estimated_savings", 0)
    }


@router.post("/{recommendation_id}/dismiss")
async def dismiss_recommendation(recommendation_id: str, authorization: str = Header(None)):
    """Dismiss a recommendation."""
    user = await get_current_user(authorization)
    client = await get_client()
    
    # Get recommendation
    rec = await client.table("recommendations").select("*").eq("id", recommendation_id).single().execute()
    
    if not rec.data:
        raise HTTPException(status_code=404, detail="Recommendation not found")
    
    # Verify ownership via analysis
    analysis = await client.table("analyses").select("id").eq("id", rec.data["analysis_id"]).eq("user_id", user.id).single().execute()
    
    if not analysis.data:
        raise HTTPException(status_code=404, detail="Recommendation not found")
    
    result = await client.table("recommendations").update({"status": "dismissed"}).eq("id", recommendation_id).execute()
    
    return {
        "message": "Recommendation dismissed",
        "recommendation": result.data[0]
    }
