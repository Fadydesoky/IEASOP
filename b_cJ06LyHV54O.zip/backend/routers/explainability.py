"""
Explainability Router
SHAP-based model explainability endpoints
"""

from fastapi import APIRouter, HTTPException, Header
from pydantic import BaseModel
from typing import Optional
from db import get_client
from routers.auth import get_current_user
from services.ml_pipeline import (
    FeatureSet,
    get_shap_waterfall,
    get_shap_force,
    get_feature_importance,
    predict_energy
)

router = APIRouter()


class ExplainRequest(BaseModel):
    """Request model for explanation."""
    cpu_cores: float = 4.0
    ram_gb: float = 8.0
    execution_time_ms: float = 1000.0
    lines_of_code: int = 500
    cyclomatic_complexity: float = 10.0
    nested_loop_depth: int = 2
    io_operations: int = 10
    memory_allocations: int = 100
    function_calls: int = 50
    async_operations: int = 5


@router.get("/feature-importance")
async def feature_importance(authorization: str = Header(None)):
    """Get global feature importance from the model."""
    await get_current_user(authorization)  # Verify auth
    
    importance = get_feature_importance()
    
    if importance is None:
        raise HTTPException(status_code=500, detail="Could not compute feature importance")
    
    return importance


@router.post("/waterfall")
async def waterfall_explanation(
    request: ExplainRequest,
    authorization: str = Header(None)
):
    """Get SHAP waterfall plot data for given features."""
    await get_current_user(authorization)
    
    features = FeatureSet(
        cpu_cores=request.cpu_cores,
        ram_gb=request.ram_gb,
        execution_time_ms=request.execution_time_ms,
        lines_of_code=request.lines_of_code,
        cyclomatic_complexity=request.cyclomatic_complexity,
        nested_loop_depth=request.nested_loop_depth,
        io_operations=request.io_operations,
        memory_allocations=request.memory_allocations,
        function_calls=request.function_calls,
        async_operations=request.async_operations
    )
    
    waterfall = get_shap_waterfall(features)
    
    if waterfall is None:
        raise HTTPException(status_code=500, detail="Could not generate waterfall explanation")
    
    return waterfall


@router.post("/force")
async def force_explanation(
    request: ExplainRequest,
    authorization: str = Header(None)
):
    """Get SHAP force plot data for given features."""
    await get_current_user(authorization)
    
    features = FeatureSet(
        cpu_cores=request.cpu_cores,
        ram_gb=request.ram_gb,
        execution_time_ms=request.execution_time_ms,
        lines_of_code=request.lines_of_code,
        cyclomatic_complexity=request.cyclomatic_complexity,
        nested_loop_depth=request.nested_loop_depth,
        io_operations=request.io_operations,
        memory_allocations=request.memory_allocations,
        function_calls=request.function_calls,
        async_operations=request.async_operations
    )
    
    force = get_shap_force(features)
    
    if force is None:
        raise HTTPException(status_code=500, detail="Could not generate force explanation")
    
    return force


@router.get("/analyses/{analysis_id}/waterfall")
async def analysis_waterfall(analysis_id: str, authorization: str = Header(None)):
    """Get SHAP waterfall for a specific analysis."""
    user = await get_current_user(authorization)
    client = await get_client()
    
    # Get analysis
    result = await client.table("analyses").select("ml_features").eq("id", analysis_id).eq("user_id", user.id).single().execute()
    
    if not result.data:
        raise HTTPException(status_code=404, detail="Analysis not found")
    
    ml_features = result.data.get("ml_features")
    if not ml_features:
        raise HTTPException(status_code=400, detail="Analysis has no ML features")
    
    features = FeatureSet(**ml_features)
    waterfall = get_shap_waterfall(features)
    
    if waterfall is None:
        raise HTTPException(status_code=500, detail="Could not generate waterfall explanation")
    
    return waterfall


@router.get("/analyses/{analysis_id}/force")
async def analysis_force(analysis_id: str, authorization: str = Header(None)):
    """Get SHAP force plot for a specific analysis."""
    user = await get_current_user(authorization)
    client = await get_client()
    
    # Get analysis
    result = await client.table("analyses").select("ml_features").eq("id", analysis_id).eq("user_id", user.id).single().execute()
    
    if not result.data:
        raise HTTPException(status_code=404, detail="Analysis not found")
    
    ml_features = result.data.get("ml_features")
    if not ml_features:
        raise HTTPException(status_code=400, detail="Analysis has no ML features")
    
    features = FeatureSet(**ml_features)
    force = get_shap_force(features)
    
    if force is None:
        raise HTTPException(status_code=500, detail="Could not generate force explanation")
    
    return force


@router.get("/analyses/{analysis_id}/summary")
async def analysis_explanation_summary(analysis_id: str, authorization: str = Header(None)):
    """Get a natural language summary of the analysis explanation."""
    user = await get_current_user(authorization)
    client = await get_client()
    
    # Get analysis with SHAP summary
    result = await client.table("analyses").select("*").eq("id", analysis_id).eq("user_id", user.id).single().execute()
    
    if not result.data:
        raise HTTPException(status_code=404, detail="Analysis not found")
    
    shap_summary = result.data.get("shap_summary", {})
    energy_score = result.data.get("energy_score", 0)
    
    # Generate natural language explanation
    sorted_features = sorted(shap_summary.items(), key=lambda x: abs(x[1]), reverse=True)
    
    positive_factors = [f for f, v in sorted_features if v > 0][:3]
    negative_factors = [f for f, v in sorted_features if v < 0][:3]
    
    summary_parts = []
    
    if energy_score >= 80:
        summary_parts.append(f"This code has an excellent energy efficiency score of {energy_score}.")
    elif energy_score >= 60:
        summary_parts.append(f"This code has a good energy efficiency score of {energy_score}, but there's room for improvement.")
    elif energy_score >= 40:
        summary_parts.append(f"This code has a moderate energy efficiency score of {energy_score}. Consider applying the recommendations below.")
    else:
        summary_parts.append(f"This code has a low energy efficiency score of {energy_score}. Significant optimizations are recommended.")
    
    if positive_factors:
        factor_names = [f.replace("_", " ") for f in positive_factors]
        summary_parts.append(f"Factors improving efficiency: {', '.join(factor_names)}.")
    
    if negative_factors:
        factor_names = [f.replace("_", " ") for f in negative_factors]
        summary_parts.append(f"Factors reducing efficiency: {', '.join(factor_names)}.")
    
    return {
        "analysis_id": analysis_id,
        "energy_score": energy_score,
        "summary": " ".join(summary_parts),
        "top_positive_factors": positive_factors,
        "top_negative_factors": negative_factors,
        "shap_values": shap_summary
    }
