"""
IEASOP Backend - Intelligent Energy-Aware Software Optimization Platform
FastAPI Application Entry Point
"""

import fastapi
import fastapi.middleware.cors

from routers import auth, projects, analyses, recommendations, simulations, explainability, cicd, cli_api
from services.ml_pipeline import is_ml_available


app = fastapi.FastAPI(
    title="IEASOP API",
    description="Intelligent Energy-Aware Software Optimization Platform",
    version="1.0.0"
)

app.add_middleware(
    fastapi.middleware.cors.CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Include routers
app.include_router(auth.router, tags=["Authentication"])
app.include_router(projects.router, prefix="/projects", tags=["Projects"])
app.include_router(analyses.router, prefix="/analyses", tags=["Analyses"])
app.include_router(recommendations.router, prefix="/recommendations", tags=["Recommendations"])
app.include_router(simulations.router, prefix="/simulations", tags=["Simulations"])
app.include_router(explainability.router, prefix="/explain", tags=["Explainability"])
app.include_router(cicd.router, prefix="/cicd", tags=["CI/CD"])
app.include_router(cli_api.router, prefix="/cli", tags=["CLI"])


@app.get("/health")
async def health() -> dict:
    """Health check endpoint."""
    return {
        "status": "ok",
        "service": "ieasop-backend",
        "ml_available": is_ml_available(),
        "mode": "full" if is_ml_available() else "lite"
    }


@app.get("/dashboard/summary")
async def dashboard_summary(authorization: str = fastapi.Header(None)):
    """Get dashboard summary for current user."""
    from db import get_client
    from routers.auth import get_current_user
    
    try:
        user = await get_current_user(authorization)
        client = await get_client()
        
        # Get total projects
        projects = await client.table("projects").select("id, latest_energy_score, latest_carbon_footprint").eq("user_id", user.id).execute()
        total_projects = len(projects.data) if projects.data else 0
        
        # Calculate average energy score
        scores = [p["latest_energy_score"] for p in (projects.data or []) if p.get("latest_energy_score")]
        avg_energy_score = sum(scores) / len(scores) if scores else 0
        
        # Get total analyses
        analyses = await client.table("analyses").select("id, energy_score, carbon_footprint").eq("user_id", user.id).execute()
        total_analyses = len(analyses.data) if analyses.data else 0
        
        # Calculate total carbon saved (simple estimate based on score improvement)
        carbon_values = [a.get("carbon_footprint", 0) for a in (analyses.data or []) if a.get("carbon_footprint")]
        initial_carbon = sum(carbon_values[:5]) / max(len(carbon_values[:5]), 1) if carbon_values else 0
        current_carbon = sum(carbon_values[-5:]) / max(len(carbon_values[-5:]), 1) if carbon_values else 0
        total_carbon_saved = max(0, (initial_carbon - current_carbon) * 1000)  # Convert to grams
        
        # Get pending recommendations (active hotspots)
        analysis_ids = [a["id"] for a in (analyses.data or [])]
        active_hotspots = 0
        if analysis_ids:
            recs = await client.table("recommendations").select("id").in_("analysis_id", analysis_ids).eq("status", "pending").execute()
            active_hotspots = len(recs.data) if recs.data else 0
        
        return {
            "total_projects": total_projects,
            "total_analyses": total_analyses,
            "avg_energy_score": round(avg_energy_score, 1),
            "total_carbon_saved": round(total_carbon_saved, 2),
            "active_hotspots": active_hotspots,
            "energy_trend": [],  # Could be populated from energy_metrics table
            "project_scores": [],
            "recent_activity": []
        }
    except Exception as e:
        # Return demo data if auth fails or no data
        return {
            "total_projects": 0,
            "total_analyses": 0,
            "avg_energy_score": 0,
            "total_carbon_saved": 0,
            "active_hotspots": 0,
            "energy_trend": [],
            "project_scores": [],
            "recent_activity": []
        }
